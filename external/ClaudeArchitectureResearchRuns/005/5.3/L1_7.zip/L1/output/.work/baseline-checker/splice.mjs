// Reverse-applies this pass's two checker edits to the copy, then reports its SHA-256 (must be the recorded
// unmodified iteration-6 checker hash for the copy to be used).
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));
const file = path.join(dir, 'check-instructions.mjs');
const lines = readFileSync(file, 'utf8').split('\n');
const routing = readFileSync(path.join(dir, 'it6-routing.txt'), 'utf8').replace(/\n$/, '').split('\n');
const targets = readFileSync(path.join(dir, 'it6-targets.txt'), 'utf8').replace(/\n$/, '').split('\n');
const find = (pred, from = 0) => { const i = lines.findIndex((l, k) => k >= from && pred(l)); if (i < 0) throw new Error('region not found'); return i; };
const tStart = find((l) => l.startsWith('  // Routing targets: the Level 2+ skills'));
const tEnd = find((l) => l === '  };', tStart);
lines.splice(tStart, tEnd - tStart + 1, ...targets);
const rStart = find((l) => l.startsWith('// Routing pointers — positive reference proof.'));
const rEnd = find((l) => l === '      if (!range) continue;', rStart);
lines.splice(rStart, rEnd - rStart + 1, ...routing);
writeFileSync(file, lines.join('\n'));
console.log(`reconstructed unmodified checker sha256 ${createHash('sha256').update(readFileSync(file)).digest('hex')}`);
console.log('recorded unmodified checker sha256      cc1f813da6fadc6d22378ac92d65d6761af0011fc2a3e35853a6137655a3db79');
