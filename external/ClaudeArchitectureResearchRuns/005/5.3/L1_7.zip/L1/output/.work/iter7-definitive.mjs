// Iteration-7 definitive confirmation: ONE invocation, oracles fixed in this file.
//  1. bypass proof: the hash-verified unmodified iteration-6 checker overlaid into sandboxes;
//  2. the finite matrix (sections A-E) with the template's current checker;
//  3. the cumulative gates: identity against the self-verifying start inventory, enforcement identity, syntax,
//     both checkers, residual scan, 196-policy audit, broken references, hygiene (iterations 2-6 definition),
//     always-loaded size.
// FAIL oracle: exit 1, the intended file named, and the intended diagnostic (for neutrality cases "names
// concrete technology '<Docker|Swagger>'"). PASS oracle: exit 0 with 0 violations and 0 warnings. Every run
// must report the sandbox itself as the checked root.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync, readdirSync, statSync, copyFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { OWNERS } from './policy-owners.mjs';

const WORK = path.dirname(fileURLToPath(import.meta.url));
const WS = path.resolve(WORK, '..', '..');
const T = path.join(WS, 'output', 'template');
const UNMODIFIED = path.join(WORK, 'baseline-checker', 'check-instructions.mjs');
const UNMODIFIED_SHA = 'cc1f813da6fadc6d22378ac92d65d6761af0011fc2a3e35853a6137655a3db79';
const START_TREE = '6d3c3ab9f9bf2142aa6e9cb0b3008d9bdfe452d81f461ebb019393bc37b3fec2';
const sha = (b) => createHash('sha256').update(b).digest('hex');
const env = { ...process.env, GIT_CEILING_DIRECTORIES: WORK.replace(/\\/g, '/') };
delete env.CLAUDE_PROJECT_DIR;

const L0 = '.claude/rules/0-core/engineering.md';
const L1 = '.claude/rules/1-architecture/roles.md';
const L1F = '.claude/rules/1-architecture/frame/boundaries.md';
const LAYOUT = '.claude/capabilities/architecture/clean-architecture/layout.md';
const FRAME_MANIFEST = '.claude/capabilities/architecture/clean-architecture/MODULE.md';
const L2 = '.claude/rules/2-technology/backend-libraries.md';
const CHECKER = '.claude/scripts/check-instructions.mjs';
const short = (f) => f.split('/').pop();
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
const read = (sb, f) => readFileSync(path.join(sb, f), 'utf8');
const write = (sb, f, t) => { mkdirSync(path.dirname(path.join(sb, f)), { recursive: true }); writeFileSync(path.join(sb, f), t); };
const append = (f, text) => (sb) => write(sb, f, `${read(sb, f).replace(/\s*$/, '')}\n\n${text}\n`);
const replace = (f, from, to) => (sb) => { const t = read(sb, f); if (!t.includes(from)) throw new Error(`setup: '${from.slice(0, 40)}' not in ${f}`); write(sb, f, t.replace(from, to)); };
const all = (...steps) => (sb) => steps.forEach((s) => s(sb));
const rm = (f) => (sb) => rmSync(path.join(sb, f), { recursive: true, force: true });
const json = (f, edit) => (sb) => { const d = JSON.parse(read(sb, f)); edit(d); write(sb, f, `${JSON.stringify(d, null, 2)}\n`); };
const tech = (f, term) => new RegExp(`^VIOLATION ${esc(f)}: Level \\S+ names concrete technology '${term}'`);
const PLACES = [L0, L1F];

// ---- 1. Bypass proof cases (unmodified checker) ----------------------------------------------------
const BASELINE = [
  { id: 'control: Technique: `docker`.', mutate: append(L0, 'Technique: `docker`.'), unmodifiedMustBe: 'PASS' },
  { id: 'control: Selected deployment technology: `docker`.', mutate: append(L0, 'Selected deployment technology: `docker`.'), unmodifiedMustBe: 'FAIL' },
  { id: 'bypass: Selected deployment technology: Technique: `docker`.', mutate: append(L0, 'Selected deployment technology: Technique: `docker`.'), unmodifiedMustBe: 'PASS' },
  { id: 'bypass: ### Selected deployment technology + Technique: `docker`.', mutate: append(L0, '### Selected deployment technology\nTechnique: `docker`.'), unmodifiedMustBe: 'PASS' },
];

// ---- 2. Matrix (current checker) ---------------------------------------------------------------------
const F = [];
const fail = (group, id, mutate, file, why) => F.push({ group, id, expect: 'FAIL', mutate, file, why });
const pass = (group, id, mutate, opts = {}) => F.push({ group, id, expect: 'PASS', mutate, ...opts });
const failAt = (group, text, term = 'Docker', places = PLACES) => { for (const f of places) fail(group, `${short(f)}: ${JSON.stringify(text)}`, append(f, text), f, tech(f, term)); };
const passAt = (group, text, places = PLACES) => { for (const f of places) pass(group, `${short(f)}: ${JSON.stringify(text)}`, append(f, text)); };

for (const text of ['Technique: `docker`.', 'See technique: `docker`.', 'Containers -> `docker`.', 'Deployment technique: Technique: `docker`.',
  '### Deployment technique\nTechnique: `docker`.', '- Deployment technique:\n  - `docker`', 'Technique: `swagger`.', 'OpenAPI documentation -> `swagger`.']) passAt('A pure pointer PASS', text);
pass('A pure pointer PASS', 'clean template (genuine aside, routing map, footnote)', () => {}, { slots: true });
passAt('A pure pointer PASS', '**CI/CD, container, or deployment change** (technique: `ci-cd`, `docker`)\n- Keep CI definitions in source control and never hide build or test failures.\n- Never apply production database migrations automatically from normal application startup.');
const lineOf = (file, prefix) => (sb) => read(sb, file).split(/\r?\n/).find((l) => l.startsWith(prefix));
for (const f of PLACES) pass('A pure pointer PASS', `${short(f)}: genuine code-review routing map`, (sb) => append(f, lineOf('.claude/skills/code-review/SKILL.md', 'Read the rule files whose')(sb))(sb));
for (const f of PLACES) pass('A pure pointer PASS', `${short(f)}: genuine build-fix footnote rule`, (sb) => append(f, lineOf('.claude/skills/build-fix/SKILL.md', 'Determine which contract is authoritative')(sb))(sb));

for (const text of ['Selected deployment technology: `docker`.', 'Selected deployment technology: Technique: `docker`.', 'Chosen deployment technology: Technique: `docker`.',
  'Configured deployment technology: Technique: `docker`.', 'Assigned deployment technology: Technique: `docker`.', 'Deployment technology is: Technique: `docker`.',
  'The deployment will run with: Technique: `docker`.', 'Technique: `docker`. This is the selected deployment technology.', 'Required deployment technology: Technique: `docker`.',
  'Default deployment: Technique: `docker`.', 'Preferred deployment technology: Containers -> `docker`.', 'Selected deployment technology -> `docker`.',
  'Technique: `docker`. Must use it for deployment.', '- Selected deployment technology:\n  - Technique: `docker`.', '- Required deployment technology:\n  - Containers -> `docker`.',
  'Selected technique: `docker`.', 'Technique: `docker`; it is the selected deployment technology.', '**Selected deployment technology** (technique: `docker`)',
  'This is the selected deployment technology. Technique: `docker`.', 'Selected container technology. Technique: `docker`.']) failAt('B selection/assignment FAIL', text);
for (const text of ['Selected API documentation tool: Technique: `swagger`.', 'Selected API documentation tool -> `swagger`.', '### Chosen API documentation tool\nTechnique: `swagger`.']) failAt('B selection/assignment FAIL', text, 'Swagger');

const TRANSFORMS = {
  t1: (L, H, X) => `${L}: ${H} ${X}.`, t2: (L, H, X) => `${L}:\n${H} ${X}.`, t3: (L, H, X) => `${L}:\n  ${H} ${X}.`, t4: (L, H, X) => `${L}:\n\n${H} ${X}.`,
  t5: (L, H, X) => `${L}:\n- ${H} ${X}.`, t6: (L, H, X) => `### ${L}\n${H} ${X}.`, t7: (L, H, X) => `### ${L}\n\n${H} ${X}.`, t8: (L, H, X) => `**${L}**\n\n${H} ${X}.`,
  t9: (L, H, X) => `${L}\n- ${H} ${X}.`, t10: (L, H, X) => `- ${L}:\n  - ${H} ${X}.`, t11: (L, H, X) => `- ${L}:\n  ${H} ${X}.`, t12: (L, H, X) => `- ${L}:\n${H} ${X}.`,
  t13: (L, H, X) => `${L}: ${H}\n${X}.`,
};
const POINTERS = [['label', 'Technique:', '`docker`'], ['arrow', 'Containers ->', '`docker`']];
for (const [lead, expect] of [['Selected deployment technology', 'FAIL'], ['Required deployment technology', 'FAIL'], ['Default deployment', 'FAIL'], ['Deployment technique', 'PASS']]) {
  const group = `C ${expect === 'FAIL' ? 'normative' : 'neutral'} "${lead}" (all forms ${expect})`;
  for (const f of PLACES) {
    const cases = [...POINTERS.flatMap(([kind, H, X]) => Object.entries(TRANSFORMS).map(([t, fn]) => [`${kind} ${t}`, fn(lead, H, X)])), ['t14 aside', `**${lead}** (technique: \`docker\`)`]];
    for (const [name, text] of cases) {
      if (expect === 'FAIL') fail(group, `${short(f)} ${name}: ${JSON.stringify(text)}`, append(f, text), f, tech(f, 'Docker'));
      else pass(group, `${short(f)} ${name}: ${JSON.stringify(text)}`, append(f, text));
    }
  }
}
for (const [lead, expect] of [['Selected API documentation tool', 'FAIL'], ['API documentation technique', 'PASS']]) {
  const group = `C swagger ${expect === 'FAIL' ? 'normative' : 'neutral'} "${lead}" (subset ${expect})`;
  for (const t of ['t1', 't2', 't6', 't10', 't13']) {
    const text = TRANSFORMS[t](lead, 'Technique:', '`swagger`');
    if (expect === 'FAIL') fail(group, `engineering.md ${t}: ${JSON.stringify(text)}`, append(L0, text), L0, tech(L0, 'Swagger')); else pass(group, `engineering.md ${t}: ${JSON.stringify(text)}`, append(L0, text));
  }
}

for (const [text, term] of [['Use DOCKER for deployment.', 'Docker'], ['Use swagger here.', 'Swagger'], ['Use kestrel for hosting.', 'Kestrel']]) failAt('D P1 case robustness', text, term);
for (const [text, mod] of [['Use nunit here.', 'backend-testing/nunit'], ['Use clean-architecture here.', 'architecture/clean-architecture']]) fail('D P1 case robustness', `${short(L2)}: ${text}`, append(L2, text), L2, new RegExp(`^VIOLATION ${esc(L2)}: names '[^']+' from module ${esc(mod)}`));
fail('D P2 frame location', 'boundaries.md: Use IHostedService here.', append(L1F, 'Use IHostedService here.'), L1F, /names 'IHostedService', which is not fixed-platform or stable-role or frame-manifest vocabulary/);
const termsLine = '- frame-terms: Domain, Application, Infrastructure, Api, IUnitOfWork, IGenericRepository, Application Services, AddApplication, AddInfrastructure, Persistence/';
for (const id of ['IHostedService', 'ControllerBase', 'DbContext', 'WebApplicationFactory', 'IQuantumLedgerBroker']) {
  fail('D P3 no legalizing', `frame-terms + ${id}; boundaries.md uses it`, all(replace(FRAME_MANIFEST, termsLine, `${termsLine}, ${id}`), append(L1F, `Use ${id} here.`)), FRAME_MANIFEST, new RegExp(`frame-terms lists code identifier '${id}', which the frame's own wording does not anchor`));
}
fail('D P3 no legalizing', 'placement-examples + IQuantumLedgerBroker; layout.md uses it', all(replace(FRAME_MANIFEST, 'TaskWorkflowService\n', 'TaskWorkflowService, IQuantumLedgerBroker\n'), append(LAYOUT, 'Use `IQuantumLedgerBroker` here.')), FRAME_MANIFEST, /placement-examples lists 'IQuantumLedgerBroker', which the placement facet does not place/);
for (const text of ['Technique: `docker` must be used for deployment.', 'Container deployment -> `docker` and it must be used.', 'Deployments must use containers (technique: `docker`).',
  'Technique: `docker`; it must be used for deployment.', '**Default:** Technique: `docker`.', 'Required deployment (technique: `docker`).', 'Mandatory deployment: Containers -> `docker`.']) failAt('D P4 earlier routing cases', text);
for (const text of ['Technique: `docker`\nmust be used for deployment.', '- Technique: `docker`\n  - must be used for deployment.', '- Technique: `docker`\n  must be used for deployment.',
  '### Technique: `docker`\nMust be used for deployment.', 'Containers -> `docker`\nmust be used for deployment.']) failAt('D P5 continuation forms', text);
for (const text of ['Deployment: Technique: `docker`.', 'Container or deployment change (technique: `docker`).', 'API documentation: Technique: `swagger`.', 'Technique: `docker`, `swagger` skills.',
  'Containers → `docker`.', 'Technique:\n`docker`.', 'See technique:\n`docker`.', '- Technique: `docker`.', 'Containers ->\n`docker`.']) passAt('D P6 earlier accepted pointers', text);
const efManifest = '.claude/capabilities/persistence/ef-core/MODULE.md';
const nunitManifest = '.claude/capabilities/backend-testing/nunit/MODULE.md';
const efBinds = /^- binds: architecture\/clean-architecture.*$/m;
const removeFrontend = ({ keepImport = false } = {}) => all(
  rm('.claude/rules/2-technology/frontend'), rm('.claude/rules/3-project/frontend-stack.md'), rm('.claude/capabilities/frontend/angular'), rm('.claude/skills/angular'),
  keepImport ? () => {} : replace('CLAUDE.md', '@.claude/rules/3-project/frontend-stack.md\n', ''),
  replace('.claude/rules/3-project/decisions.md', '| frontend | optional | angular | `angular` | Decided stack: imported frontend stack rule. |', '| frontend | optional | none | — | — |'),
  (sb) => {
    const gone = ['.claude/rules/2-technology/frontend/framework.md', '.claude/rules/3-project/frontend-stack.md', '.claude/capabilities/frontend/angular/', '.claude/skills/angular/SKILL.md'];
    write(sb, '.claude/INSTRUCTION_MAP.md', read(sb, '.claude/INSTRUCTION_MAP.md').split('\n').filter((l) => !gone.some((g) => l.includes(g))).join('\n').replace('; framework: `frontend/framework.md`; stack: `frontend-stack.md`', ''));
  },
  replace('.gitignore', '.angular/\n', ''));
fail('D capability / binds / frontend', 'extra slot directory', (sb) => write(sb, '.claude/capabilities/messaging/CONTRACT.md', '> Level: 1-architecture · Owns: x · Loading: never\n'), '.claude/capabilities/messaging', /extra slot/);
fail('D capability / binds / frontend', 'leaf uses frame terms with binds: none', (sb) => write(sb, efManifest, read(sb, efManifest).replace(efBinds, '- binds: none')), efManifest, /declares no "binds: architecture\/clean-architecture"/);
fail('D capability / binds / frontend', 'missing binds: line', replace(nunitManifest, '- binds: none\n', ''), nunitManifest, /missing "- binds:" line/);
fail('D capability / binds / frontend', 'leaf facet at Level 1', (sb) => write(sb, nunitManifest, read(sb, nunitManifest).replace(/\| 2-technology \|/, '| 1-architecture |')), nunitManifest, /leaf facet '[^']+' must be Level 2 or 3/);
fail('D capability / binds / frontend', 'leak token in another module', append('.claude/skills/ef-core/SKILL.md', 'Run NUnit here.'), '.claude/skills/ef-core/SKILL.md', /names 'NUnit' from module backend-testing\/nunit/);
pass('D capability / binds / frontend', 'optional frontend disabled (documented removal)', removeFrontend());
fail('D capability / binds / frontend', 'incomplete frontend removal (import kept)', removeFrontend({ keepImport: true }), 'CLAUDE.md', /import does not resolve/);
fail('D stability direction', 'L0 depends on Level 2 rule without label', append(L0, 'Follow `.claude/rules/2-technology/backend-libraries.md` for libraries.'), L0, /depends on less stable 2-technology/);
pass('D stability direction', 'L0 labeled routing pointer to Level 2 rule', append(L0, 'Technique: `.claude/rules/2-technology/backend-libraries.md`.'));
fail('D stability direction', 'header Level differs from directory', replace(L1, '> Level: 1-architecture', '> Level: 0-core'), L1, /does not match directory/);
pass('D D11/D12', 'D12: run from .claude/rules/0-core', () => {}, { cwd: '.claude/rules/0-core' });
pass('D D11/D12', 'D12: run from .claude/scripts', () => {}, { cwd: '.claude/scripts' });
fail('D D11/D12', 'D11: shell-string PreToolUse hook', json('.claude/settings.json', (s) => { s.hooks.PreToolUse[0].hooks[0].command = 'node .claude/hooks/pre-bash-dependency.mjs'; }), '.claude/settings.json', /exec form/);
fail('D D11/D12', 'D11: critical PreToolUse without onFailure block', json('.claude/settings.json', (s) => { delete s.hooks.PreToolUse[0].hooks[0].onFailure; }), '.claude/settings.json', /must set "onFailure": "block"/);

// ---- Runner ------------------------------------------------------------------------------------------
function run(fx, i, checkerOverride) {
  const sb = path.join(WORK, `sb-${i}`);
  rmSync(sb, { recursive: true, force: true });
  cpSync(T, sb, { recursive: true });
  if (checkerOverride) copyFileSync(checkerOverride, path.join(sb, CHECKER));
  let out = '';
  let status;
  try {
    fx.mutate(sb);
    const r = spawnSync('node', [path.join(sb, CHECKER)], { cwd: path.join(sb, fx.cwd || ''), env, encoding: 'utf8' });
    out = `${r.stdout}${r.stderr}`;
    status = r.status;
    if (!out.includes(`Instruction check of ${sb.replace(/\\/g, '/')}:`)) status = 'wrong-root';
    if (fx.slots) {
      const rows = read(sb, '.claude/rules/3-project/decisions.md').match(/^\| (architecture|persistence|backend-testing|frontend) \| [^|]+ \| ([a-z-]+) \|/gm) || [];
      if (rows.map((r2) => r2.split('|')[3].trim()).join(',') !== 'clean-architecture,ef-core,nunit,angular') status = 'slots';
    }
  } catch (error) { out = String(error.message); status = 'setup'; }
  rmSync(sb, { recursive: true, force: true });
  const violations = out.split('\n').filter((l) => l.startsWith('VIOLATION'));
  const summary = out.split('\n').find((l) => l.startsWith('Instruction check of')) || '';
  const actual = status === 0 && /0 violation\(s\), 0 warning\(s\)/.test(summary) ? 'PASS' : status === 1 ? 'FAIL' : `ERROR(${status})`;
  return { actual, violations, summary };
}

const report = {};
// 1. Bypass proof.
const unmodifiedSha = sha(readFileSync(UNMODIFIED));
report.bypassProof = { unmodifiedCheckerSha256: unmodifiedSha, verified: unmodifiedSha === UNMODIFIED_SHA, cases: [] };
BASELINE.forEach((fx, i) => { const r = run(fx, `b${i}`, UNMODIFIED); report.bypassProof.cases.push({ case: fx.id, unmodifiedChecker: r.actual, asRequired: r.actual === fx.unmodifiedMustBe }); });
const bypassOk = report.bypassProof.verified && report.bypassProof.cases.every((c) => c.asRequired);
// 2. Matrix.
const results = F.map((fx, i) => {
  const r = run(fx, i, null);
  const ok = fx.expect === 'PASS' ? r.actual === 'PASS'
    : r.actual === 'FAIL' && r.violations.some((v) => v.startsWith(`VIOLATION ${fx.file}`)) && (!fx.why || r.violations.some((v) => fx.why.test(v)));
  return { group: fx.group, id: fx.id, expect: fx.expect, actual: r.actual, ok, detail: ok ? undefined : (r.violations.slice(0, 3).join(' || ') || r.summary) };
});
const syntax = [];
const walk = (d) => readdirSync(d).forEach((e) => { const f = path.join(d, e); if (statSync(f).isDirectory()) walk(f); else if (f.endsWith('.mjs')) syntax.push(f); });
walk(path.join(T, '.claude'));
for (const f of syntax) { const ok = spawnSync('node', ['--check', f]).status === 0; results.push({ group: 'E syntax (node --check)', id: path.relative(T, f), expect: 'PASS', actual: ok ? 'PASS' : 'FAIL', ok }); }
const groups = {};
for (const r of results) { groups[r.group] ??= { pass: 0, total: 0 }; groups[r.group].total++; if (r.ok) groups[r.group].pass++; }
report.matrix = [...Object.entries(groups).map(([g, c]) => `${g}: ${c.pass}/${c.total}`), ...results.filter((r) => !r.ok).map((r) => `NOT OK [${r.group}] ${r.id} expected ${r.expect}, got ${r.actual}: ${r.detail}`), `TOTAL ${results.filter((r) => r.ok).length}/${results.length}`];
const matrixOk = results.every((r) => r.ok);
// 3. Gates.
const listAll = (d) => readdirSync(d).flatMap((e) => { const f = path.join(d, e); return statSync(f).isDirectory() ? listAll(f) : [f]; });
const rel = (f) => path.relative(T, f).split(path.sep).join('/');
const files = listAll(T).sort((a, b) => (rel(a) < rel(b) ? -1 : 1));
const inv = files.map((f) => `${sha(readFileSync(f))} *./${rel(f)}`);
const startText = readFileSync(path.join(WORK, 'start-inventory.txt'), 'utf8');
const start = new Map(startText.trim().split('\n').map((l) => [l.slice(66).trim(), l.slice(0, 64)]));
const now = new Map(inv.map((l) => [l.slice(66), l.slice(0, 64)]));
const g = {};
g.treeHash = sha(inv.map((l) => `${l}\n`).join(''));
g.startInventorySelfVerifies = sha(startText) === START_TREE;
g.files = files.length;
g.bytes = files.reduce((n, f) => n + statSync(f).size, 0);
g.changedFiles = [...now].filter(([f, h]) => start.get(f) !== h).map(([f]) => f);
g.addedOrRemoved = [...[...now.keys()].filter((f) => !start.has(f)), ...[...start.keys()].filter((f) => !now.has(f))];
g.unchanged = `${[...now].filter(([f, h]) => start.get(f) === h).length}/${files.length}`;
g.checkerSha256 = now.get(`./${CHECKER}`);
const ENFORCEMENT = ['./.claude/hooks/pre-bash-dependency.mjs', './.claude/hooks/post-change-checks.mjs', './.claude/hooks/stop-cochange.mjs', './.claude/hooks/manifest-policy.json',
  './.claude/settings.json', './.claude/scripts/lib/project.mjs', './.claude/scripts/check-architecture.mjs', ...[...now.keys()].filter((f) => f.startsWith('./.claude/capabilities/') && f.endsWith('.json'))];
g.enforcementIdentical = `${ENFORCEMENT.filter((f) => start.get(f) === now.get(f)).length}/${ENFORCEMENT.length}`;
const cenv = { ...process.env, GIT_CEILING_DIRECTORIES: path.join(WS, 'output').replace(/\\/g, '/') };
delete cenv.CLAUDE_PROJECT_DIR;
const ci = spawnSync('node', [path.join(T, CHECKER)], { cwd: T, env: cenv, encoding: 'utf8' });
g.instructionCheck = { exit: ci.status, summary: ci.stdout.trim().split('\n').pop() };
const ca = spawnSync('node', [path.join(T, '.claude/scripts/check-architecture.mjs')], { cwd: T, env: cenv, encoding: 'utf8' });
g.architectureCheck = { exit: ca.status, summary: `${ca.stdout}${ca.stderr}`.trim().split('\n').pop() };
const docs = new Map(files.filter((f) => f.endsWith('.md')).map((f) => [rel(f), readFileSync(f, 'utf8').replace(/\r\n/g, '\n')]));
const RESIDUAL = /\bcontrollers?\b|controllerbase|apicontroller|kestrel|minimal apis?\b|asp\.net core identity|data protection|dbcontext|webapplicationfactory|ihostedservice|\bserilog\b|\bredis\b|\bdapper\b|\bef core\b|\bhangfire\b|\borleans\b|\bdapr\b|\bnunit\b|\bangular\b/i;
g.level01ResidualHits = [...docs].filter(([, t]) => /^> Level: (0-core|1-architecture)/m.test(t)).flatMap(([f, t]) => t.split('\n').filter((l) => RESIDUAL.test(l)).map((l) => `${f}: ${l.slice(0, 80)}`));
const inventory = JSON.parse(readFileSync(path.join(WS, 'source', 'inventory.json'), 'utf8'));
const shared = JSON.parse(readFileSync(path.join(WS, 'source', 'shared-research-invariants.json'), 'utf8'));
const policies = [...inventory.policygroups.flatMap((x) => x.policies), ...shared.invariants];
const imports = [...docs.get('CLAUDE.md').matchAll(/^@(\S+)\s*$/gm)].map((m) => m[1]);
const trigger = (o) => (o === 'CLAUDE.md' || imports.includes(o) ? 'always' : o.startsWith('.claude/rules/') ? 'path'
  : /Loading: (on invocation|on delegation|read by|user)/.test((docs.get(o) || '').split('\n').find((l) => l.startsWith('> Level:')) || '') ? 'workflow' : 'other');
const globs = (o) => { const m = (docs.get(o) || '').match(/^---\n([\s\S]*?)\n---/); return m ? [...m[1].matchAll(/-\s+"([^"]+)"/g)].map((x) => x[1]) : []; };
const COVER = { common: ['**/*'], 'repo/meta': ['**/*'], backend: ['**/*', 'backend/**/*'], 'backend-tests': ['**/*', 'backend/**/*', 'backend/**/*Tests/**/*'], frontend: ['**/*', 'frontend/**/*'] };
const problems = [];
const pol = { total: policies.length, owners: 0, ownerRegressions: 0, triggerDeltas: 0, scopeMisses: 0, duplicates: 0 };
for (const p of policies) {
  const e = OWNERS[p.id];
  if (!e) { pol.ownerRegressions++; problems.push(`${p.id}: no owner`); continue; }
  const [o, phrase] = e;
  const hits = [...docs].filter(([, t]) => t.includes(phrase)).map(([f]) => f);
  if (hits.includes(o)) pol.owners++; else { pol.ownerRegressions++; problems.push(`${p.id}: phrase not in ${o}`); }
  if (hits.length > 1) { pol.duplicates++; problems.push(`${p.id}: duplicate`); }
  if (trigger(o) !== p.trigger_class) { pol.triggerDeltas++; problems.push(`${p.id}: trigger`); }
  if (trigger(o) === 'path' && !globs(o).some((x) => COVER[p.scope].includes(x))) { pol.scopeMisses++; problems.push(`${p.id}: scope`); }
}
g.policies = pol;
g.brokenReferences = /path reference does not resolve|import does not resolve|references unknown skill|facet reference/.test(ci.stdout) ? 'present' : 0;
const HYGIENE = [/[Ѐ-ӿ一-鿿]/, /\b(GOV|ARC|PST|API|TST|SEC|RUN|DEP|FE|WF|EXC)-\d{3}\b/, /\b(L0|L1|K0|K1|Run-0\d|benchmark|research|replicate)\b/,
  /TASK\.md|CANDIDATE\.md|GENERATION_REPORT|REFINEMENT_|DEFECT_DOSSIER|inventory\.json|v2-baseline|iteration[ -]?[1-7]\b|corrective pass|metamorphic/i, /claude-(opus|sonnet|haiku|fable)/, /[A-Z]:\\(Users|Projects)|\/c\/Projects|AI Learning/];
g.hygieneFindings = files.flatMap((f) => readFileSync(f, 'utf8').split('\n').filter((l) => HYGIENE.some((re) => re.test(l))).map((l) => `${rel(f)}: ${l.slice(0, 80)}`));
let chars = docs.get('CLAUDE.md').length;
for (const imp of imports) chars += docs.get(imp).length;
for (const sk of readdirSync(path.join(T, '.claude', 'skills'))) {
  const fm = docs.get(`.claude/skills/${sk}/SKILL.md`).split('\n---')[0];
  if (!/disable-model-invocation:\s*true/.test(fm)) chars += sk.length + ((fm.match(/^description:\s*(.+)$/m) || [])[1] || '').length + 4;
}
for (const a of readdirSync(path.join(T, '.claude', 'agents'))) chars += a.length + ((docs.get(`.claude/agents/${a}`).match(/^description:\s*(.+)$/m) || [])[1] || '').length + 4;
g.alwaysLoaded = { chars, tokens: Math.round(chars / 4), imports: imports.length };
report.gates = g;
report.problems = problems;
const gatesOk = g.startInventorySelfVerifies && g.files === 86 && g.changedFiles.length === 1 && g.changedFiles[0] === `./${CHECKER}` && g.addedOrRemoved.length === 0
  && g.enforcementIdentical === `${ENFORCEMENT.length}/${ENFORCEMENT.length}` && ci.status === 0 && /PASS \(67 artifacts, 0 violation\(s\), 0 warning\(s\)\)/.test(g.instructionCheck.summary)
  && ca.status === 0 && g.level01ResidualHits.length === 0 && problems.length === 0 && pol.owners === 196 && g.brokenReferences === 0 && g.hygieneFindings.length === 0 && chars === 20581;
report.result = bypassOk && matrixOk && gatesOk ? 'CLEAN: bypass reproduced on the unmodified checker; matrix and every gate green' : `NOT CLEAN (bypassProof ${bypassOk}, matrix ${matrixOk}, gates ${gatesOk})`;
console.log(JSON.stringify(report, null, 1));
process.exit(bypassOk && matrixOk && gatesOk ? 0 : 1);
