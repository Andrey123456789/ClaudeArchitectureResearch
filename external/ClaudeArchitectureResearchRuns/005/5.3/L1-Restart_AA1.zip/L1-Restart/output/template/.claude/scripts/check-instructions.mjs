#!/usr/bin/env node
// Instruction-structure checker for the level-first instruction system with replaceable capabilities.
// Validates: headers and levels, rule paths, conformance direction, capability selection, slot contracts,
// module manifests (facets, binds, leak tokens, frame terms), facet ownership, always-loaded imports,
// implementation-name leakage, Core/Architecture technology neutrality, references, required
// workflows/knowledge, agent, hook registrations, map coverage.
// Usage (from any directory of the project or a linked worktree):
//   node "$(git rev-parse --show-toplevel)/.claude/scripts/check-instructions.mjs"   (exit 1 on violations, 2 on setup errors)
import { existsSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { listFiles, parseSelection, readText, resolveRoot, toPosix } from './lib/project.mjs';

const LEVELS = ['0-core', '1-architecture', '2-technology', '3-project'];
const SLOTS = { architecture: 'required frame', persistence: 'required leaf', 'backend-testing': 'required leaf', frontend: 'optional leaf' };
const REQUIRED_WORKFLOWS = ['development-workflow', 'project-structure', 'verify', 'code-review', 'build-fix', 'custom-settings',
  'git-workflow', 'security-scan', 'add-dependency', 'architecture-decision', 'template-maintenance'];
const REQUIRED_SHARED_KNOWLEDGE = ['http-api', 'aspnet-error-handling', 'logging', 'httpclient-factory', 'configuration',
  'dependency-injection', 'caching', 'swagger', 'api-versioning', 'health-check', 'docker', 'ci-cd', 'modern-csharp', 'authentication'];
const LEAK_ALLOWED = new Set(['.claude/rules/3-project/decisions.md', '.claude/INSTRUCTION_MAP.md']);

// Core/Architecture neutrality. The fixed platform vocabulary is .NET, C#, ASP.NET Core, NuGet, HTTP, Git (names,
// their CLIs, protocol vocabulary, vendor-neutral standards). Everything below is technology for Levels 0/1.
// Detection does not rely on this lexicon alone: technique-skill names, leaf-module leak tokens and package ids
// are derived from the template, and API-shaped identifiers are denied by default.
const TECHNOLOGY_LEXICON = ['Docker', 'Dockerfile', 'Docker Compose', 'Kubernetes', 'Swagger', 'Swashbuckle', 'OpenAPI', 'NSwag',
  'Serilog', 'NLog', 'log4net', 'FluentValidation', 'Mapster', 'AutoMapper', 'MediatR', 'Kommand', 'Polly', 'Testcontainers',
  'xUnit', 'MSTest', 'TUnit', 'Moq', 'NSubstitute', 'FluentAssertions', 'Playwright', 'Redis', 'RabbitMQ', 'Kafka',
  'MassTransit', 'Hangfire', 'Dapper', 'PostgreSQL', 'Npgsql', 'MySQL', 'SQLite', 'MongoDB', 'Elasticsearch', 'GitHub Actions',
  'Azure', 'AWS', 'TypeScript', 'JavaScript', 'npm', 'pnpm', 'yarn', 'Node.js', 'Blazor', 'SignalR', 'gRPC', 'GraphQL', 'nginx',
  'Kestrel', 'curl', 'PowerShell', 'Minimal API', 'Minimal APIs', 'controller', 'controllers', 'ASP.NET Core Identity',
  'ASP.NET Core Data Protection', 'Data Protection API', 'IExceptionHandler', 'ProblemDetails', 'ValidationProblemDetails',
  'IActionResult', 'ActionResult', 'IResult', 'WebApplicationFactory', 'HttpClient', 'IHttpClientFactory', 'HttpResponseMessage',
  'ILogger', 'TimeProvider', 'IConfiguration', 'IOptions', 'CancellationToken', 'ValueTask', 'DbContext', 'DbSet', 'IQueryable'];
const PLATFORM_IDENTIFIERS = new Set(['NuGet']);
const MODALITY = new Set(('must shall should required require requires requiring requirement requirements mandatory need needs needed '
  + 'selected select selects selection chosen choose choice default defaults preferred prefer prefers preference use uses used using '
  + 'adopt adopts adopted approved approve decided decide decision standard always never only recommended recommend assigned assign '
  + 'primary baseline official mandated enforce enforced pick picked').split(' '));
const REFERENTIAL = /\b(?:this|that|these|those|said|the\s+(?:above|below|following|preceding|previous|listed|referenced))\s+(?:[\w-]+\s+){0,2}?(?:technique|techniques|technology|technologies|tool|tools|skill|skills|reference|references|approach|option|one)\b|\b(?:technique|techniques|technology|tool|skill|reference)\s+(?:above|below)\b/i;
// The same reference used as a bare pronoun (no head noun): a clause-initial subject before a finite verb
// ("This is the selected ...", "Thus, it must be used ..."), or, elsewhere in the clause, it/them or a determiner
// standing alone before punctuation or a preposition ("use it for ...", "must use this.").
const DEMONSTRATIVE = 'this|that|these|those|the\\s+(?:above|preceding|previous|following)|below';
const PRONOUN_SUBJECT = new RegExp(`^\\W*(?:[a-z-]+(?:\\s+[a-z-]+){0,3}[,:]\\s*)?(?:(?:and|but|so|thus|hence|therefore|then)\\s+)?(?:${DEMONSTRATIVE}|it|they)(?:\\s+(?:is|are|was|were|will|would|shall|should|must|may|might|can|could|has|have|had|needs|remains|becomes|stays)\\b|['\\u2019]s\\b)`, 'i');
const PRONOUN_OTHER = new RegExp(`\\b(?:it|them)\\b|\\b(?:${DEMONSTRATIVE})(?=\\s*(?:[.,;:!?)]|$)|\\s+(?:for|as|in|on|at|by|with|to|from|over|instead)\\b)`, 'gi');

const violations = [];
const warnings = [];
const fail = (file, msg) => violations.push(`${file}: ${msg}`);
const warn = (file, msg) => warnings.push(`${file}: ${msg}`);
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const wordRe = (token, flags = 'i') => new RegExp(`(?<![A-Za-z0-9-])${esc(token)}(?![A-Za-z0-9-])`, flags);

function splitFrontmatter(text) {
  const normalized = text.replace(/\r\n/g, '\n');
  if (!normalized.startsWith('---\n')) return { fm: '', body: normalized };
  const end = normalized.indexOf('\n---', 4);
  if (end < 0) return { fm: '', body: normalized };
  return { fm: normalized.slice(4, end), body: normalized.slice(end + 4) };
}

function parseHeader(body) {
  const line = body.split('\n').find((l) => l.trim() !== '') || '';
  if (!line.startsWith('> Level: ')) return null;
  const fields = {};
  for (const part of line.slice(2).split(' · ')) {
    const idx = part.indexOf(':');
    if (idx > 0) fields[part.slice(0, idx).trim()] = part.slice(idx + 1).trim();
  }
  return fields;
}

// ---------- Markdown blocks with governors (bounded structure: headings, paragraphs, list items, rows, code) ----------

function parseBlocks(body) {
  const blocks = [];
  const headings = [];
  let para = null;
  let list = null; // { items, leadIn }
  let item = null;
  let fence = null;
  let blankRun = 0;
  let lastPara = null;
  const lines = body.split('\n');
  for (let n = 0; n < lines.length; n++) {
    const line = lines[n];
    if (fence) {
      fence.text += `\n${line}`;
      if (/^\s*```/.test(line)) fence = null;
      continue;
    }
    if (/^\s*```/.test(line)) {
      para = null; item = null;
      fence = { type: 'code', text: line, headings: [...headings], ancestors: [] };
      blocks.push(fence);
      continue;
    }
    if (line.trim() === '') { para = null; blankRun++; continue; }
    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      para = null; item = null; list = null; lastPara = null;
      const level = heading[1].length;
      while (headings.length && headings[headings.length - 1].level >= level) headings.pop();
      const h = { type: 'heading', level, text: heading[2], headings: [...headings], ancestors: [] };
      blocks.push(h);
      headings.push(h);
      blankRun = 0;
      continue;
    }
    if (/^\s*\|/.test(line)) {
      para = null; item = null; list = null;
      blocks.push({ type: 'row', text: line, headings: [...headings], ancestors: [] });
      blankRun = 0;
      continue;
    }
    const li = line.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);
    if (li) {
      const indent = li[1].length;
      if (!list) {
        const lead = lastPara && (blankRun === 0 || /:\s*$/.test(lastPara.text)) ? lastPara : null;
        list = { items: [], leadIn: lead };
      }
      const parent = [...list.items].reverse().find((x) => x.indent < indent) || null;
      const ancestors = [];
      for (let p = parent; p; p = p.parent) ancestors.unshift(p);
      if (!parent && list.leadIn) ancestors.unshift(list.leadIn);
      item = { type: 'item', text: li[2], indent, parent, list, ancestors, headings: [...headings] };
      list.items.push(item);
      blocks.push(item);
      para = null; lastPara = null; blankRun = 0;
      continue;
    }
    if (item && /^\s+\S/.test(line) && (blankRun === 0 || /^\s{2,}/.test(line))) { // list-item continuation (form 4)
      item.text += ` ${line.trim()}`;
      blankRun = 0;
      continue;
    }
    if (para && blankRun === 0) { para.text += ` ${line.trim()}`; continue; } // wrapped paragraph (form 6)
    item = null;
    if (blankRun > 0 || !list) list = null;
    para = { type: 'para', text: line.replace(/^>\s?/, '').trim(), headings: [...headings], ancestors: [] };
    blocks.push(para);
    lastPara = para;
    blankRun = 0;
  }
  return blocks;
}

// Inline code spans are masked so sentence splitting and pointer forms see them as atoms.
function maskCode(text) {
  const spans = [];
  const masked = text.replace(/`([^`]+)`/g, (_, c) => { spans.push(c); return `\u0001${spans.length - 1}\u0002`; });
  return { masked, spans };
}

function sentencesOf(masked) {
  return masked.replace(/\b(e\.g|i\.e|etc|vs)\./gi, '$1\u0003').split(/(?<=[.!?])\s+(?=\S)/).map((s) => s.replace(/\u0003/g, '.'));
}

const words = (s) => s.toLowerCase().replace(/\u0001\d+\u0002/g, ' ').match(/[a-z]+/g) || [];
const hasModality = (s) => words(s).some((w) => MODALITY.has(w));
const plain = (s) => s.replace(/[*_]/g, '').replace(/\s+/g, ' ').trim().replace(/[:.]\s*$/, '').trim();

// Reference label: technique(s) | reference(s) | see | see also | route map | routing, optionally with topic words.
function referenceLabel(text) {
  const t = plain(text).toLowerCase();
  if (/\u0001/.test(t) || hasModality(t)) return null;
  if (/^(?:see|see also|route map|routing|(?:see\s+)?(?:technique|techniques|reference|references))$/.test(t)) return 'generic';
  if (/^(?:see\s+)?(?:[a-z0-9/&+-]+\s+){1,6}(?:technique|techniques|reference|references|route map)$/.test(t)) return 'topic';
  return null;
}

const REF = '\u0001(\\d+)\u0002(?:\\s+skills?)?';
const REFS = new RegExp(`^${REF}(?:\\s*(?:,|/|\\band\\b|\\bor\\b|,\\s*and)\\s*${REF})*$`, 'i');
const refIndexes = (s) => [...s.matchAll(/\u0001(\d+)\u0002/g)].map((m) => Number(m[1]));

// Returns { idx:Set, generic, lead } when the clause is a pure pointer, else null.
function pointerForm(clause) {
  const c = clause.trim().replace(/[.]\s*$/, '').trim();
  const aside = c.match(/\(\s*((?:see\s+)?(?:technique|techniques|reference|references)\s*:\s*[^()]*|see\s+[^()]*)\)/i);
  if (aside) {
    const inner = aside[1].replace(/^(?:see\s+)?(?:technique|techniques|reference|references)\s*:\s*|^see\s+/i, '');
    const anchor = c.replace(aside[0], ' ');
    if (REFS.test(inner.trim()) && !hasModality(anchor)) return { idx: new Set(refIndexes(inner)), kind: 'aside' };
  }
  let m = c.match(/^(.*?)(?:→|->)\s*(.+)$/);
  if (m && REFS.test(m[2].trim())) {
    const area = plain(m[1]);
    if (area && area.split(' ').length <= 6 && !/[\u0001:]/.test(area) && !hasModality(area)) return { idx: new Set(refIndexes(m[2])), kind: 'route' };
    if (!area.includes(':')) return null;
  }
  m = c.match(/^see(?:\s+also)?\s+(.+)$/i);
  if (m && REFS.test(m[1].trim())) return { idx: new Set(refIndexes(m[1])), kind: 'label', generic: true };
  const parts = c.split(':');
  if (parts.length >= 2) {
    const value = parts[parts.length - 1].trim();
    const label = parts[parts.length - 2];
    const kind = referenceLabel(label);
    if (kind && REFS.test(value)) {
      if (parts.length === 2) return { idx: new Set(refIndexes(value)), kind: 'label', generic: kind === 'generic' };
      if (parts.length === 3 && referenceLabel(parts[0])) return { idx: new Set(refIndexes(value)), kind: 'lead' };
      return { idx: new Set(), kind: 'governed-by-non-reference-lead' };
    }
    // Same-line lead before a self-governed pointer (route entry or self-describing label): the lead must not be normative.
    const lead = parts[0];
    const rest = c.slice(lead.length + 1).trim();
    const inner = rest ? pointerForm(rest) : null;
    if (inner && inner.idx.size && inner.kind !== 'lead' && !inner.generic) {
      return hasModality(lead) ? { idx: new Set(), kind: 'governed-by-non-reference-lead' } : { ...inner, kind: 'led' };
    }
  }
  return null;
}

function isReferenceGovernor(g) {
  return !!g && !!referenceLabel(g.type === 'item' || g.type === 'para' ? g.text.replace(/`[^`]*`/g, '') : g.text);
}

const clausesOf = (sentence) => sentence.split(/\s*;\s*|\s+·\s+/);

// A clause with modality and a bare pronoun asserts the selection or requirement of what the pronoun refers to.
// Returns the pointers it binds: 'all' for a clause-initial subject (no antecedent inside its clause, so any
// pointer of the block or its siblings may be meant), otherwise 'back' (pointers before it) or 'forward'
// (`the following`, `below`). No antecedent is chosen: every candidate loses the exemption.
function pronominalBinding(clause) {
  if (!hasModality(clause)) return [];
  if (PRONOUN_SUBJECT.test(clause)) return ['all'];
  return [...clause.matchAll(PRONOUN_OTHER)].map((m) => (/following|below/i.test(m[0]) ? 'forward' : 'back'));
}

// P4: decide for every backticked technique-skill reference whether it is a pure non-normative pointer.
function techniquePointerViolations(block, techSkills) {
  const { masked, spans } = maskCode(block.text);
  const results = []; // { token, masked, reason }
  const refsInBlock = spans.map((s, i) => ({ s, i })).filter(({ s }) => techSkills.has(s));
  if (refsInBlock.length === 0) return results;
  const governors = [...block.headings, ...block.ancestors];
  const poisoned = governors.find((g) => hasModality(g.text.replace(/`[^`]*`/g, '')));
  const siblings = block.type === 'item' ? block.list.items.filter((x) => x !== block && x.parent === block.parent) : [];
  const bound = [...sentencesOf(masked), ...siblings.map((s) => s.text), ...block.ancestors.map((a) => a.text)].some((t) => REFERENTIAL.test(t));
  const sentences = sentencesOf(masked);
  // Pronominal assertions in reading order: earlier sibling items, the clauses of this block, later sibling items.
  const own = sentences.flatMap(clausesOf);
  const earlier = (x) => block.list.items.indexOf(x) < block.list.items.indexOf(block);
  const siblingClauses = (before) => siblings.filter((x) => earlier(x) === before).flatMap((x) => sentencesOf(maskCode(x.text).masked).flatMap(clausesOf));
  const binders = [...siblingClauses(true).map((t) => [t, -1]), ...own.map((t, pos) => [t, pos]), ...siblingClauses(false).map((t) => [t, own.length])]
    .flatMap(([t, pos]) => pronominalBinding(t).map((dir) => ({ dir, pos })));
  for (const { s, i } of refsInBlock) {
    const sentence = sentences.find((x) => x.includes(`\u0001${i}\u0002`)) || '';
    const clauses = clausesOf(sentence);
    const ci = clauses.findIndex((x) => x.includes(`\u0001${i}\u0002`));
    const form = pointerForm(clauses[ci] || '');
    const at = own.findIndex((x) => x.includes(`\u0001${i}\u0002`));
    let reason = null;
    if (!form || !form.idx.has(i)) reason = form && form.kind === 'governed-by-non-reference-lead' ? 'pointer governed by a non-reference label' : 'not a pure technique pointer';
    else if (poisoned) reason = `governed by normative/selection context '${plain(poisoned.text).slice(0, 60)}'`;
    else if (bound) reason = 'bound by a referential obligation in the same block or sibling items';
    else if (binders.some((b) => b.dir === 'all' || (b.dir === 'back' ? b.pos > at : b.pos < at))) reason = 'bound by a pronominal selection or requirement in the same block or sibling items';
    else if (clauses.length > 1 && ci > 0 && clauses[0].includes(':')) {
      const lead = clauses[0].slice(0, clauses[0].indexOf(':'));
      if (hasModality(lead)) reason = 'series lead-in is normative';
      else if (form.generic && !referenceLabel(lead)) reason = 'generic pointer under a non-reference series lead-in';
    }
    if (!reason && form.generic && block.type === 'item') {
      const nearest = block.parent || block.list.leadIn || block.headings[block.headings.length - 1];
      if (!isReferenceGovernor(nearest)) reason = `generic technique pointer in a list governed by '${nearest ? plain(nearest.text).slice(0, 60) : 'nothing'}', which is not a technique-reference label`;
    }
    results.push({ token: s, index: i, masked: !reason, reason });
  }
  return results;
}

const API_SHAPES = [
  /\bI[A-Z][a-z0-9]+[A-Za-z0-9]*\b/g,
  /\b[A-Za-z_][A-Za-z0-9_]*<[A-Za-z0-9_, ]+>/g,
  /\[[A-Z][a-z]+[A-Za-z0-9]*(?:\([^)\]]*\))?\](?!\()/g,
  /(?<![\w.])\.[A-Z][a-z][A-Za-z0-9]*(?:\(\))?/g,
  /\b[A-Za-z_][A-Za-z0-9_]*\(\)/g,
  /\b[A-Z][A-Za-z0-9]*\.[A-Z][a-z][A-Za-z0-9]*\b/g,
  /\b[A-Z][a-z0-9]+(?:[A-Z][a-z0-9]*)+[A-Za-z0-9]*\b/g,
  /\b[a-z][a-z0-9]*[A-Z][A-Za-z0-9]*\b/g,
];

// Words that are paths, file names, placeholders or naming-convention examples are not API identifiers.
function stripNonIdentifiers(text) {
  return text.split(/(\s+)/).map((tok) => {
    const t = tok.replace(/^[`("'[]+|[`)"'\],.;:!?]+$/g, '');
    if (/^https?:\/\//.test(t) || /\//.test(t) || /(^|[^A-Za-z0-9_])<[A-Za-z-]+>/.test(t) || /_/.test(t)
      || /\.(cs|csproj|json|md|mjs|props|slnx|sln|ts|ya?ml|xml|config|sql|editorconfig|gitignore)$/i.test(t)) return ' '.repeat(tok.length);
    return tok;
  }).join('');
}

function neutralityCheck(p, d, ctx) {
  const blocks = parseBlocks(d.body);
  const description = (d.fm.match(/^description:\s*(.+)$/m) || [])[1];
  if (description) blocks.push({ type: 'para', text: description, headings: [], ancestors: [] });
  const reported = new Set();
  const report = (token, why) => {
    const key = token.toLowerCase();
    if (reported.has(key)) return;
    reported.add(key);
    fail(p, `Level ${d.header.Level} names concrete technology '${token}' (${why}); keep neutral policy here and move the technique to Level 2 or the owning capability facet`);
  };
  // Every block is checked for its own technology tokens, headings included: a heading is a same-line statement
  // like any other (e.g. "## Must use Swagger"). Its separate role as governing context for the blocks below it is
  // unchanged (parseBlocks records it in each descendant's `headings`).
  for (const block of blocks) {
    let text = block.text;
    const pointers = techniquePointerViolations(block, ctx.techSkills);
    const { spans } = maskCode(text);
    for (const r of pointers) if (!r.masked) report(r.token, r.reason);
    const maskedIdx = new Set(pointers.filter((r) => r.masked).map((r) => r.index));
    let k = -1;
    text = text.replace(/`([^`]+)`/g, (all, c) => { k += 1; return maskedIdx.has(k) ? ' ' : ` ${c} `; });
    for (const term of ctx.vocabulary) if (wordRe(term).test(text)) report(text.match(wordRe(term))[0], 'technology vocabulary');
    const ids = stripNonIdentifiers(text);
    for (const re of API_SHAPES) {
      for (const m of ids.matchAll(re)) {
        const id = m[0].replace(/^\./, '').replace(/\(\)$/, '');
        const base = id.replace(/<.*$/, '');
        if (PLATFORM_IDENTIFIERS.has(base)) continue;
        if (ctx.frameOwned(p) && id.split('.').every((seg) => ctx.frameTerms.has(seg) || ctx.frameTerms.has(seg.replace(/<.*$/, '')))) continue;
        if (ctx.frameOwned(p) && (ctx.frameTerms.has(id) || ctx.frameTerms.has(base))) continue;
        report(m[0], 'API-shaped identifier outside the platform vocabulary');
      }
    }
    void spans;
  }
}

function main() {
  const root = resolveRoot();
  const rel = (abs) => toPosix(path.relative(root, abs));
  const exists = (p) => existsSync(path.join(root, p));
  const claude = path.join(root, '.claude');

  const artifactPaths = [
    'CLAUDE.md',
    '.claude/INSTRUCTION_MAP.md',
    ...['rules', 'skills', 'agents', 'capabilities'].flatMap((d) => listFiles(path.join(claude, d), (f) => f.endsWith('.md')).map(rel)),
  ].filter((p) => exists(p));
  const docs = new Map();
  for (const p of artifactPaths) {
    const text = readText(path.join(root, p), p);
    const { fm, body } = splitFrontmatter(text);
    docs.set(p, { text, fm, body, header: parseHeader(body) });
  }
  const levelOf = (p) => { const d = docs.get(p); return d && d.header ? LEVELS.indexOf(d.header.Level) : -1; };

  // Headers.
  for (const [p, d] of docs) {
    if (!d.header) { fail(p, 'missing one-line header starting with "> Level: "'); continue; }
    if (!LEVELS.includes(d.header.Level)) fail(p, `unknown Level '${d.header.Level}'`);
    if (!d.header.Owns) fail(p, 'header lacks "Owns:"');
    if (!d.header.Loading) fail(p, 'header lacks "Loading:"');
    if ('Kind' in d.header) fail(p, 'header uses a "Kind:" field; classify by Level and Capability only');
  }

  // Selection record, slot directories, slot contracts.
  const selection = parseSelection(root);
  const selected = {};
  const capDir = path.join(claude, 'capabilities');
  const slotDirs = existsSync(capDir) ? readdirSync(capDir).filter((e) => statSync(path.join(capDir, e)).isDirectory()) : [];
  for (const dir of slotDirs) if (!(dir in SLOTS)) fail(`.claude/capabilities/${dir}`, `unknown capability slot directory (only the four agreed slots exist: ${Object.keys(SLOTS).join(', ')})`);
  const contracts = {};
  for (const [slot, kind] of Object.entries(SLOTS)) {
    const row = selection.find((r) => r.slot === slot);
    if (!row) { fail('.claude/rules/3-project/decisions.md', `selection record lacks slot '${slot}'`); continue; }
    const requirement = kind.startsWith('required') ? (slot === 'architecture' ? 'required frame' : 'required') : 'optional';
    if (row.requirement !== requirement) fail('.claude/rules/3-project/decisions.md', `slot '${slot}' must be recorded as '${requirement}' (found '${row.requirement}')`);
    if (kind.startsWith('required') && !row.selected) fail('.claude/rules/3-project/decisions.md', `required slot '${slot}' has no selected implementation`);
    selected[slot] = row.selected;
    const slotDir = path.join(capDir, slot);
    const contractPath = `.claude/capabilities/${slot}/CONTRACT.md`;
    const contract = docs.get(contractPath);
    if (!contract) fail(`.claude/capabilities/${slot}`, 'missing CONTRACT.md');
    else {
      if (!new RegExp(`^# Slot Contract: ${esc(slot)} \\(${esc(kind)}\\)`, 'm').test(contract.body)) fail(contractPath, `title must declare the slot as '${kind}'`);
      const required = [...contract.body.matchAll(/^\|\s*(?:`([a-z-]+\.[a-z-]+)`|(knowledge skill))\s*\|/gm)].map((m) => m[1] || `${slot}.knowledge`);
      const requiresBinds = (contract.body.match(/^- requires-binds:\s*(\S+)/m) || [])[1] || null;
      contracts[slot] = { path: contractPath, required, requiresBinds };
    }
    const impls = existsSync(slotDir) ? readdirSync(slotDir).filter((e) => statSync(path.join(slotDir, e)).isDirectory()) : [];
    const expected = row.selected ? [row.selected] : [];
    if (impls.sort().join(',') !== expected.join(',')) {
      fail(`.claude/capabilities/${slot}`, `implementations present [${impls.join(', ')}] differ from selection [${expected.join(', ')}] (static composition: only selected modules ship)`);
    }
  }
  for (const row of selection) if (!(row.slot in SLOTS)) fail('.claude/rules/3-project/decisions.md', `unknown slot '${row.slot}' (only the four agreed slots exist)`);

  // Module manifests.
  const modules = [];
  for (const [slot, impl] of Object.entries(selected)) {
    if (!impl) continue;
    const manifestPath = `.claude/capabilities/${slot}/${impl}/MODULE.md`;
    const doc = docs.get(manifestPath);
    if (!doc) { fail(manifestPath, 'missing module manifest'); continue; }
    const capability = `${slot}/${impl}`;
    const line = (key) => (doc.body.match(new RegExp(`^- ${key}:\\s*(.+)$`, 'm')) || [])[1];
    const facets = [...doc.body.matchAll(/^\|\s*`([a-z-]+\.[a-z-]+)`\s*\|\s*`([^`]+)`\s*\|\s*([a-z0-9-]+)\s*\|/gm)]
      .map((m) => ({ facet: m[1], file: m[2], level: m[3] }));
    if (!line('leak-tokens')) fail(manifestPath, 'missing "- leak-tokens:" line');
    if (!line('binds')) fail(manifestPath, 'missing "- binds:" line (use "none" when the module needs no frame-specific binding)');
    if (facets.length === 0) fail(manifestPath, 'facet table is empty or malformed');
    if (doc.header && doc.header.Capability !== capability) fail(manifestPath, `header Capability must be '${capability}'`);
    const tokens = (line('leak-tokens') || '').split(',').map((t) => t.trim()).filter(Boolean);
    const list = (key) => (line(key) || '').split(',').map((t) => t.trim()).filter(Boolean);
    const frameTerms = slot === 'architecture' ? list('frame-terms') : [];
    const placementExamples = slot === 'architecture' ? list('placement-examples') : [];
    if (slot === 'architecture' && frameTerms.length === 0) fail(manifestPath, 'frame manifest lacks "- frame-terms:" (role-realization and placement names its Level 1 facets use)');
    for (const f of facets) {
      if (!f.facet.startsWith(`${slot}.`)) fail(manifestPath, `facet '${f.facet}' does not belong to slot '${slot}'`);
      if (!exists(f.file)) { fail(manifestPath, `facet file missing: ${f.file}`); continue; }
      if (f.file.endsWith('.md')) {
        const fd = docs.get(f.file);
        if (fd && fd.header) {
          if (fd.header.Capability !== capability) fail(f.file, `must declare "Capability: ${capability}" (listed in ${manifestPath})`);
          if (fd.header.Facet !== f.facet) fail(f.file, `must declare "Facet: ${f.facet}"`);
          if (fd.header.Level !== f.level) fail(f.file, `Level '${fd.header.Level}' differs from manifest level '${f.level}'`);
        }
      } else if (f.file.endsWith('.json')) {
        try { JSON.parse(readText(path.join(root, f.file), f.file)); } catch { fail(f.file, 'invalid JSON'); }
      }
    }
    const contract = contracts[slot];
    if (contract) for (const req of contract.required) if (!facets.some((f) => f.facet === req)) fail(manifestPath, `missing required facet '${req}' declared by ${contract.path}`);
    const binds = (line('binds') || '').trim();
    modules.push({ slot, impl, capability, manifestPath, facets, tokens, frameTerms, placementExamples, binds, dir: `.claude/capabilities/${slot}/${impl}/` });
  }
  const frame = modules.find((m) => m.slot === 'architecture');
  const ownerOf = (p) => modules.find((m) => p.startsWith(m.dir) || m.facets.some((f) => f.file === p || (f.file.endsWith('/SKILL.md') && p.startsWith(f.file.replace(/SKILL\.md$/, '')))));
  const moduleFiles = (m) => [...docs.keys()].filter((p) => ownerOf(p) === m && p !== m.manifestPath);

  // Binds: the frame binds nothing; a leaf binds only the selected frame, with a reason; required when the
  // contract says so or when the module's content uses frame-specific vocabulary.
  // Project-name segments come from the frame's own check specification (role project patterns).
  const frameSegments = [];
  const frameCheck = frame && frame.facets.find((f) => f.facet === 'architecture.check');
  if (frameCheck && exists(frameCheck.file)) {
    try {
      const spec = JSON.parse(readText(path.join(root, frameCheck.file), frameCheck.file));
      for (const def of [...Object.values(spec.roles || {}), ...Object.values(spec.testRoles || {})]) {
        for (const seg of String(def.projectPattern || '').match(/[A-Za-z]+/g) || []) if (!frameSegments.includes(seg)) frameSegments.push(seg);
      }
    } catch { /* reported by the manifest check */ }
  }
  const frameVocabulary = frame ? [...frame.tokens, ...frame.frameTerms.filter((t) => /[A-Z].*[A-Z]|[<(]/.test(t) && !frameSegments.includes(t))] : [];
  for (const m of modules) {
    if (m.slot === 'architecture') {
      if (m.binds !== 'none') fail(m.manifestPath, 'the architecture frame must not declare binds: a frame never depends on a leaf (binds: none)');
      continue;
    }
    const target = frame ? `architecture/${frame.impl}` : null;
    const declared = m.binds !== 'none';
    if (declared && (!target || !m.binds.startsWith(target) || !/—\s*\S.{10,}/.test(m.binds))) fail(m.manifestPath, `binds must be "none" or "${target} — <reason>"`);
    const evidence = [];
    for (const p of moduleFiles(m)) {
      const body = docs.get(p).body;
      for (const t of frameVocabulary) if (wordRe(t.replace(/<.*$/, ''), '').test(body)) evidence.push(`${p}: ${t}`);
      for (const seg of frameSegments) if (new RegExp(`<Name>\\.${esc(seg)}\\b`).test(body)) evidence.push(`${p}: <Name>.${seg}`);
    }
    for (const f of m.facets.filter((x) => x.file.endsWith('.json'))) {
      const body = readText(path.join(root, f.file), f.file);
      for (const seg of frameSegments) if (new RegExp(`\\*\\.${esc(seg)}\\b`).test(body)) evidence.push(`${f.file}: *.${seg}`);
    }
    const contract = contracts[m.slot];
    if (contract && contract.requiresBinds && !declared) fail(m.manifestPath, `binds: none, but ${contract.path} requires a binding to the ${contract.requiresBinds} frame`);
    if (evidence.length && !declared) fail(m.manifestPath, `binds: none, but module content uses frame-specific vocabulary (${evidence.slice(0, 3).join('; ')}); declare binds: ${target} — <reason>`);
  }

  // Capability declarations must match manifests.
  for (const [p, d] of docs) {
    if (!d.header || !d.header.Capability) continue;
    const m = modules.find((x) => x.capability === d.header.Capability);
    if (!m) { fail(p, `declares Capability '${d.header.Capability}', which is not a selected module`); continue; }
    if (!(p.startsWith(m.dir) || m.facets.some((f) => f.file === p))) fail(p, `declares Capability '${m.capability}' but is not listed in ${m.manifestPath}`);
  }

  // Rules: level directory, paths, capability subdirectories.
  for (const [p, d] of docs) {
    if (!p.startsWith('.claude/rules/')) continue;
    const parts = p.split('/');
    const levelDir = parts[2];
    if (!LEVELS.includes(levelDir)) fail(p, `rule outside a level directory (${LEVELS.join(', ')})`);
    if (d.header && d.header.Level !== levelDir) fail(p, `header Level '${d.header.Level}' does not match directory '${levelDir}'`);
    const pathsBlock = d.fm.match(/^paths:\s*\n((?:\s+-\s+.+\n?)+)/m);
    if (!pathsBlock || !/-\s+"?[^"\s]+"?/.test(pathsBlock[1])) fail(p, 'rule must declare non-empty "paths:" frontmatter');
    if (parts.length > 4 && d.header && !d.header.Capability) fail(p, 'rule in a capability subdirectory must declare "Capability:"');
  }

  // Conformance direction: a rule may depend only on rules/facets of the same or a more stable level.
  // The only exempt reverse form is a binding pointer ("Framework binding: `<slot>.<facet>` ...").
  const facetLevel = new Map(modules.flatMap((m) => m.facets.map((f) => [f.facet, LEVELS.indexOf(f.level)])));
  for (const [p, d] of docs) {
    if (!p.startsWith('.claude/rules/') || !d.header) continue;
    const own = levelOf(p);
    for (const block of parseBlocks(d.body)) {
      for (const sentence of block.text.split(/(?<=\.)\s+/)) {
        const targets = [
          ...[...sentence.matchAll(/\.claude\/rules\/(\d)-/g)].map((m) => [m[0], Number(m[1])]),
          ...[...sentence.matchAll(/(?<![\w./-])((?:architecture|persistence|backend-testing|frontend)\.[a-z][a-z-]*)(?![\w-])/g)].map((m) => [m[1], facetLevel.has(m[1]) ? facetLevel.get(m[1]) : -1]),
        ].filter(([, lvl]) => lvl > own);
        if (!targets.length) continue;
        if (/^\s*(?:Framework\s+binding|Bindings?)\s*:\s*`(?:architecture|persistence|backend-testing|frontend)\.[a-z-]+`(?:\s*\([^)]*\))?\.?\s*$/i.test(sentence.replace(/\s+[A-Z][^.]*:.*$/, ''))) continue;
        for (const [target, lvl] of targets) fail(p, `conformance dependency on less stable ${LEVELS[lvl]} artifact '${target}'; a rule may depend only on the same or a more stable level`);
      }
    }
  }

  // Always-loaded surface: CLAUDE.md imports.
  const imports = [...docs.get('CLAUDE.md').body.matchAll(/^@(\S+)\s*$/gm)].map((m) => m[1]);
  for (const imp of imports) {
    if (!exists(imp)) { fail('CLAUDE.md', `import does not resolve: @${imp}`); continue; }
    const d = docs.get(imp);
    if (d && d.header && !/^always/.test(d.header.Loading)) fail(imp, 'imported by CLAUDE.md but header Loading is not "always"');
  }
  for (const [p, d] of docs) {
    if (p !== 'CLAUDE.md' && d.header && /^always/.test(d.header.Loading) && !imports.includes(p)) fail(p, 'declares "Loading: always" but is not imported by CLAUDE.md');
  }

  // Implementation-name leakage (case-insensitive).
  for (const [p, d] of docs) {
    if (LEAK_ALLOWED.has(p)) continue;
    const owner = ownerOf(p);
    for (const m of modules) {
      if (owner === m) continue;
      for (const token of m.tokens) {
        if (wordRe(token).test(d.body)) fail(p, `names '${token}' from module ${m.capability}; use slot/facet/role vocabulary or move the content into the module`);
      }
    }
  }

  // Core and Architecture neutrality (strict P4 with bounded pointer grammar).
  const skillsDir = path.join(claude, 'skills');
  const skills = existsSync(skillsDir) ? readdirSync(skillsDir).filter((e) => existsSync(path.join(skillsDir, e, 'SKILL.md'))) : [];
  const techSkills = new Set(skills.filter((s) => { const d = docs.get(`.claude/skills/${s}/SKILL.md`); return d && d.header && d.header.Level === '2-technology'; }));
  const packageIds = [];
  const collectIds = (obj) => {
    if (Array.isArray(obj)) { for (const x of obj) collectIds(x); return; }
    if (obj && typeof obj === 'object') {
      for (const [k, v] of Object.entries(obj)) {
        if ((k === 'id' || k === 'prefix') && typeof v === 'string') packageIds.push(v.replace(/[/.]+$/, ''));
        else if (/Packages|PackagePrefixes/.test(k) && Array.isArray(v)) v.filter((x) => typeof x === 'string').forEach((x) => packageIds.push(x.replace(/[/.]+$/, '')));
        else collectIds(v);
      }
    }
  };
  for (const f of ['.claude/hooks/manifest-policy.json', ...modules.flatMap((m) => m.facets.filter((x) => x.file.endsWith('.json')).map((x) => x.file))]) {
    if (exists(f)) { try { collectIds(JSON.parse(readText(path.join(root, f), f))); } catch { /* reported elsewhere */ } }
  }
  const leafTokens = modules.filter((m) => m.slot !== 'architecture').flatMap((m) => m.tokens.map((t) => t.replace(/^\[|\]$/g, '')));
  const vocabulary = [...new Set([...TECHNOLOGY_LEXICON, ...leafTokens, ...packageIds].filter((t) => t && t.length > 2))];
  const vocabRes = vocabulary.map((t) => wordRe(t));
  const isTechnology = (term) => techSkills.has(term) || vocabRes.some((re) => re.test(term.replace(/<.*$/, '')));
  // Frame terms and placement examples are allowed only inside frame-owned Level 1 artifacts and can never
  // legalize technology: an entry that is technology vocabulary is itself a violation.
  const frameTerms = new Set(frame ? [...frame.frameTerms, ...frame.placementExamples].flatMap((t) => [t.replace(/\(\)$/, ''), t.replace(/<.*$/, '')]) : []);
  if (frame) {
    for (const [key, terms] of [['frame-terms', frame.frameTerms], ['placement-examples', frame.placementExamples]]) {
      for (const t of terms) {
        if (isTechnology(t) || [...techSkills].some((s) => s.toLowerCase() === t.toLowerCase())) fail(frame.manifestPath, `${key} entry '${t}' is technology vocabulary; frame vocabulary cannot legalize concrete technology at Levels 0/1`);
      }
    }
  }
  const ctx = { techSkills, vocabulary, frameTerms, frameOwned: (p) => !!frame && ownerOf(p) === frame };
  for (const [p, d] of docs) {
    if (!d.header || !['0-core', '1-architecture'].includes(d.header.Level)) continue;
    neutralityCheck(p, d, ctx);
  }

  // Facet references.
  for (const [p, d] of docs) {
    for (const m of d.body.matchAll(/(?<![\w./-])(architecture|persistence|backend-testing|frontend)\.([a-z][a-z-]*)(?![\w-])/g)) {
      const [ref, slot] = [m[0], m[1]];
      const mod = modules.find((x) => x.slot === slot);
      if (!mod) { if (SLOTS[slot].startsWith('required')) fail(p, `facet reference '${ref}' but slot '${slot}' has no module`); continue; }
      if (!mod.facets.some((f) => f.facet === ref)) fail(p, `facet reference '${ref}' is not declared in ${mod.manifestPath}`);
    }
  }

  // Skills and agents.
  const agents = listFiles(path.join(claude, 'agents'), (f) => f.endsWith('.md')).map((f) => path.basename(f, '.md'));
  const moduleKnowledge = modules.flatMap((m) => m.facets.filter((f) => f.facet.endsWith('.knowledge')).map((f) => f.file.split('/')[2]));
  for (const name of [...REQUIRED_WORKFLOWS, ...REQUIRED_SHARED_KNOWLEDGE, ...moduleKnowledge]) {
    if (!skills.includes(name)) fail(`.claude/skills/${name}`, 'required skill is missing');
  }
  for (const name of skills) {
    const p = `.claude/skills/${name}/SKILL.md`;
    const d = docs.get(p);
    const fmName = (d.fm.match(/^name:\s*(.+)$/m) || [])[1];
    const description = (d.fm.match(/^description:\s*(.+)$/m) || [])[1];
    if (fmName !== name) fail(p, `frontmatter name '${fmName}' must equal directory '${name}'`);
    if (!description) fail(p, 'missing description');
    else if (description.length > 360) warn(p, `description is ${description.length} chars; keep skill listings compact`);
    const userOnly = /^disable-model-invocation:\s*true\s*$/m.test(d.fm);
    if (name === 'template-maintenance' && !userOnly) fail(p, 'must set disable-model-invocation: true (user-only workflow)');
    if (name !== 'template-maintenance' && userOnly) fail(p, 'must stay model-invocable');
  }
  const reviewer = docs.get('.claude/agents/code-reviewer.md');
  if (!reviewer) fail('.claude/agents/code-reviewer.md', 'missing code-reviewer agent');
  else {
    const disallowed = (reviewer.fm.match(/^disallowedTools:\s*(.+)$/m) || [])[1] || '';
    if (!/\bWrite\b/.test(disallowed) || !/\bEdit\b/.test(disallowed)) fail('.claude/agents/code-reviewer.md', 'must disallow Write and Edit (read-only reviewer)');
    if (!reviewer.body.includes('`code-review`')) fail('.claude/agents/code-reviewer.md', 'must delegate to the code-review skill');
  }

  // Named skill/agent references.
  const known = new Set([...skills, ...agents]);
  for (const [p, d] of docs) {
    const re = /`([a-z][a-z0-9-]*)`(?=\s+(?:skill|workflow|agent)\b)|(?:\brun|→|->|[Tt]echniques?:|Procedures?:)\s+`([a-z][a-z0-9-]*)`/g;
    for (const m of d.body.matchAll(re)) {
      const name = m[1] || m[2];
      if (!known.has(name)) fail(p, `references unknown skill or agent '${name}'`);
    }
  }

  // Path references.
  for (const [p, d] of docs) {
    for (const m of d.body.matchAll(/`(\.claude\/[^`\s]+|references\/[^`\s]+)`/g)) {
      const target = m[1].replace(/[.,;:]+$/, '');
      if (/[<*>]/.test(target)) continue;
      const resolved = target.startsWith('references/') ? path.posix.join(path.posix.dirname(p), target) : target;
      if (!exists(resolved)) fail(p, `path reference does not resolve: ${target}`);
    }
  }

  // Skill-private references are used only by their owning skill (the map may list them).
  for (const p of docs.keys()) {
    const m = p.match(/^\.claude\/skills\/([^/]+)\/references\/(.+)$/);
    if (!m) continue;
    for (const [other, d] of docs) {
      if (other === p || other === '.claude/INSTRUCTION_MAP.md' || other.startsWith(`.claude/skills/${m[1]}/`)) continue;
      const ownRelative = other.startsWith('.claude/skills/') && d.body.includes(`references/${m[2]}`);
      if (d.body.includes(`${m[1]}/references/${m[2]}`) || ownRelative) fail(other, `depends on private reference ${p} of skill '${m[1]}'`);
    }
  }

  // Human map coverage.
  const map = docs.get('.claude/INSTRUCTION_MAP.md');
  if (!map) fail('.claude/INSTRUCTION_MAP.md', 'missing instruction map');
  else {
    for (const p of docs.keys()) if (p !== '.claude/INSTRUCTION_MAP.md' && !map.body.includes(p)) fail('.claude/INSTRUCTION_MAP.md', `does not list ${p}`);
    if (imports.includes('.claude/INSTRUCTION_MAP.md')) fail('CLAUDE.md', 'the instruction map must not be auto-loaded');
  }

  // Hooks: exec form (command + args, placeholder only as argument data), required registrations, failure semantics.
  const settingsPath = path.join(claude, 'settings.json');
  if (!existsSync(settingsPath)) fail('.claude/settings.json', 'missing');
  else {
    const S = '.claude/settings.json';
    const settings = JSON.parse(readText(settingsPath, S));
    const hooks = settings.hooks || {};
    for (const [event, groups] of Object.entries(hooks)) {
      for (const group of groups) {
        for (const hook of group.hooks || []) {
          const cmd = hook.command || '';
          if (hook.type !== 'command') fail(S, `${event} hook must be of type "command"`);
          if (!cmd || /[\s$%`'"&|;<>]/.test(cmd)) fail(S, `${event} hook command must be a bare executable name (exec form), found: ${cmd}`);
          if (!Array.isArray(hook.args) || hook.args.length === 0) { fail(S, `${event} hook must use exec form with "args" (no shell-form command string)`); continue; }
          const script = hook.args[0];
          if (!/^\$\{CLAUDE_PROJECT_DIR\}\/\.claude\/hooks\/[\w.-]+\.mjs$/.test(script)) fail(S, `${event} hook script argument must be "\${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.mjs", found: ${script}`);
          else if (!exists(script.replace('${CLAUDE_PROJECT_DIR}/', ''))) fail(S, `${event} hook script missing: ${script}`);
          for (const a of hook.args.slice(1)) if (/[$%`]/.test(a)) fail(S, `${event} hook argument relies on expansion: ${a}`);
          if (typeof hook.timeout !== 'number') fail(S, `${event} hook needs a numeric timeout`);
          if (event === 'PreToolUse' && hook.onFailure !== 'block') fail(S, 'critical PreToolUse hook must set onFailure: "block" (fail closed on missing script, crash, malformed input, timeout)');
          if (event !== 'PreToolUse' && hook.onFailure === 'block') fail(S, `${event} hook must stay non-blocking (no onFailure: "block" on advisory post/Stop hooks)`);
        }
      }
    }
    const covered = (event, tool) => (hooks[event] || []).some((g) => (g.hooks || []).length && (tool ? g.matcher && new RegExp(`^(?:${g.matcher})$`).test(tool) : true));
    for (const tool of ['Bash', 'PowerShell']) if (!covered('PreToolUse', tool)) fail(S, `PreToolUse must cover ${tool} (dependency and project-graph gate)`);
    for (const tool of ['Edit', 'Write', 'MultiEdit', 'Bash', 'PowerShell']) if (!covered('PostToolUse', tool)) fail(S, `PostToolUse must cover ${tool} (actual manifest state)`);
    for (const tool of ['Bash', 'PowerShell']) if (!covered('PostToolUseFailure', tool)) fail(S, `PostToolUseFailure must cover ${tool} (partial side effects of failed shell calls)`);
    if (!covered('Stop')) fail(S, 'Stop co-change hook is not registered');
  }

  for (const w of warnings) console.log(`WARNING   ${w}`);
  for (const v of violations) console.log(`VIOLATION ${v}`);
  console.log(`Instruction check: ${violations.length === 0 ? 'PASS' : 'FAIL'} (${docs.size} artifacts, ${violations.length} violation(s), ${warnings.length} warning(s)).`);
  process.exit(violations.length === 0 ? 0 : 1);
}

try {
  main();
} catch (error) {
  console.error(`Instruction check could not run: ${error.message}`);
  process.exit(2);
}
