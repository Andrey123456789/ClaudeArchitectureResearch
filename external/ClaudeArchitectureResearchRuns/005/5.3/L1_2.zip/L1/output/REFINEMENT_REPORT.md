# Refinement Report — L1 (Iteration 005 / 5.3)

## Final status: **STRICTLY_BETTER** (after Corrective pass — iteration 2)

Every mandatory defect D1–D15 is repaired with behavioral evidence, D16/D17 reviews are complete, the strict cumulative gate passes on every item, and one complete cumulative confirmation audit found **0 concrete template defects**.

Independent verification after iteration 1 found D1 and D2 still incomplete: Level 0/1 kept controller technique, and the checker let plain technology nouns pass. Iteration 2 (last section of this report) closed both while keeping every other iteration-1 result. Where the iteration-1 sections below claim D1/D2 complete, the iteration-2 section supersedes them. All other iteration-1 results stand: their runtime files are byte-identical.

| Gate metric | Result |
| --- | --- |
| Normalized runtime requirements represented | 196 / 196 (194 inventory + GOV-017/GOV-018) |
| Authoritative-owner regressions | **0** (owner file per policy identical to baseline) |
| `trigger_class` deltas | **0** |
| Minimum-scope misses | **0** |
| Duplicate owner texts (anchor uniqueness) | 0 |
| Unresolved broken references | **0** |
| Regression matrix (harness) | **212 / 212** checks pass |
| Instruction checker on the template | PASS (67 artifacts, 0 violations, 0 warnings) |
| Runtime hygiene (language, research metadata, standalone, JS parse) | 0 findings |
| Cumulative confirmation audit | **0 concrete template defects** |

## Baseline provenance

- Immutable comparison point: **5.2 / L1 / Run-02** (`baseline/template/`), copied byte-identically to `output/template/` before any change (`diff -r`: identical).
- Initial tree hash (SHA-256 of the sorted per-file SHA-256 list): `852d78f8a8f8094d9507bdb8b827781b79cfc1696d94df65e91301b644c52422` (85 files).
- Final tree hash (same method): `7d52dd424fe003ca9217ed3376ccfb8ef7c322eb43a42cac73765ea6fa97191f` (86 files).
- Run-01 implementation files were not used; Run-01's report was read as comparative evidence only.

## L1 identity (unchanged)

Levels `0 Core → 1 Architecture → 2 Technology → 3 Project`, level-first rules, `Level:` headers; exactly four static slots — `architecture` (required frame, `clean-architecture`), `persistence` (required leaf, `ef-core`, provider `sqlserver`), `backend-testing` (required leaf, `nunit`), `frontend` (optional leaf, `angular`); contracts/manifests as maintainer metadata; the frame owns placement, leaves own technique; role vocabulary mediates frame/leaf interaction; `binds:` kept where executable frame integration needs it (persistence → frame); L-style stratified decisions; no `Kind:` taxonomy, no cross-level register, no flattening, no extra slots or dynamic discovery. The only structural addition is one frame facet, `architecture.enforcement` (Level 2 data), which moves package identifiers out of the Level 1 `architecture.check` data.

## D1–D15 disposition

| # | Defect | Repair | Evidence |
| --- | --- | --- | --- |
| D1 | Level 0/1 technology leakage | Neutral policy kept at its owner; concrete technique moved to Level 2: new **Platform bindings** table in `.claude/rules/2-technology/backend-libraries.md` (controllers mechanism + Minimal API rule, result/transport types, `ProblemDetails`/`ValidationProblemDetails`, `IExceptionHandler`, authentication handlers/Identity, Data Protection, `WebApplicationFactory<Program>`, `IHttpClientFactory`, `ILogger<T>`, `IConfiguration`/options). Rewritten owners: Core http-api (API-002, API-007, API-012), security (SEC-008, SEC-016), testing (TST-006), backend-code (RUN-005, RUN-013, RUN-022), frontend (FE-009); Architecture roles (API-001), frame boundaries (ARC-002, ARC-008, ARC-010, ARC-018), adopted-style, layout (Minimal API rule, composition code, test host). `scan-layers.md` (platform-specific search patterns, owns no policy) reclassified 0 → 2; `security-scan` and `build-fix` examples neutralized (`frontend.commands` gained a toolchain row). Package IDs moved from Level 1 `check.json` to `architecture.enforcement`. The fixed platform vocabulary itself is unchanged (.NET, C#, ASP.NET Core, NuGet, HTTP, Git) and now stated precisely in the map and `template-maintenance`. | Refined checker rejects all 8 baseline Level 0/1 terms when the baseline rule texts are restored (one-time demonstration); manual re-scan of every Level 0/1 artifact shows only platform names, `dotnet`/`git` CLIs, .NET project files, base-runtime types, role/frame vocabulary, skill names, template tooling |
| D2 | Neutrality checker was a partial deny-list | Layered, data-driven neutrality: (1) fail-closed allow-list for code identifiers and API-shaped prose in non-frame Level 0/1; (2) lexicon harvested from the template's own Level 2 binding sections, package tables, enforcement data, and module leak-tokens; (3) "ASP.NET Core <Feature>" rule; (4) generic non-slot technology list; (5) Level 0/1 JSON data may hold no package IDs | 9 leak fixtures fail (incl. `IHostedService`, named in no list, rejected by the fail-closed layer); platform/stable-role vocabulary fixture passes; baseline checker reports PASS on the unrepaired baseline (demonstrated once) |
| D3 | CWD-fragile launchers | Exec form everywhere: `"command": "node"`, `"args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.mjs"]` | Baseline shell form fails from a nested cwd (`MODULE_NOT_FOUND`, demonstrated once); exec form starts from root, nested backend/frontend, linked worktree, nested worktree cwd, paths with spaces |
| D4 | Launcher root vs active root conflated | `lib/project.mjs`: launcher root from script location; active root from hook `cwd` (or the edited file) via Git + instruction marker; policy data from the active root when present; per-worktree hook state in the worktree's own Git directory | Worktree-only invalid manifest reported with the worktree path while main stays quiet; main change does not affect the worktree; main working tree unmodified; state never in any working tree; Stop and architecture checks inspect the worktree |
| D5 | Critical PreToolUse could fail open | `onFailure: "block"` on the dependency guard; the script itself denies on empty/malformed/odd-encoded input, missing `tool_input.command`, missing configuration, and internal errors; post/Stop hooks stay non-blocking (checker enforces both) | Missing script, crashing script, and timeout → block (controlled exec-form runner with documented semantics); control without the flag fails open; 6 malformed-input cases deny |
| D6 | npm/pnpm/yarn global options and force flags bypassed routing | Quote-aware tokenizer; global options with values (`--prefix`, `-C`, `--workspace`, `-w`, `--dir`, `--filter`, `-F`, `--cwd`, …), `yarn workspace`, `npm pkg set`, `npm audit fix`, nested `bash -c`/`powershell -Command`/`cmd /c`, `npx`/`npm exec`; `--force`, `-f`, `--legacy-peer-deps`, `npm config set legacy-peer-deps` → ask; module CLI commands (`ng add/update`) read from `frontend.enforcement` | 77-row table (+1 check that module CLI commands come only from module data): all positives routed, all restore-only/unrelated negatives (`npm ci`, `npm install`, `dotnet restore`, `git add package.json`, quoted `echo`, …) quiet |
| D7 | `dotnet add/remove … reference` bypassed PreToolUse | Project-reference changes (incl. `dotnet reference add/remove`) denied once with a pointer to decision control / `project-structure` / `architecture-decision`; post-change architecture check validates the resulting graph | Reference cases routed (Bash and PowerShell); `dotnet reference list`, `dotnet sln add` quiet; architecture violations detected from actual state |
| D8 | Post-change shell validation relied on command text | `post-change-checks.mjs` (renamed from `post-edit-checks.mjs`) registered for `PostToolUse` Bash/PowerShell: per-worktree snapshot (HEAD + content hash of tracked/untracked, non-ignored manifests) compared with the previous one; only changed artifacts are validated | Unrecognized `node -e` and PowerShell `Set-Content` mutations detected; unchanged state after a report stays quiet |
| D9 | Failed shell calls with side effects | Same validation registered for `PostToolUseFailure` Bash/PowerShell; message marks the failed call; never blocks | Failed Bash and failed PowerShell partial mutations detected; failed call without relevant change quiet |
| D10 | HEAD transitions, rewrites, deletions, moves | Snapshot holds HEAD and hashes; first observation validates every manifest once; deletions reported only if the file is gone; moves = removed + added with equal hash; skipped dirs (`node_modules`, build output, dot-dirs, nested repos/worktrees) never listed | Fresh state + first HEAD transition to an invalid committed manifest (clean worktree) detected; later HEAD transition named; same-path rewrite, deletion, `git mv` reported; `node_modules` and newly ignored paths cause no false removals; HEAD change without manifest change quiet |
| D11 | Checker froze shell-form serialization | Checker validates `command`/`args` exec form, placeholder as data only, script existence, timeouts, required events/matchers, `onFailure: "block"` on the critical guard, no blocking post/Stop hooks, and the `PostToolUseFailure` registration | Fixtures: missing `onFailure`, missing `PostToolUseFailure`, shell-form command, blocking post hook all rejected; baseline checker rejects the correct exec-form settings (demonstrated once) |
| D12 | Root-relative manual commands | One form everywhere: `node "$(git rev-parse --show-toplevel)/.claude/scripts/<check>.mjs"`; scripts check the project containing the current directory | Bash and Windows PowerShell 5.1 from nested main and worktree directories check the right checkout |
| D13 | Windows encoding robustness | `decodeText`: UTF-8 (± BOM), BOM-tagged UTF-16LE/BE; deterministic errors for odd-length UTF-16, invalid UTF-8, BOM-less UTF-16; used for hook stdin and every manifest/project reader | UTF-8 BOM and UTF-16LE stdin routed; UTF-8 BOM/UTF-16LE/UTF-16BE project files and PowerShell 5.1 `Out-File` package.json validated; malformed files reported without crashing; architecture checker reads UTF-16 |
| D14 | Stop dedupe by path set | Material fingerprint = reminder set + HEAD + content hash of every triggering file, stored per worktree; `stop_hook_active` exits | remind → loop guard → unchanged silent → unrelated change silent → same-file change reminds → silent; identical change in worktree B still reminds |
| D15 | Capability invariants unproven | Checker: exactly four slot dirs and selection rows with the right requirement, contract titles (frame vs leaf), static composition, every module-dir file is a listed facet, contract facets provided at the contracted level, facet Level/Capability/Facet and JSON `$comment` consistency, leaf facets Level ≥ 2 and frame rule facets Level 1, frame `frame-terms:` ⇒ leaf `binds:` required, leak check incl. skill descriptions, module-directory paths, and hook/script code | 11 capability fixtures + removed-`binds:` fixture rejected; documented 6-step frontend removal → checker PASS, zero Angular references anywhere, routing still works |

## Reviews

**D16 — V2 fidelity (source-based).** All 41 files of `source/v2-baseline/` were read. The baseline preserved V2 semantics well; key-term recall is unchanged (658/703 terms, no section lower), i.e. neutralized terms moved into bindings rather than disappearing. Restored as useful technique: Serilog request-log diagnostic-context enrichment and process enrichers (`logging/references/serilog.md`), EF Core single-context concurrency (no fire-and-forget or parallel queries on one `DbContext`) (`ef-core`), the V2 testing decision guide (`dotnet-testing`), and V2's implementation-layer validation clause (`backend-libraries.md`). Intentionally not restored: lists that would restate rules already owned elsewhere (EF Core anti-patterns that repeat access/seeding rules, the reviewer's list of non-adopted pattern names — it would put technology names into Level 0), verbose duplicate examples.

**D17 — efficiency.** One demonstrably redundant always-loaded clause removed (`decisions.md` restated that changing a capability selection is Reserved; `CLAUDE.md` § Decision control owns it). No policy moved between trigger classes; no routing removed.

## Files and size

- Added (2): `.claude/capabilities/architecture/clean-architecture/enforcement.json`, `.claude/hooks/post-change-checks.mjs`.
- Removed (1): `.claude/hooks/post-edit-checks.mjs` (superseded by `post-change-checks.mjs`).
- Changed (39): `settings.json`; hooks `pre-bash-dependency.mjs`, `stop-cochange.mjs`; scripts `check-architecture.mjs`, `check-instructions.mjs`, `lib/project.mjs`; `manifest-policy.json`; frame `check.json`, `MODULE.md`, `CONTRACT.md`, `layout.md`; frontend `CONTRACT.md`, `MODULE.md`, `commands.md`, `enforcement.json`; Core rules (backend-code, frontend, http-api, security, testing); Architecture rules (roles, adopted-style, boundaries); `backend-libraries.md`; `decisions.md`, `package-management.md`; skills add-dependency, architecture-decision, build-fix, code-review, dotnet-testing, ef-core, project-structure, security-scan (+ `scan-layers.md`), template-maintenance, verify, `logging/references/serilog.md`; `INSTRUCTION_MAP.md`.

| Measure | Baseline | Refined |
| --- | ---: | ---: |
| Runtime files | 85 | 86 |
| Runtime bytes | 298,925 | 356,681 |
| Hook/script code bytes | 41,894 | 88,525 |
| Instruction Markdown bytes | 246,127 | 255,937 |
| Always-loaded chars (CLAUDE.md + imports + skill/agent listings) | 20,626 | 20,595 |
| Always-loaded tokens (chars/4) | ≈ 5,157 | ≈ 5,149 |

Complexity growth is confined to deterministic enforcement (actual-state snapshots, exec-form/fail-closed hooks, the stronger checker) required by D2–D15; the always-loaded surface did not grow. (The provenance file's 20,341-char estimate uses a slightly different counting method; both trees above use the same method.)

## Behavioral matrix summary (harness, controlled process-level execution)

Hooks were executed from the generated `settings.json` by an emulator of the documented host semantics (exec form, `${CLAUDE_PROJECT_DIR}` substituted as data, stdin input, per-hook timeout, `onFailure`), in Git sandboxes under `output/.work/` whose path contains spaces, with Git discovery capped at `output/` and no global/system Git configuration. The live Desktop session was not relocated.

- **Launch/root/worktree (29):** exec form from root, nested backend, nested frontend, linked worktree (`feature tree`), nested worktree cwd, worktree nested inside the main checkout; per-worktree deny-once state; reference routing via the PowerShell matcher; worktree vs main isolation for manifests, architecture, Stop; manual checks via Bash and PowerShell.
- **Input/encoding (25):** normal, UTF-8 BOM, UTF-16LE stdin; empty/whitespace/malformed/array/missing-command/odd-UTF-16 input denied; exact `command`/`args` shape; only PreToolUse blocks on failure; missing/crash/timeout blocked; manifest encodings as listed under D13.
- **Dependency/reference routing (78):** 77-row table under D6/D7 plus the module-data check.
- **Shell actual state (21):** under D8–D10, plus Edit/Write validation that refreshes the snapshot, product-source reminder, Windows path-casing reuse of the snapshot.
- **Stop (10):** under D14, plus satisfied co-changes silent and a non-blocking explanation outside Git.
- **Level/capability structure (32), bounded negative fixtures (13 = the 8 dossier fixtures + 2 hook-serialization fixtures + 3 one-time baseline demonstrations), frontend removal (4).**

## Level 0/1 neutrality and stability direction

Neutrality: checker PASS on the template; leak fixtures for a binding identifier, a framework type in prose, a named framework feature, persistence/frontend/testing implementations, an unlisted API, frame technique, and a package ID in Level 1 data all fail; platform vocabulary passes. Direction: rules and `CLAUDE.md` may reference less stable artifacts only through labeled routing pointers (imports are loading); reverse-dependency fixture fails, same-or-more-stable and labeled routing fixtures pass; rule path vs header level, `Kind:` rejection, and decision stratification (`Decided:` only in the frame style facet and Level 3 rules; no register) are enforced.

## Primary audit and confirmation audit

**Primary audit** (all 15 required areas) passed after repairing: (1) a Windows robustness defect — the shell snapshot compared its stored root case-sensitively, so a differently cased `cwd` resolved through the marker walk-up would repeat the initial validation on every call; (2) the frontend contract and map did not describe the new `dependencyCommands` data; (3) a harness coverage gap (worktree nested inside the main checkout). During construction the checker also caught the frame manifest description lacking its leak token and an Angular CLI cue (`ng add`) in the always-loaded `add-dependency` description; both were fixed.

**Cumulative confirmation audit** (complete rerun of all gates plus a manual review of every changed owner text against its normalized policy and new Level 2 binding): 212/212 matrix checks, checker PASS, 196/196 owners with 0 owner regressions, 0 trigger deltas, 0 scope misses, 0 duplicates, 0 broken references, hygiene 0 findings, V2 recall unchanged, always-loaded flat. **0 concrete template defects.**

## Workspace events (directly observed)

- Experimental isolation violations: 0 (no network, sibling, or excluded material; no Run-01 template).
- Recoverable workspace-process incidents (remediated): one shell redirect accidentally targeted an outside path (`/tmp/../dev/null`); it failed and wrote nothing. The shell's working directory twice drifted into `output/template/` after a `cd`; it was returned to the workspace root immediately and later commands used absolute paths.
- Platform-managed persistence events: three oversized command outputs were saved by the tool runtime outside the workspace; they were not opened and the content was re-read from workspace files. Claude Desktop auto-discovered the skills under `output/template/` and `source/v2-baseline/`; they were not invoked.

## Why this is strictly better than the baseline

The baseline passed its own checker while violating L1's core rule (concrete ASP.NET Core APIs and features in Core/Architecture), its hooks failed to start after a normal `cd`, conflated the launcher with the active worktree, could fail open, missed global-option and project-reference commands, ignored shell-driven and failed-call manifest mutations, and deduplicated Stop reminders by path only. The refined template removes every one of those failures with behavioral evidence, makes the checker prove L1's actual properties (neutrality, direction, four static slots, frame/leaf separation, `binds:`, exec-form fail-closed hooks), and does so with zero owner, trigger, scope, or reference regressions, unchanged V2 fidelity, and an unchanged always-loaded surface. No previously passing property regressed.

## Corrective pass — iteration 2

Iteration 2 continued in place from the iteration-1 `output/template/` (start tree hash `7d52dd42…`, 86 files). It did not recreate the template from the baseline. At the start, a file-hash inventory of that tree was recorded as the no-regression reference. The temporary harness under `output/.work/` was written new for this pass; nothing was recovered from iteration-1 material. It was deleted after this section was written.

### Independent residual findings

- **D1 (residual): Level 0/1 still carried controller technique.** The Level 1 frame named controllers and a `Controllers/` folder as the Api mechanism: the adopted-architecture role row, the Api section of the boundary rules, and the clean-architecture layout tree and prose. A Level 0 workflow cue read "New controller endpoint", and the maintainer map described "controller responsibilities".
- **D2 (residual): the checker had blind spots.** The neutrality checker matched only harvested binding tokens and API shapes. Plain technology nouns and phrases in Level 0/1 prose (Controllers, Identity, Data Protection, Kestrel, …) passed, so the checker reported PASS while D1 existed.

### Exact files changed (7)

| File | Change |
| --- | --- |
| `.claude/rules/1-architecture/frame/adopted-style.md` | Api role row is now "entry point and composition root (`Program.cs`)" → `backend/<Name>.Api` |
| `.claude/rules/1-architecture/frame/boundaries.md` | Api section restated in entry-point terms, keeping each rule (see below); it ends with a binding pointer to the platform bindings |
| `.claude/capabilities/architecture/clean-architecture/layout.md` | tree line `Controllers/` → `<entry points>/` (its folder and type conventions come from the platform bindings); prose points to the bindings |
| `.claude/skills/security-scan/SKILL.md` | cue "New controller endpoint" → "New API endpoint" |
| `.claude/rules/2-technology/backend-libraries.md` | new platform-binding row that receives the moved technique (see below) |
| `.claude/INSTRUCTION_MAP.md` | locator wording "entry-point responsibilities" |
| `.claude/scripts/check-instructions.mjs` | strengthened neutrality checker (design below) |

### How each Level 0/1 leak was neutralized without losing semantics

- **Api mechanism (adopted-style, boundaries, layout).** "Controllers" became "entry point / entry-point code". Every rule is kept at Level 1, unchanged in meaning:
  - Api is the default HTTP entry point (ARC-010).
  - Entry-point code stays thin: it binds and validates HTTP input, invokes Application services, and translates outcomes into HTTP responses.
  - Entry-point code contains no business logic, no persistence-context or concrete-repository access, and no manual construction of infrastructure services (ARC-011).
  - `Program.cs` is the composition root (ARC-012), and registration stays near the owning layer (ARC-023).
- **Controller technique moved to Level 2.** The technique lives in one binding row in `backend-libraries.md` § Platform bindings: ASP.NET Core controllers (`ControllerBase` with `[ApiController]`) in the Api project's `Controllers/` folder, with no Minimal API endpoint groups unless requested. The approved-stack decision "ASP.NET Core Controllers" stays at Level 3 in `decisions.md`. The controller-only default therefore keeps its force, now at the level that owns technique.
- **Security cue (Level 0 skill).** "New API endpoint" keeps the same review trigger (access control, input handling, HTTP security) without naming a mechanism. WF-020 and WF-021 are unchanged.
- **Kept on purpose:**
  - The fixed platform vocabulary is unchanged.
  - No controller term was added to frame-terms or to any allow-list.
  - The Level 2/3 mentions stay (binding rows, decisions, technique skills); that is where technique belongs.
- **Owners re-checked:** ARC-010 and ARC-011 (new phrases in `boundaries.md`), WF-020 and WF-021 (`security-scan`). Owner file, trigger, and scope are unchanged for all four.

### Checker design changes

1. **Binding-prose harvesting.** Besides binding tokens, packages, and leak tokens, the lexicon now harvests terms from the `## Platform bindings` / `## Bindings` cells: "ASP.NET Core <feature>" heads, and mid-sentence capitalized product runs, including acronym-led names. Stable methodology words, the fixed base vocabulary, and frame-terms are excluded.
2. **Whole-word matching for every term.** Matching is plural- and case-aware, and covers Level 0/1 Markdown and the Level 1 JSON facets. The frame is exempt only for its own frame-terms and tokens.
3. **Platform-follower rule.** "ASP.NET Core X" at Level 0/1 fails unless X is a generic follower (backend, application, project, code, version, …).
4. **Fail-closed capitalized-term layer.** At Level 0/1, any mid-sentence Title-case word or known technology acronym (EF, MVC, WPF, …) fails. The exceptions are stable methodology phrases and words (Unit of Work, Application Services, OWASP category names, level names, …) and, only in frame-owned artifacts, the frame's own words.
5. **Extended fixed technology-name list:** Controller/Controllers, Kestrel, Identity, Data Protection, Razor Pages, Web API, Hangfire, Quartz.NET, Orleans, Dapr.
6. **No legalizing.** The checker fails if its own allow-lists or any frame's frame-terms contain technology vocabulary, so a leak cannot be hidden by broadening vocabulary or frame-terms.

The existing API-shape, leak-token, `binds:`, slot, level, direction, and reference checks are unchanged.

### Positive/negative fixture results

The iteration-2 harness ended at **97/97**. It ran the strengthened checker against throwaway copies of the template.

- **Negative fixtures.** Each must FAIL, and did. Injected into Level 0/1:
  - Controllers/controller and ASP.NET Core Identity/Identity
  - Data Protection and Kestrel
  - WebApplicationFactory and DbContext
  - ControllerBase/`[ApiController]` and Minimal APIs
  - a restored `Controllers/` layout line
  - plural and case variants
  - attempts to legalize a term through frame-terms or the allow-lists
  - removal of the binding row or the binding pointer
- **Positive fixtures.** Each must PASS, and did:
  - the final template
  - stable-role and methodology wording (Application Services, Unit of Work, Decision Request fields, OWASP categories)
  - frame vocabulary inside frame-owned artifacts
  - the technique at Level 2/3
  - D12 regression cases
- **Syntax:** all scripts pass `node --check`.

**Development regression.** One development run reached 86/97. The causes were checker false positives on stable words and on a code comment that tripped the tooling leak rule. Both were fixed in the checker, after which the harness passed 97/97. That fix was the last template change: the tree hash has been `cebb0e61…` ever since, and it matches the confirmation below.

### D3–D17 preservation

- **7 of 86 files changed** compared with the start inventory, all listed above; the other 79 files are byte-identical.
- **D3–D14 runtime surface.** The 12 enforcement files are byte-identical to the iteration-1 accepted state:
  - the 3 hooks
  - `hooks/manifest-policy.json`
  - `settings.json`
  - `scripts/lib/project.mjs`
  - `scripts/check-architecture.mjs`
  - the 5 capability JSON facets

  As the task's efficient regression strategy allows, byte identity plus the iteration-1 evidence (212/212) carries D3–D14 forward. The shell/worktree matrix was not rebuilt.
- **D15 revalidated directly** by the strengthened checker: four static slots, frame/leaf levels, leak tokens, `binds:`, and the optional frontend. Result: PASS.
- **D16 V2 fidelity.** The full owner/trigger/scope audit below shows 0 deltas.
- **D17 efficiency.** The always-loaded surface shrank slightly. The only new logic is in the checker.

### Cumulative metrics

| Metric | Iteration-1 accepted | After iteration 2 |
| --- | --- | --- |
| Policies/invariants represented | 196/196 (194 + GOV-017/GOV-018) | 196/196 (194 + GOV-017/GOV-018) |
| Owner regressions | 0 | **0** |
| `trigger_class` deltas | 0 | **0** |
| Minimum-scope misses | 0 | **0** |
| Broken references | 0 | **0** |
| Runtime files | 86 | **86** |
| Template bytes | 356,681 | 365,140 |
| Always-loaded estimate | 20,595 chars (≈5,149 tokens) | **20,581 chars (≈5,145 tokens)** |
| Level 0/1 technology leaks | residual D1 (controller technique) | **0** |

The byte growth is in the checker (`check-instructions.mjs`). The instruction-text edits are small rewordings plus one binding row.

### Cumulative confirmation audit and final state

One cumulative confirmation audit ran after all repairs and before this section was written. It was a single script, deleted afterwards. An earlier draft of this section had been written before that audit; it was removed so that the audit precedes the report text. After the audit, only this report changed; the template was not edited. Results:

- **Tree identity:** 86 files, hash `cebb0e61…`, identical to the fixture-tested tree.
- **Syntax:** every `.mjs` passes `node --check`.
- **Strengthened instruction checker:** PASS (67 artifacts, 0 violations, 0 warnings). It covers:
  - D1 neutrality
  - level assignment and stability direction
  - the D15 slot, frame/leaf, leak, `binds:`, and optional-frontend checks
  - CLAUDE.md imports and internal path, skill, and agent references
- **Architecture checker:** exit 0.
- **Level 0/1 residual scan:** 0 hits. Terms scanned: Controller(s), Kestrel, Minimal API, ASP.NET Core Identity, Data Protection, DbContext, ApiController, WebApplicationFactory.
- **Full policy audit (194 inventory policies + GOV-017/GOV-018):** 196/196 owners found by phrase in their owner files, with 0 trigger deltas, 0 minimum-scope misses, and 0 duplicates.
- **Standalone/research/language hygiene:** 0 findings.
- **Always-loaded:** 20,581 chars (≈5,145 tokens).

**Result: CLEAN — 0 concrete template defects.**

Final tree hash: `cebb0e61796e50583c8db5c0ec1bfc3dec5d32ce3ede0dc025ade398306a6966` (86 files). It is the sha256 of the sorted per-file sha256 list, with `./path` names.

**Final status: STRICTLY_BETTER.** Iteration 2 keeps every iteration-1 pass and fully repairs residual D1 and D2, with no regressions.
