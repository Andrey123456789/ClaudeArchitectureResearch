# L1-Restart Refinement Report (Phase 5.3, Candidate L1)

## 1. Terminal status: **STRICTLY_BETTER**

All mandatory repairs D1–D15 are implemented and evidenced against the final template, D16/D17 were reviewed, the
frozen Section-3 P4/P6 matrix passes in both eligible levels, and one unchanged-oracle cumulative confirmation audit
ran clean (**302/302 checks, 0 failures**, groups G1–G7). L1 identity (0 Core → 1 Architecture → 2 Technology →
3 Project, four static slots, frame/leaf ownership, selected clean-architecture / ef-core(sqlserver) / nunit /
angular) is unchanged. The baseline fails the same harness broadly (Section 9). Known bounded limitations are listed
in Section 12; none is a known template defect or an accepted Level 0/1 technology assignment.

## 2. Provenance and working copy

- Workspace: fresh L1-Restart copy; `output/` was empty at start (0 files). Nothing was imported from L1 iterations 2–8
  or other candidates; no sibling/parent directories were read.
- Immutable inputs verified with `MANIFEST.sha256`: 144/144 OK at start and again at the end (the two Restart prompt
  files are not in the manifest and were not modified).
- `baseline/template/` (Run-02) copied byte-for-byte to `output/template/`; `diff -r` identical; 85 files.
- Tree-hash algorithm (run inside the tree): `find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum`.

| | Files | Bytes | Tree hash |
|---|---:|---:|---|
| Baseline Run-02 (start copy) | 85 | 298,925 | `852d78f8a8f8094d9507bdb8b827781b79cfc1696d94df65e91301b644c52422` |
| Final `output/template/` | 86 | 351,673 | `e11bcf8c00b884aabe8d4b6408f90f66c4ab2b67fab534fcc9dd66508702cc22` |

The final hash is the hash of the exact tree that the confirmation audit ran against (re-verified after the run).

## 3. File changes

Added (3): `.claude/rules/2-technology/backend-platform.md` (Level 2 bindings receiving the concrete API technique
removed from Levels 0/1), `.claude/hooks/pre-shell-command.mjs`, `.claude/hooks/post-change-checks.mjs`.
Removed (2): `.claude/hooks/pre-bash-dependency.mjs`, `.claude/hooks/post-edit-checks.mjs` (replaced by the two hooks
above; names now match their Bash+PowerShell / edit+shell scope).
Changed (34): `settings.json`; `hooks/stop-cochange.mjs`, `hooks/manifest-policy.json`; `scripts/check-instructions.mjs`,
`scripts/check-architecture.mjs`, `scripts/lib/project.mjs`; rules `0-core/{backend-code,frontend,http-api,security,testing}.md`,
`1-architecture/roles.md`, `1-architecture/frame/{adopted-style,boundaries}.md`,
`2-technology/backend-testing/test-framework.md`, `3-project/package-management.md`; capability metadata
`architecture/CONTRACT.md`, `architecture/clean-architecture/{MODULE.md,layout.md}`, `persistence/CONTRACT.md`,
`frontend/CONTRACT.md`, `frontend/angular/{MODULE.md,enforcement.json}`; skills `architecture-decision`, `build-fix`,
`code-review`, `dotnet-testing`, `project-structure`, `security-scan` (+ `references/scan-layers.md`, re-leveled to
Level 2), `template-maintenance`, `verify`; `INSTRUCTION_MAP.md`. `CLAUDE.md` is byte-identical to baseline.

## 4. D1–D17 disposition

| Item | Disposition | Evidence |
|---|---|---|
| D1 Core/Architecture neutrality | **Fixed.** Every Level 0/1 artifact audited. Neutral policy kept at its owner; concrete technique moved to `2-technology/backend-platform.md` (bindings that add no policy) or the owning facet: `IExceptionHandler`, `ProblemDetails`/`ValidationProblemDetails`, ASP.NET Core Identity/Data Protection, `dotnet user-secrets`, `WebApplicationFactory` (→ `backend-testing.framework`), `IActionResult`/`HttpResponseMessage`, ASP.NET Core Controllers / Minimal API in the frame, `.Result`/`.Wait()`/`CancellationToken`/`TimeProvider`/`HttpClient`/`IHttpClientFactory`/`ILogger<T>`/`IConfiguration`/`ValueTask`/`Task`, TypeScript/OpenAPI/curl/PowerShell/`[Authorize]`/`AllowAnyOrigin()` in Level 0 workflows. `scan-layers.md` (pure .NET/ASP.NET Core investigation technique) re-leveled 0→2. Platform boundary NOT enlarged (still .NET, C#, ASP.NET Core, NuGet, HTTP, Git). | G1 129/129; content audit (§6); owners unchanged (G7) |
| D2 Checker approximation | **Fixed.** Neutrality = deny-by-default API-shape detection + vocabulary derived from the template (Level-2 skill names, leaf leak tokens, enforcement package ids) + a lexicon + the bounded P4 grammar. Removing a lexicon entry does not make `IExceptionHandler`, `WebApplicationFactory<Program>`, `` `docker` `` or `NUnit` pass (A09). Frame terms / placement examples cannot legalize technology (A08, A08b). | G1 A01–A10, A08b, A09 |
| D3 Launcher cwd fragility | **Fixed.** Exec form `command: "node"`, `args: ["${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.mjs"]` for all five registrations. | G3 H01, G5 nested/worktree/space paths |
| D4 Launcher vs active root | **Fixed.** `resolveRoots(cwd)`: launcher root (script location) vs active root (template root ancestor of hook `cwd` within the Git top-level, else Git top-level); config from the active root when it carries the template. State, manifests, architecture and Stop use the active root; Edit hooks resolve from the edited file. | G5 W01–W06 (main tree and state byte-unchanged while worktree active) |
| D5 Fail-closed PreToolUse | **Fixed.** `onFailure: "block"` + script exit 2 on empty/malformed/incomplete input and internal failure. | G3 H03a–f blocked (missing script, crash, timeout, malformed, empty, no command); H03g harmless allowed |
| D6 npm/pnpm/yarn options | **Fixed.** Table-driven tokenizer/segmenter (quotes, `&&`/`;`/`|`, PowerShell `&`, `bash -c`, `cmd /c`, `powershell -Command`, `npx`), value-taking global options (`--prefix`, `-C`, `--workspace`/`-w`, `--dir`, `--filter`/`-F`, `--cwd` …), `=`-forms, force/legacy-peer flags anywhere incl. `npm config set`. | G4 71/71 |
| D7 dotnet reference bypass | **Fixed.** `dotnet add/remove … reference …` and `dotnet reference add/remove` → `ask` before execution (Reserved unless it implements the approved layout); architecture check validates the resulting graph afterwards. | G4 reference rows; G5 A08/A14 |
| D8 Post-change via command text | **Fixed.** `PostToolUse` Bash|PowerShell validates the actual per-worktree manifest snapshot independent of command text (Git index ids for clean files, content ids only for files Git reports changed). | G5 A04 (unrecognized `node -e` mutation), A06 |
| D9 Failed shell calls | **Fixed.** `PostToolUseFailure` Bash|PowerShell registered; same actual-state validation; quiet when nothing relevant changed. | G5 A07, A08 (findings), A09 (quiet) |
| D10 HEAD/rewrite/delete/move state | **Fixed.** Persistent per-worktree snapshot; first observation validates all manifests once; later events validate added/changed/removed/moved manifests incl. HEAD transitions; skipped dirs never enter state. | G5 A11–A18, W01 |
| D11 Checker freezes serialization | **Fixed.** Checker validates exec form, placeholder as argument data, script existence, required events/matchers, `onFailure` only on PreToolUse, `PostToolUseFailure` coverage. | G3 H02a–f |
| D12 Manual checker after `cd` | **Fixed.** One documented form everywhere: `node "$(git rev-parse --show-toplevel)/.claude/scripts/check-…mjs"` (Bash and PowerShell); fallback documented outside Git. | G3 H05 (root, nested, worktree, worktree-nested × Bash/PowerShell; architecture check in worktree) |
| D13 Windows encodings | **Fixed.** Hook stdin and manifests: UTF-8, UTF-8 BOM, BOM-tagged UTF-16LE/BE; odd-length UTF-16, invalid UTF-8, BOM-less UTF-16 (NUL) → visible deterministic findings; single/double-quoted XML attributes equivalent; MSBuild `$(…)` values reported, not trusted. | G6 E01–E10 (incl. real PowerShell 5.1 `-Encoding Unicode`) |
| D14 Stop dedup | **Fixed.** Fingerprint = reminder kinds + content ids of triggering files, per worktree; `stop_hook_active` exits; clean state writes nothing. | G6 T01–T10 |
| D15 Four-slot integrity | **Fixed/strengthened.** Exactly four slot dirs and rows, recorded requirement (architecture = required frame), slot-contract titles, required facets from contracts, facet metadata, static composition, leak rule (now case-insensitive), `binds:` (frame binds nothing; leaf binds only the selected frame with a reason; required by contract `requires-binds` **and** independently by frame vocabulary in module content), frontend CLI routing moved into `frontend.enforcement`, documented removal incl. map rows. | G2 26/26 (S05–S08, S13–S16) |
| D16 V2 technique | **Reviewed.** 589 V2 sections compared with output and baseline: mean best-section term recall 0.586 vs baseline 0.587 (the 0.001 difference is relocation of API names into the binding rule, not loss). Low-recall sections inspected; restored V2's test-technique decision table in `dotnet-testing` (technique only). Other low-recall sections were compressions already present (e.g. deprecated Elasticsearch sink, expected-outcome technique). | §10 |
| D17 Always-loaded | **Reviewed, no compaction.** Same method on both trees (CLAUDE.md + imports + model-visible skill/agent listings): 20,623 → 20,596 chars ≈ 5,156 → 5,149 tokens (PROVENANCE's 20,341/5,085 used another method). No always-loaded routing prose was demonstrably redundant enough to remove without weakening routing. | G7 P-always-loaded |

## 5. P4/P6: supported grammar and fixture results

Implemented in `check-instructions.mjs` and frozen in advance (pre-edit contract):

- **Scope:** Markdown artifacts with header Level `0-core`/`1-architecture` (incl. frontmatter `description`, tables, code).
- **Only** a backticked reference to an existing Level-2 technique skill can be masked. Bare names, API identifiers,
  leaf leak tokens and package ids are never masked.
- **Pointer forms (per `;`/`·` clause):** `<reference label>: refs` (generic `Technique:`/`See technique:`/`References:`
  or self-describing `<topic> technique(s)|reference(s)`), `see refs`, `<area> → refs` / `->`, parenthesized aside
  `(technique: refs)` whose anchor has no modality word, `<reference label>: Technique: refs`, and a non-normative
  same-line lead before a route/self-describing pointer.
- **Six structural forms:** same line, heading, parent/nested item, list-item continuation, colon lead-in + following
  list, wrapped paragraph — parsed by a bounded block parser.
- **Governors:** any ancestor (all heading levels, parent items, lead-ins, same-sentence lead) with a word from a closed
  modality set (must, required, selected, chosen, default, preferred, use, approved, decided, …) blocks masking; a
  GENERIC-label pointer that forms a whole list item needs its nearest governor to be a reference label (so a generic
  rule list such as `Engineering Discipline` never legalizes `- Technique: \`docker\`.`); paragraphs are
  self-contained statements.
- **Referential obligations:** a sentence in the same block, an immediate sibling item or an ancestor containing
  `this|that|these|those|the above|below|following|preceding|previous|listed|referenced|said` + technique/tool/skill/
  reference… binds the pointer(s): no exemption, with one or several antecedents. Unrelated duties (`Must run unit
  tests.`) have no effect.

Results (both L0 `0-core/engineering.md` and L1 `frame/boundaries.md`, fresh copy per case): N01–N14 (19 rows) FAIL
with the neutrality diagnostic naming the injected `docker`/`swagger`; P01–P12 (19 rows) PASS with 0 violations and
0 warnings; metamorphic M01–M12 as specified (neutral siblings before/after never legalize a selection; binding sibling
above/below always fails; unrelated normative sibling keeps PASS; case variants `Docker`/`DOCKER` fail; Swagger
controls); A01–A07 API/vocabulary leaks fail; A10 platform/role paragraph passes; genuine in-place constructs
(`development-workflow` aside, `code-review` route map, `build-fix` footnote) pass. **G1: 129/129.**

Unsupported (documented, out of scope): remote pronouns and cross-section references; free paraphrase that assigns a
technology without any technology token (covered only by the content audit); a generic-label pointer paragraph under a
non-normative topic heading is accepted (matrix-silent); a maintainer could add a new, non-lexicon API name to the
frame's `frame-terms`/`placement-examples` (visible boundary change; technology names and known framework APIs are
rejected there).

## 6. Independent Level 0/1 content audit

All Level 0/1 artifacts were reread after the edits. Remaining concrete terms are inside the predefined platform
boundary or are not prescriptions: `dotnet build/test/format/package list`, `.slnx`, `global.json` (.NET toolchain),
LINQ (C#), `Program.cs`/`appsettings*.json` (ASP.NET Core host placement), ORM/identity (concepts), MD5/SHA1 (named as
acceptable non-security checksums), MCP (named as *not* required), Conventional Commits (optional commit-message
convention), and the grammar-verified pure pointers to `docker`, `ci-cd`, `swagger`, `http-api` and other technique
skills. The Level-1 JSON facet `check.json` keeps `Microsoft.AspNetCore.App` (platform shared framework, inner-role
prohibition) and MediatR/Kommand as approval-required (non-adoption enforcement data, not a selection).

## 7. Policy preservation (196 = 194 inventory + GOV-017/GOV-018)

Frozen owner map (owner file + distinctive anchor per policy), audited automatically and reviewed by hand:
mapped 196/196; owner missing 0; anchor missing 0; **trigger_class deltas 0**; **minimum-scope misses 0** (rule
`paths` checked against sample paths per scope); **strength/condition issues 0**; **duplicate primary anchors 0**;
**owner relocations 0** (D1 moved bindings, not owners; e.g. API-007 is still owned by `0-core/http-api.md`, now
neutral, with its mechanism in the Level-2 binding); broken references 0 (checker); hygiene: English only, no
research metadata. `SPECIFICATION.md` remains an empty input.

## 8. Structure, capability and hooks results (final template)

- **Level/stability (G2):** path/header mismatch, `Kind:`, reverse conformance dependency (rule → less stable rule or
  rule facet, only `Framework binding: \`<facet>\`` exempt) all fail; forward dependency passes.
- **Capabilities (G2):** fifth slot row and fifth slot directory fail; empty required selection fails; missing required
  facet (from contract) fails; facet metadata mismatch fails; implementation leaks (workflow and non-module Level 2)
  fail; `binds:` removed from manifest fails; removed from manifest **and** contract still fails (content evidence);
  frame binding a leaf fails; frontend cleared in a sandbox → checker PASS, architecture check runs, real pre/post hooks
  work, zero residual frontend-module tokens; final output keeps all four selections (persistence provider sqlserver);
  architecture checker catches outward refs, inner-role persistence packages, prod→test refs, single-quoted XML.
- **Hooks (G3):** exact exec-form registrations; checker rejects six broken configurations; PreToolUse fails closed in
  six failure modes; post/Stop crashes stay non-blocking; manual checkers work from 4 locations × 2 shells.
- **Routing (G4):** 70 table rows + deny-once/retry/ask semantics; restore-only and unrelated commands stay silent
  (`npm ci`, `dotnet restore`, `dotnet package list --vulnerable`, `git commit -m "npm install x"`, `echo …`).
- **Actual state (G5):** real Git repo + real linked worktree, directories with spaces, `GIT_CEILING_DIRECTORIES` from
  the first Git call: Bash/PowerShell success and failure, unrecognized command text, first and later HEAD transition,
  same-path rewrite, tracked delete, rename, skipped paths (`node_modules`, `bin`, nested repo) without false removals,
  unchanged calls quiet without state rewrite, nested cwd, Edit hook in worktree, Pre state per worktree.
- **Encoding/Stop (G6):** 22/22 as listed in §4.

Process level vs host semantics: hooks run as real processes with real inputs; the harness emulates documented host
behavior (exec form, `${CLAUDE_PROJECT_DIR}` substitution as data, exit-code/JSON interpretation, `onFailure`, timeout).
Live Claude Desktop hook activation was not tested (not required).

## 9. Baseline demonstration (run once against a copy of Run-02)

Same harness: G1 51/128 pass (the baseline checker accepted every negative fixture except the bare `Docker` (M08) and
`Serilog` (A07) sentences; the passes are the positive controls);
G2 17/26 (reverse dependency, fifth slot dir, binds removal, frame→leaf binds undetected); G3 6/26 (no exec form,
no fail-closed, no PostToolUseFailure, nested-cwd `MODULE_NOT_FOUND`); G4 42/70 (all reference forms, global options,
wrappers missed; `echo npm install x` falsely denied); G5 9/18 checked (no shell actual-state validation at all);
G6 8/22 (BOM/UTF-16, quotes, Stop dedup, nested-cwd Stop launch).

## 10. Complexity and V2

+1 instruction file (Level-2 binding owner required by D1); hooks renamed, not multiplied (3 hooks + 1 policy file as
before). Byte growth +52.7 KB is almost entirely deterministic enforcement: `check-instructions.mjs` 16.0→40.5 KB
(neutrality grammar, binds, contracts, conformance, hook validation), `lib/project.mjs` 5.8→10.7 KB (roots, decoding),
hooks 9.7→28.4 KB (routing parser, snapshots, Stop fingerprints). Instruction prose is essentially flat; always-loaded
−27 chars. The checker's size is the main maintainability cost; it is commented and bounded to the frozen grammar.

## 11. Audits

- **Primary substantive audit:** found and fixed real template defects: P09 route entries after a same-sentence lead
  not recognized; generic `X<Program>` mis-stripped as placeholder (API-shape miss); `IGenericRepository` base name not
  matched; shared hook code still hardcoding the Angular CLI (moved to `frontend.enforcement`); `.angular`/`Vitest`
  frontend tokens in shared code; three binding lines restating policy (reworded as pure mappings); scaffolding
  lacked a pointer to the entry-point folder binding (added to `project-structure`); V2 test-technique table restored.
- **Oracle corrections (all before the confirmation audit, recorded):** G6 E01–E03 reused one command (identical
  retry is allowed by design); G3 timeout case not executable for shell-form baseline hooks on Windows; G5 crash when
  baseline lacked a state file; G7 strength heuristic now accepts a modal cue shared verbatim with the inventory
  wording (SEC-014 "prefer", DEP-002 "rather than") and DEP-005 anchors its "Approval…" heading. No expected verdict
  was changed.
- **Confirmation audit:** oracles frozen by hash (`1658d6a3…`), template hash `e11bcf8c…`; G1 129, G2 26, G3 26,
  G4 71, G5 24, G6 22, G7 4 → **302/302 pass**. Oracle and template hashes re-verified unchanged afterwards.

## 12. Known limitations (no known template defect)

1. The neutrality check is a bounded guard, not an English proof; a bare product name absent from the lexicon and
   from all derived sources and with no API shape (e.g. a hypothetical new library name) is caught only by review.
2. Command routing covers the documented forms; not pre-gated: package-manager config via environment variables,
   PowerShell `Start-Process` argument arrays, project creation/`dotnet sln add`, and reference edits performed by
   arbitrary scripts — the post-state hook still validates resulting manifests and runs the architecture check.
3. MSBuild properties are not evaluated (reported as findings, never trusted).
4. The first shell event in a worktree validates all manifests once and can report pre-existing issues once; non-Git
   projects use a stat-based scan, and Stop reports that co-change checks are unavailable once per state.
5. A broken selection record makes the critical PreToolUse gate block shell commands (fail closed, with a message;
   file edits remain possible).
6. The root-aware manual command needs Git; a template nested below a monorepo root is not covered by that form.
7. Reproduction for any of the above: inject the case into a fresh copy and run the checker or hook as in G1–G6.

## 13. Workspace events

No isolation violations. Platform-managed: the desktop session auto-listed the copied template's skills (never
invoked); one oversized command output (inventory printout) was persisted by the tool runtime and read back (own
output of an allowed input); background command logs were written by the runtime. Recoverable process incidents: one
orphaned hook process (baseline shell-form timeout) was terminated; the first baseline run was cut short by my own
900 s wrapper and G5/G6 were rerun once. `output/.work/` (harness, ledgers, sandboxes) was deleted after this report.

---

# Corrective pass — iteration 2

## Status: **STRICTLY_BETTER**

Both independently reproduced blockers are fixed, every preservation control in the fixed harness still passes, the
single final confirmation ran against the unchanged oracle (132/132), and no file outside the three permitted scripts
changed. Continued in place from the iteration-1 `output/template/`; nothing was taken from `baseline/template/`, L1
iterations 2–8 or other candidates.

## Hashes and files (`find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum -b | sha256sum`)

| | Files | Tree hash |
|---|---:|---|
| Start (iteration 1, verified once before editing) | 86 | `e11bcf8c00b884aabe8d4b6408f90f66c4ab2b67fab534fcc9dd66508702cc22` |
| Final (same before and after the confirmation run) | 86 | `cbabd288390b3d9b7eaf3d6264b460b21465ceeb1f5f46005c606d8f4ddd486b` |

Changed (only these; sha256 prefixes start → final):

- `.claude/scripts/check-instructions.mjs` (`6b76bc35` → `8fe5bb05`)
- `.claude/scripts/check-architecture.mjs` (`77f14c76` → `f755cf48`)
- `.claude/scripts/lib/project.mjs` (`81ec3e8b` → `2fdf409d`)

The other 83 files are byte-identical to iteration 1 (per-file hash comparison). No files were added or removed. Immutable inputs: `MANIFEST.sha256` 144/144 OK.

## Causes and repairs

- **Defect A (P4, heading content):** `neutralityCheck` skipped heading blocks
  (`if (block.type === 'heading') continue;`), so a heading that itself selects a technology was never checked.
  - **Repair:** headings now go through the same centralized check as paragraphs and list items. That covers technique-pointer grammar, technology vocabulary and API-shape identifiers.
  - **Governor role unchanged:** parsing is untouched, so each descendant still records the heading as its governing context.
  - **No new rules:** no new vocabulary, grammar or P6 reinterpretation was added.
- **Defect B (inner-role ASP.NET Core confinement):** `check-architecture.mjs` saw only explicit `<FrameworkReference>` elements.
  - **XML reader:** `parseCsproj` (`lib/project.mjs`) now also returns literal SDK names. It reads `<Project Sdk="A;B/ver">`, `<Sdk Name>` and `<Import Sdk>`, with single or double quotes; version suffixes are dropped and properties are not evaluated.
  - **Inner-role rule:** inner roles (domain-model, use-case-layer) now also reject:
    - an SDK that implicitly references a forbidden shared framework (fixed platform fact: `Microsoft.NET.Sdk.Web` → `Microsoft.AspNetCore.App`);
    - packages of a forbidden framework's family (`Microsoft.AspNetCore.App` → `Microsoft.AspNetCore.*`).
  - **Derived, not duplicated:** both checks come from the frame's existing `forbiddenFrameworkReferencesInInnerRoles`; the frame JSON and policy text are unchanged.
  - **Allowed roles unchanged:** the entry point (Api) and test roles are allowed as before.
  - **Reporting:** the post-change hook already calls `checkArchitecture`, so findings surface without hook changes.

## Fixed harness and results

One harness file in `output/.work/` held all expected verdicts. They were fixed before editing; oracle sha256 `d4faa6995be6ec6eb17ff97d90e7eb993e50234cbe57981a11db2663c622ee23`, verified unchanged before and after the confirmation. The oracle was not corrected at any point in this pass.

| Group | What | Pre-edit (demonstration) | Final confirmation |
|---|---|---|---|
| A-heading | 7 FAIL headings (`## Docker is required for deployment`, `## Selected deployment technology: Docker`, `## Must use Swagger`, `## Default logging provider: Serilog`, `## Use Docker for deployment` + neutral item, `## Docker`, `## Docker` + neutral item) and 3 PASS (`## Deployment technology`, `## HTTP API`, `## Technique: \`docker\``), each in `0-core/engineering.md` and `frame/boundaries.md` | 6/20 (all 14 FAIL headings falsely passed) | 20/20 |
| P4-matrix | Locked Section-3 matrix of `L1-Restart-REFINEMENT_TASK.md` (N01–N14, P01–P12 incl. variants), both levels | 76/76 | 76/76 |
| B-arch | Domain/Application with Web SDK (single/double quotes, `<Sdk>` element), `Microsoft.AspNetCore.Mvc.Core`, `Microsoft.AspNetCore.Authentication.JwtBearer` → FAIL. Explicit `FrameworkReference`, outward Domain→Api, EF Core in Domain/Application, production→test → FAIL. Clean graph, plain SDK with single quotes, Api with Web SDK + ASP.NET Core packages, integration tests → PASS | 8/17 (all 9 new FAIL cases falsely passed) | 17/17 |
| C-hooks | Real Git repo + linked worktree, launcher = main checkout: initial and unchanged events quiet; `PostToolUseFailure` Bash (Domain Web SDK, exit 3) and PowerShell (Application `Microsoft.AspNetCore.Mvc.Core`, exit 1) report the architecture finding; Api ASP.NET Core package quiet; PreToolUse unchanged (allow/ask) | 4/6 | 6/6 |
| D-struct | Clean template PASS with 0 violations/warnings and genuine pointers present; architecture check on template; four slots and selections; exact hook registrations; `binds:` removed from manifest, and from manifest + contract; fifth slot; reverse dependency; optional frontend cleared in a sandbox | 9/9 | 9/9 |
| E-integrity | All `.mjs` parse; 86 files; byte identity outside the permitted scripts; immutable manifest | 4/4 | 4/4 |

FAIL cases required the specific diagnostic, for example:
- `Level 0-core names concrete technology 'Swagger'`
- `domain-model must not use SDK 'Microsoft.NET.Sdk.Web', which implicitly references framework 'Microsoft.AspNetCore.App'`
- `domain-model must not reference package 'Microsoft.AspNetCore.Authentication.JwtBearer' of framework 'Microsoft.AspNetCore.App'`
- the hook output `Manifest state after failed Bash call: - architecture: backend/App.Domain/App.Domain.csproj: …`

## Evidence labels and policy identity

- **New in this pass:**
  - all results above, from real checkers and real hook processes;
  - hooks launched by the same controlled Node host emulation of documented exec-form semantics. No live Claude Desktop run was performed.
- **Policy identity (194 + GOV-017/GOV-018):**
  - every instruction, rule, skill, manifest, settings and hook file is byte-identical to iteration 1, so owner text, trigger and scope cannot have changed in this pass;
  - the 196-record owner/trigger/scope/strength audit itself is **previous evidence** (iteration-1 report above) and was not re-run independently here.
- **Previous evidence, not re-run:** Windows linked-worktree path/encoding/Stop experiments. The hook implementations are byte-identical, and the shared reader change only adds the `sdks` field.

## Limitations

- **Literal values only:** a project that reaches ASP.NET Core only through MSBuild properties, `Directory.Build.props/targets` imports or transitive packages is not detected.
- **Package-family rule:** this covers the forbidden framework family prefix (`Microsoft.AspNetCore.*`) and does not judge individual packages. A legitimately transport-free `Microsoft.AspNetCore.*` utility in an inner role would also be reported, so that case would need an approved exception.
- **Bounded guard:** the P4 heading check inherits the iteration-1 grammar limits (it is a bounded guard, not a natural-language proof).

`output/.work/` was deleted after this section was written; `output/` contains only `template/` and `REFINEMENT_REPORT.md`.
