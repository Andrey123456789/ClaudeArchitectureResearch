# K0 Refinement Report — Iteration 005 / 5.3

## Final status: **STRICTLY_BETTER**

Every strict-promotion gate item in `REFINEMENT_TASK.md` § 12 passes (gate table at the end). The result is still K0: seven Kinds, six Scopes, one primary Kind and Scope per artifact, mechanism by Kind, one always-loaded decision register with `Details in` / `Affects`, scope-first path-scoped standards, embedded technologies, and no Levels or capability machinery.

## Baseline provenance

- Immutable baseline: **5.2 / K0 / Run-02** (`baseline/template/`, 62 files, 324,363 bytes). The Run-01 template was not sought or used.
- `output/` was empty at start. `baseline/template/` was copied to `output/template/` and checked byte-identical (`diff -r`).
- Initial tree hash (sha256 of the sorted per-file `sha256sum` list): `18f51b02f45bb5cbc7284e5fc412aee810996bc8c16ff0676f65c9c3144c2209` (same as the baseline).
- Final tree hash, same method: **`51105bf425561a167dfda0bce08314c9f1fa84ef4a71be85bc9a26892ce08022`** (63 files).

## Evidence base

One bounded harness under `output/.work/`, created once and kept until this report was written:

- process-level hook runs in exec form, with the main checkout as the launcher;
- sandbox Git repositories whose paths contain spaces, a linked worktree and a worktree nested in a checkout;
- Git discovery capped from the first test (`GIT_CEILING_DIRECTORIES`), with an isolated empty global Git config;
- real Git Bash and Windows PowerShell 5.1 mutations;
- a small structural fixture set;
- a one-time baseline contrast run on a *copy* of the baseline.

**Final run: 298/298 checks pass.**

| Section | Checks |
|---|---:|
| Static: JS syntax, checker on the final template, settings shape | 6 |
| 6.1 Launch, root, worktree, nested cwd, spaces | 20 |
| 6.2 Input, failure modes, encodings | 24 |
| 6.3 Dependency and project-reference routing | 103 |
| 6.4 Git-safety routing | 81 |
| 6.5 Actual state after successful and failed shells | 23 |
| 6.6 Stop | 12 |
| 6.7 K0 structural fixtures | 23 |
| Baseline contrast | 6 |

The live Claude session was not moved into a sandbox. Host semantics come from `audit/EXTERNAL_MECHANICS_NOTES.md`:

- exec form and `${CLAUDE_PROJECT_DIR}` in `args`;
- hook input `cwd`;
- `PostToolUseFailure`;
- `onFailure: "block"`.

These semantics are relied on as documented. They were not re-proven against the running session.

## D1–D11 disposition

| ID | Repair | Evidence |
|---|---|---|
| **D1** active worktree | New `.claude/scripts/repo.cjs` separates the **launcher root** (only locates `hook.cjs`) from the **active root**. The active root is the Git work tree of the hook input `cwd`, or of the edited file. All checks use the active root: path relativization, Git state, manifest and graph validation, co-change, instruction validation, and per-worktree state in `<active root>/.claude/.hook-state/`. `process.cwd()` is only a fallback when `cwd` is absent. | The dossier reproduction now reports the inline-version error, whether the session cwd is the worktree or the main checkout. Root, nested backend, nested frontend, worktree root and nested worktree cwd all pass, with Bash and PowerShell tool names. Main and worktree snapshots stay separate, and the main checkout stays clean. Baseline contrast: silent. |
| **D2** fail-closed PreToolUse | `settings.json` uses exec form (`"command": "node"`, `args` with `${CLAUDE_PROJECT_DIR}/.claude/hooks/hook.cjs`) and `"onFailure": "block"`, set only on the PreToolUse policy hook. Unreadable or incomplete required input, or a crashing helper, produces an explicit `deny`. A missing script, a crash of `hook.cjs` itself or a timeout ends with a non-zero exit, which the host blocks. PostToolUse, PostToolUseFailure and Stop stay non-blocking. | Checks: <ul><li>empty, whitespace, malformed, array, missing-command and invalid-UTF-8 input → deny;</li><li>broken `repo.cjs` → deny;</li><li>missing script and syntax-broken hook → non-zero exit with no allow output;</li><li>hung stdin → the hook keeps waiting and never emits a premature allow;</li><li>malformed post/stop input → visible exit 1.</li></ul> Fixture: removing `onFailure` → FAIL. |
| **D3** dependency routing | Table-driven npm/pnpm/yarn classifier (subcommand → change / named-package / restore), with value-taking global options skipped (`--prefix`, `-w`, `--workspace`, `--dir`, `-C`, `--filter`, `--cwd`, …). Force and legacy-peer flags are detected in any position, and a restore with a bypass flag counts as a change. Also covered: ng/npx ng, NuGet CLI and PMC cmdlets, `.cmd`/`.exe`/full-path forms, nested `bash -c` / `powershell -Command` / `cmd /c`, quote-aware segment splitting. | 56 change forms detected (7 with the force flag noticed). 29 restore, read-only or unrelated forms allowed, including `npm install`, `npm ci`, `dotnet restore`, `dotnet list package`, and `git commit -m "npm install …"`. The reviewed marker allows the command. One classifier bug found by the harness (`yarn workspace <name> add`) was fixed. |
| **D4** project-reference graph | `dotnet add/remove [<project>] reference …` and `dotnet reference add/remove …` (spaces in paths, option placement) are denied as Reserved unless the command carries `# project-references: approved`. The dependency marker does not approve a reference change. New `project-structure` § Changing project references owns the procedure. After execution, actual graph changes — a changed reference set, a new project with references, a removal or move with dangling references — are flagged as Reserved; this is not a substitute for the pre-gate. | 7 reference forms detected, plus marker semantics. Shell matrix: a legal Api→Domain reference added by an unrecognized command is flagged; a production→test reference is caught after a failed PowerShell command. |
| **D5** actual-state post-validation | PostToolUse and PostToolUseFailure for `Bash\|PowerShell` run one per-worktree snapshot model. The first observation records a full baseline and validates every tracked manifest and the instruction files. Later observations hash only the paths Git reports: status now, status at the last observation, missing snapshot entries, and `diff old HEAD..new HEAD`, with a full list for a first commit or an unknown old HEAD. Same-content delete+add is reported as a move. `node_modules`, build output, dot-directories, nested repositories and nested worktrees are never in the surface. | 23 matrix checks (see the actual-state section below). |
| **D6** Git safety | Table-driven read-only vs repository-changing classifier after global options (`-C`, `-c`, `--git-dir`, `--no-pager`, …). Conditional forms are handled (branch, tag, stash, worktree, remote, config, notes, reflog, submodule, symbolic-ref, bisect, sparse-checkout, apply, checkout, hash-object), and unknown subcommands count as repository-changing. Mutations return `permissionDecision: "ask"` (user confirmation = the explicit-request path); read-only commands produce no output. The partial static `permissions.ask` list was removed. Map and `git-workflow` claims were narrowed to what is enforced; Git run indirectly by scripts is stated as not classified. | 34 read-only and 45 mutating forms, plus the `ask` decision text and deny precedence. Baseline contrast: the old ask-list omits add, rm, mv, switch, apply, am and update-ref. |
| **D7** encodings | Hook stdin and manifests are decoded by `decodeText`: UTF-8 with or without a BOM, BOM-tagged UTF-16LE and UTF-16BE. Deterministic findings, never a crash, for: <ul><li>odd-length UTF-16;</li><li>invalid UTF-8;</li><li>NUL bytes without a BOM;</li><li>invalid surrogates.</li></ul> | BOM-prefixed and UTF-16LE hook JSON are parsed on all events. The four encodings of an invalid `.csproj` give identical findings, and a UTF-16LE `package.json` is clean. Four malformed variants give a single deterministic error each. A real `Set-Content -Encoding Unicode` file is validated. Baseline contrast: BOM rejected. |
| **D8** checker vs serialization | The checker validates properties, not the old serialization (see the checks below). | Fixtures: missing `onFailure` → FAIL; missing PostToolUseFailure → FAIL; the old shell-string command → FAIL. Baseline contrast: the old checker rejects exec form. |
| **D9** root-aware manual tools | Every instructed invocation uses `node "$(git rev-parse --show-toplevel)/.claude/scripts/…"`, which works in Bash and PowerShell. The scripts default to the Git work tree of the current directory and accept `--root`. The checker rejects cwd-relative `node .claude/…` invocations. | Git Bash and Windows PowerShell 5.1 from nested worktree directories with spaces check the worktree. The instruction checker passes from nested directories in both shells. The `template-maintenance` sample runs in both shells. Fixture: a cwd-relative command → FAIL. |
| **D10** Stop material state | Reminder keys include a content hash of every relevant changed file. The fingerprint is stored per worktree. `stop_hook_active` returns immediately. | The five-state sequence passes: remind / silent / remind on a same-path rewrite / silent / no loop. Seed, migration, test-satisfied and custom-settings obligations behave as before. A worktree stop inspects the worktree. A non-Git root fails visibly. Baseline contrast: silent on the same-path change. |
| **D11** Kind direction | The checker formalizes CONFORMS_TO, routing pointers and the ENF rules (detailed below). | Fixtures (see the structural section below). Baseline contrast: the old checker accepts a reversed STD→KNW edge. |

D8 checker properties:

- executable-only `command` plus an `args` vector;
- a `${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>` target that exists;
- an event argument handled by the script (parsed from its `EVENTS`);
- matchers covering the required tools: PreToolUse Bash/PowerShell; PostToolUse for edit tools and shells; PostToolUseFailure Bash/PowerShell; Stop;
- `onFailure: "block"` required on PreToolUse and rejected elsewhere;
- positive timeouts and no variable expansion.

D11 conformance relation (`CONFORMS_TO`):

- OP → nothing;
- DEC → OP;
- STD → DEC, OP;
- KNW → STD, DEC, OP;
- WF → KNW, STD, DEC, OP;
- ENF → STD, DEC;
- IN → OP, DEC;
- same-Kind edges are allowed but must stay acyclic.

D11 routing-pointer forms, which may point in any direction:

- references after `See also:`, `Workflow:`, `Technique:`, `Procedure:`, `Enforced by:` or `Loading:`;
- invocations (run, use, invoke, switch to, `→`, slash commands, `(agent …)`);
- sections whose heading names routing;
- imports;
- the register's Details in / Affects cells;
- a private reference naming its own skill;
- enforcement messages.

D11 handling of ENF and inputs:

- ENF declares its conformance in its header and in `Conforms to:` lines.
- References to product inputs are reads, not conformance.
- References to enforcement assets name files or tools, not owners.
- 16 unlabelled pointer lines in 11 files (KNW→WF, OP→WF, or same-Kind cross-references that formed cycles) were made explicit routing pointers.

## Actual-state shell matrix (D5)

All 23 checks pass:

- fresh state, then a first shell HEAD transition to an invalid committed manifest with a clean worktree → detected;
- later transitions → detected, or quiet on a valid revision;
- successful Bash mutation (`package.json` floating version) → detected;
- same-path rewrite with the same Git status → detected again;
- successful PowerShell UTF-16LE `.csproj` rewrite → detected;
- failed Bash (`exit 3`) and failed PowerShell (`exit 5`) commands with partial side effects → detected through `PostToolUseFailure` / `additionalContext`;
- failed command with no relevant change → quiet;
- unrecognized command text (Node script adding a deprecated package) → detected;
- unchanged unrelated commands in Bash and PowerShell → quiet, with no re-validation;
- tracked deletion → reported, and the dangling reference found;
- `mv` and `git mv` moves → reported as moves and validated at the new path;
- additions with references → validated and flagged;
- committing already-observed changes → quiet;
- skipped paths (`node_modules`, `bin`, a nested repository, a nested linked worktree) → neither observed nor falsely reported as removed;
- state loss → one re-baseline;
- product-input change → reminder;
- instruction-file corruption via `sed` → checked on the active root.

Non-Git copy of the system: a bounded walk validates the manifests, then stays quiet.

## K0 structural result (D8, D11)

`check-instructions` on the final template: **60 artifacts, 0 errors**.

Bounded fixture set: 23 checks, all as expected.

PASS cases:

- the legal WF→KNW, KNW→STD, STD→DEC and DEC→OP edges are recognized as conformance edges;
- legal ENF→STD and ENF→DEC declarations;
- explicit reverse-direction routing pointers.

FAIL cases:

- reversed STD→KNW, KNW→WF and DEC→STD edges;
- ENF→KNW and ENF→WF declarations;
- a KNW header on a rule, and an STD Kind on a skill;
- a broken `Affects` target, and a citation without `Affects` coverage;
- a decision restatement;
- a procedure in an STD;
- a bare norm in KNW;
- a `Level:` field, a `0-core/` directory and a capability-contract file;
- missing `onFailure`, missing PostToolUseFailure, and a shell-string hook;
- a broken reference and a missing section;
- a cwd-relative tool command;
- a second always-loaded import.

New property checks:

- malformed code fences (the check found and led to fixing a real defect in `logging/SKILL.md`);
- empty directories;
- exactly one Kind DEC artifact, which must be the only `@` import;
- `Details in` targets must appear in `Affects`;
- `Affects` targets must be STD/KNW/WF/ENF and unique;
- IN artifacts load as input;
- agents load as delegated agents.

No baseline check was weakened. The literal launcher-string check was replaced by stronger property checks. The STD-only "route to skills" check is subsumed by the general direction rule.

## Decision register / `Affects`

The register was unchanged: 18 entries, IDs, one-sentence decisions, Details in, Affects. Every citation is covered by `Affects`. Every `Details in` target is also listed in `Affects`. Every target exists and has an allowed Kind. The map's Decision → Affects view matches the register. New citations (`project-structure` → D-01; `solution-layout` → D-17) were already covered by `skills/project-structure`.

## Policy and invariant coverage (explicit 196-entry owner map, final vs baseline)

- **196 / 196** represented: 194 inventory policies plus GOV-017 and GOV-018.
- Owner regressions **0**, trigger-role deltas **0** (32 always / 123 path / 41 workflow, identical to the inventory), minimum-scope misses **0**, unresolved broken references **0**.
- Owner text is identical to the baseline except GOV-010. There, "synchronize it with `custom-settings`" became "synchronize it (workflow: `custom-settings`)", with the same semantics. The same routing-only change was made in the Decision Request line of `CLAUDE.md` § Decisions.
- Restatement sweep (shared 10-word sequences between artifacts): 14 pairs before and 14 after, no new sequences. All 14 are frontmatter/header boilerplate or check-by-reference pointers. One baseline restatement of D-17 in `solution-layout.md` was replaced by a citation.
- Hygiene: no research labels, policy IDs, workspace references or non-English text in `output/template/`. The only scanner hit is "Benchmark" in the RUN-012 owner text ("Benchmark or profile …"), which is a performance term.

## D12 — source-based V2 fidelity review

All of `source/v2-baseline/` was read.

Automated passes:

- section vocabulary coverage: 596 sections, mean 0.97;
- statement-level single-file coverage: 1,416 statements, 373 flagged below 0.75.

Every flagged statement was reviewed manually. Nearly all are preserved paraphrases at the K0 owner, V2 lineage notes ("detailed guidance belongs to the X skill", `technology-stack.md` pointers) that the register and Kind routing replace, or frontmatter descriptions kept concise for the always-loaded budget. No normative gap was found; all 196 owners are confirmed above.

Restored as practical technique, placed by Kind:

- `code-review` (WF): routing to the area → knowledge table, and approved `CUSTOM_SETTINGS.md` values as part of the intended behavior (from the V2 reviewer agent and code-review);
- `security-scan` (WF): a cross-skill technique pointer line (V2 "Cross-Skill Guidance");
- `build-fix` (WF): typical full-stack contract-failure triggers.

Intentionally omitted:

- verbose repetition;
- duplicate anti-pattern lists already expressed at the owner;
- V2 file-lineage notes;
- trigger keyword lists in descriptions.

## D13 — efficiency review

- Always-loaded surface: ≈ 19,724 → 19,738 characters, **≈ 4,931 → 4,935 tokens**. The +14 characters are the two explicit routing labels in `CLAUDE.md`, needed for D11.
- Runtime files: **62 → 63**. The added `.claude/scripts/repo.cjs` holds the single shared implementation of active-root resolution, Git calls, text decoding and hashing, used by the hook and both checkers; without it these would be implemented three times.
- Bytes: 324,363 → 366,543. Almost all of the growth is enforcement code:
  - `hook.cjs` 11.9 → 31.9 KB;
  - `check-instructions.cjs` 24.2 → 34.8 KB;
  - `check-dependencies.cjs` 11.8 → 13.7 KB;
  - `repo.cjs` 4.6 KB;
  - `MAP.md` 23.5 → 26.2 KB.
- Each increase implements a mandatory defect repair (D1–D11). No Markdown file, rule, skill, decision entry, layer or taxonomy cell was added, and the register stays a summary.

## Files

- **Added:** `.claude/scripts/repo.cjs`.
- **Removed:** none.
- **Changed, enforcement:** `.claude/settings.json`, `.claude/hooks/hook.cjs`, `.claude/scripts/check-dependencies.cjs`, `.claude/scripts/check-instructions.cjs`.
- **Changed, map:** `.claude/MAP.md` — conformance and routing conventions, Kind × Scope ENF cell, artifact rows, topic row, enforcement summary.
- **Changed, OP:** `CLAUDE.md` — two routing labels.
- **Changed, WF:**
  - `add-dependency`, `architecture-decision`, `verify`, `template-maintenance`, `project-structure` (+ `references/backend-layout.md`): root-aware commands, gate notes, § Changing project references;
  - `project-structure/references/solution-layout.md`: D-17 citation;
  - `git-workflow`: enforcement line;
  - `code-review`, `security-scan`, `build-fix`: D12;
  - `development-workflow`, `custom-settings`: routing and wording.
- **Changed, KNW:** `angular`, `api-versioning`, `ci-cd`, `docker`, `dotnet-testing`, `ef-core`, `swagger`, `httpclient-factory/references/resilience.md` (explicit routing labels); `logging` (broken code fence).

## Audits

- **Primary substantive audit** (all 20 items of § 10) found these concrete defects and repaired them:
  - the yarn-workspace classifier miss;
  - the D-17 restatement;
  - the D12 review cue;
  - "post-edit" wording made stale by shell-path reminders;
  - an over-broad "every Git command" claim (D6 claim accuracy).

  Before that, during the repairs themselves, the new checker exposed:
  - the broken fence in `logging/SKILL.md`;
  - 16 unlabelled reverse-direction or cycle-forming pointer lines;
  - the cwd-relative commands.
- **Cumulative confirmation audit** ran after the last template edit. It covered:
  - the full harness from fresh sandboxes (298/298);
  - the checker (0 errors) and JS syntax;
  - the 196-entry owner, trigger and scope audit;
  - the restatement sweep and hygiene;
  - the K0 identity checklist (§ 4);
  - a read of the final map and of the complete Markdown diff against the baseline.

  Result: **0 concrete template defects.**

## Workspace events (directly observed)

- Experimental isolation violations: **0**.
- Recoverable workspace-process incident: during the initial hash, a relative path wrote a hash list of the template one directory above the workspace (`../treehash.tmp`). It was deleted immediately and contained only hashes of allowed workspace files. No forbidden information was obtained.
- Platform-managed events:
  - the desktop app auto-registered the template's skills under `output/template/` as session skills; none was invoked;
  - one oversized output of my own listing of the template's rule files was stored by the tool runtime in its tool-results directory and read back once to see that output.

  Neither creates a dependency of the result on external data.

## Why the result is strictly better than the baseline

The baseline enforced the main checkout instead of the active worktree. Its critical pre-command hook could fail open. It missed removals, global-option forms and project-reference changes, and judged shell effects only by command text. It ignored failed shells and HEAD transitions, crashed on BOM input, let materially new work escape the Stop reminder, depended on cwd-relative manual commands, and had a checker that both froze an obsolete hook serialization and was blind to Kind direction.

The baseline-contrast checks reproduce each of these against the immutable baseline. The refined template repairs all of them with direct behavioral evidence. Every policy, trigger role, minimum scope, decision and K0 structural property is preserved; the only cost is enforcement code and +4 always-loaded tokens. This is a strict improvement, not a tie.

## Strict promotion gate

| Gate item | Result |
|---|---|
| D1–D11 repaired | PASS |
| D12 completed, real gaps repaired | PASS |
| D13 completed without unnecessary expansion | PASS |
| 194 + GOV-017/GOV-018 represented | PASS (196/196) |
| Owner regressions / trigger-role deltas / minimum-scope misses / broken references | 0 / 0 / 0 / 0 |
| K0 identity unchanged; exactly one authoritative DEC register; Kind determines mechanism | PASS |
| Kind conformance direction mechanically enforced | PASS (fixtures) |
| Git policy and deterministic Git enforcement agree on the documented surface | PASS |
| Active worktree, successful/failed shell, first/later HEAD, delete/move, encoding, Stop | PASS |
| No checker weakened to achieve PASS | PASS |
| Complexity growth justified by correctness | PASS |
