# Refinement Report — M1 / Run-02

## Final Status

**STRICTLY_BETTER** (cumulative, after corrective iteration 2)

All eight confirmed defects (D1–D8) are fixed with deterministic behavioral evidence, one adjacent
worktree defect found during the audit is fixed, the three quality gates (Q1–Q3) were reviewed with
targeted changes, no binding regression was found, and the result is the same M1 architecture
(four static capability slots, flat M-style rules, frame/leaf rule, no Level/Kind taxonomy).
Corrective iteration 2 (Section 16) closed the two residual gaps found by a later audit: shell
commands are now judged by their actual effect on manifests and project files after successful
and failed Bash/PowerShell calls (`PostToolUseFailure`), including HEAD transitions, same-file
rewrites, deletions, and moves in repository roots, nested directories, and real worktrees; and
hook input is UTF-8-BOM tolerant while the critical PreToolUse hook stays fail-closed. Every
earlier result was re-verified unchanged, and the cumulative confirmation audit found zero
concrete template defects.

## 1. Baseline Identity and Hashes

| Item | Value |
|---|---|
| Baseline | `baseline/template/` = 5.2 / M1 / Run-02 (PROVENANCE `selected_baseline`) |
| `MANIFEST.sha256` | all 140 entries verified OK before and after refinement (baseline, source, audit, task files unchanged) |
| `CANDIDATE.md` | `f1b209f4984ecf93b35c4552026f0b5ed85fada9d54d337c5b47b2642332bff3` (= PROVENANCE `candidate_sha256`) |
| Baseline report | `67ea0ebe749ecccbb8ee72ac78394fb0fd941fa8f3a509a489711c38928913d7` (= PROVENANCE `baseline_report_sha256`) |
| Baseline tree hash¹ | `f3cbfd5d87e39307de67cf57198460230734c203cf45d154253a587d5f3e860d` |
| Output tree hash¹ (final, after iteration 2) | `60b39d95af92099e0af5fdc0ca53d6f899899fe715a86ed43e74b57389eed49b` |
| Iteration-1 output tree hash¹ | `84fd48d280e7a9881f60f4b685388636f016e7d956ea5cdfa967be4f6d44d138` |
| `source/inventory.json` | `bcf1a1532437f4a1d7bfafcb1f27ebcbb832ba684e35b8a42569cd9d2d9ad168` |
| `source/shared-research-invariants.json` | `51b442b118b55ea89e16f3ac8603309d66635a7d184e456af2091d584f7da6d7` |

¹ SHA-256 over the sorted lines `<sha256-of-file>  <relative path>` of every file in the template.
(The PROVENANCE `baseline_template_tree_sha256` uses an undocumented method; identity is
established through the per-file `MANIFEST.sha256` entries, which all verify.)

`output/template/` started as an exact copy (`diff -r` empty). Changed files (baseline → final output,
first 12 hex digits of SHA-256; iteration 2 changed ten of them again, see Section 16.3 for the
iteration-1 hashes); the other 61 files are byte-identical to the baseline:

| File | Baseline | Output | Reason |
|---|---|---|---|
| `.claude/settings.json` | `0c493e2de5b3` | `7ea3bfbc19f2` | D2, D8, I2 |
| `.claude/hooks/pre-tool-use.js` | `58db15b3de3a` | `0191df357e55` | D3, D4, D8, I2 |
| `.claude/hooks/post-tool-use.js` | `4429735d81cc` | `0de60c2d7a85` | D1, D3, I2 |
| `.claude/hooks/stop.js` | `2f2a5d2d5ad2` | `0709d980e8c9` | D1, D7, I2 |
| `.claude/scripts/lib/common.js` | `189c1f9fa53c` | `cfe2358e18d4` | D1, D6, I2 |
| `.claude/scripts/lib/dependency-commands.js` | `e0082ce89969` | `62efa646f2bd` | D3, D4 |
| `.claude/scripts/lib/hook-output.js` | `596f0b4c9702` | `f8a135e48ff5` | D8, I2 |
| `.claude/scripts/check-instructions.js` | `2b622b7d4942` | `98b741da768b` | D5, I2 |
| `.claude/scripts/check-manifests.js` | `934d3fd2ac60` | `4db4f14dbb4a` | D6, I2 |
| `.claude/scripts/check-architecture.js` | `a3e3ede311ad` | `49647ea148f7` | D6, I2 |
| `.claude/skills/project-structure/SKILL.md` | `a14c87493c3f` | `140a4c74cabd` | D4, D6 |
| `.claude/skills/development-workflow/SKILL.md` | `203291df566e` | `f5ea2951cb6e` | D4 routing |
| `.claude/skills/verify/SKILL.md` | `10359e58fc4e` | `b362c4d7ceb2` | D6 |
| `.claude/skills/add-dependency/SKILL.md` | `8ad9fba35c87` | `559ab9eb214e` | D6 |
| `.claude/skills/template-maintenance/SKILL.md` | `109df8ad02b9` | `91e9ba6989a0` | D6 |
| `.claude/skills/code-review/SKILL.md` | `22151d09d241` | `99d4a418e4be` | D6, Q1 |
| `.claude/skills/ef-core/SKILL.md` | `49efd50c885a` | `525cf3a7b08e` | Q2 |
| `.claude/capabilities/persistence/ef-core/MODULE.md` | `067af9813eb0` | `43815c211f24` | Q2 |
| `.claude/MAP.md` | `8b4bc930f430` | `78e82cfc82f7` | map of the above, I2 |

## 2. Old vs. New Metrics

| Metric | Baseline | Output | Delta |
|---|---:|---:|---:|
| Runtime files | 80 | 80 | 0 |
| Total bytes | 368,816 | 405,146 | +36,330 |
| Markdown files / bytes | 67 / 303,524 | 67 / 307,055 | 0 / +3,531 |
| JavaScript files / bytes | 9 / 61,012 | 9 / 93,601 | 0 / +32,589 |
| Flat rules / skills | 14 / 29 | 14 / 29 | 0 |
| Always-loaded files / bytes | 7 / 16,474 | 7 / 16,474 | 0 (byte-identical) |
| Always-loaded estimate (checker, incl. skill listings) | ~5,568 tokens | ~5,568 tokens | 0 |
| Capability slots / implementations | 4 / 4 | 4 / 4 | 0 |
| Checker result | 0 errors, 0 warnings | 0 errors, 0 warnings | — |

The byte increase is almost entirely enforcement code required by D1/D3/D4/D7/D8 (a real
Bash/PowerShell command parser, the two-root model, content-identity hashing, fail-closed
handling) and by iteration 2 (+8,215 JavaScript bytes for the actual-state manifest check,
the failure event, and BOM/UTF-16 tolerance; +290 Markdown bytes in two map rows). No file,
layer, slot, or always-loaded content was added. Iteration-1 figures: Section 16.8.

## 3. Confirmed Defects D1–D8

| # | Defect | Fix | Test evidence (output) | Baseline on same tests | Result |
|---|---|---|---|---|---|
| D1 | Repository checks used a static root from the script location, so a worktree was checked against the main checkout | `common.js` two-root model: **launcher root** (script location) only loads code; **active root** = Git top-level of hook-input `cwd` (parsed first) when it holds the instruction system, otherwise the nearest enclosing directory with `CLAUDE.md` and `.claude/` (bounded by that top-level, or anywhere above `cwd` when there is no repository yet); never the launcher root. All path containment, walking, manifest/architecture/instruction checks, Git calls, and Stop state use the active root. Paths are canonicalized (junctions/symlinks/short names). Nested repositories/worktrees (e.g. Claude Code's `.claude/worktrees/<name>`) are not walked as part of the outer checkout | 15 D1 tests in real Git worktrees under paths with spaces: invalid worktree manifest detected; valid equivalent passes; nested cwd maps to worktree root; invalid main does not leak into worktree, valid main does not hide invalid worktree; edits outside the active worktree and `..` escapes are not checked as inside; CLI path outside root rejected (exit 2); nested `.claude/worktrees` checkout neither pollutes nor is hidden; junction cwd and junction file path resolve; Stop reads the worktree change set — **15/15 pass** | 11 of these are wrong (misses the worktree manifest, substitutes main state, 119 false instruction errors from a nested worktree, junction paths missed) | Fixed |
| D2 | Complex shell-form `node -e "require(...)"` launcher | Exec form for all three hooks: `"command": "node", "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.js"]` | Launch matrix (project root, nested cwd, worktree root, nested cwd in worktree; all under a path containing spaces; Windows, `shell: false`, placeholder substituted as a plain string; Windows backslash `file_path`) — **18/18 pass** | Baseline launches too, but through a shell form; it routes none of the global-option forms | Fixed |
| D3 | npm/pnpm/yarn global options before the subcommand bypassed routing; pre and post phases used different regexes | One tokenizer/classifier (`classifyCommand`) drives both `analyzeCommand` (PreToolUse) and `changesManifests` (PostToolUse): Bash/PowerShell lexing (quotes, comments, `;` `&&` `\|\|` `\|` `&`, subshells, redirections, heredocs/here-strings, shell-aware line continuation), wrapper removal (`sudo`, `env`, `FOO=1`, `&`, `if`…), nested `bash -c`/`pwsh -Command`/`cmd /c`, `npx`/`npm exec`/`corepack` re-dispatch, per-manager global options with value consumption (`--prefix`/`-C`, `--workspace`/`-w`, `--dir`, `--filter`/`-F`, `--cwd`, …), `yarn workspace`/`global`, executable paths such as `npm.cmd`. Markers count only in the trailing comment of the same line | 125-case table, positive and negative (Section 7) — **125/125 pass** | 71/125 (54 misses or false positives) | Fixed |
| D4 | `dotnet add/remove … reference` not routed before mutation | Classified as `reference` operations (never as NuGet packages) for `dotnet add/remove [<project>] reference …` and `dotnet reference add/remove …`; denied until `project-structure` § Changing Project References (new 4-step procedure pointing to the dependency-direction rule, the frame's reference layout, and `architecture-decision` for Reserved changes) is applied and the command is re-run with `# project-reference: checked`; `changesManifests` is true so the post-command architecture check validates the result | Add/remove with explicit project operands, shorthand without project, noun-first .NET 10 form, `cd … &&` form, marker isolation (package marker does not approve a reference and vice versa), post-command outward-reference detection in a sandbox — all pass | All reference cases allowed before mutation; `dotnet reference add/remove` not even post-checked | Fixed |
| D5 | Checker hardcoded the old shell-form launcher | `checkSettings` validates the actual schema: expected events only; each event runs its script; matcher covers the required tools; `type: "command"`, `command: "node"`, `args` exactly one `${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.js`; script exists; PreToolUse must declare `onFailure: "block"`; PostToolUse/Stop must not | 17 settings mutations (old shell form, missing/extra args, cwd-relative path, missing script, shell command string, missing fail-closed, `onFailure` on Stop/PostToolUse, matcher gaps, missing/unexpected event, wrong script, invalid JSON) — **17/17 detected/passed as expected** | Baseline checker rejects the exec form and accepts the old launcher (2/17) | Fixed |
| D6 | Manual checker commands (`node .claude/scripts/…`) failed after `cd` and ignored the active worktree | One self-contained form everywhere: `node "$(git rev-parse --show-toplevel)/.claude/scripts/<checker>.js"` (works in Bash and PowerShell, from any directory of the active repository or worktree); checkers resolve the active root from their working directory and resolve file arguments against it (`verify`, `add-dependency`, `project-structure`, `template-maintenance`, `code-review`, MAP, script usage lines) | Documented commands run from a nested directory inside a worktree in Bash and in Windows PowerShell check the worktree; instruction checker passes there — **3/3 pass** | `MODULE_NOT_FOUND` from nested cwd (0/3) | Fixed |
| D7 | Stop dedup fingerprint was only `{files, messages}` | Fingerprint = SHA-256 of the reminders plus the content identity (file hash, `missing`, or `directory`) of every changed file the reminders were derived from; stored in the worktree's own Git directory; `stop_hook_active` still short-circuits | Section 9 — **12/12 pass** | In an ordinary checkout it suppresses the reminder for the same file set with modified content; inside a worktree it never reminds | Fixed |
| D8 | Critical PreToolUse failure was non-blocking | Three layers: `settings.json` PreToolUse handler `onFailure: "block"`; caught internal errors return a `deny` decision with a clear reason; failure to load the output helper exits with blocking code 2. PostToolUse/Stop keep visible non-blocking failures | Missing script, crashing classifier, crashing output helper, syntax error in the hook, unparseable input → all **blocked**; post-tool failure stays non-blocking — **6/6 pass** | All five failure modes allowed the command (non-blocking error) | Fixed |

**Additional defect found in the primary audit (same class as D1):** in the baseline, a Git worktree
created inside the project (Claude Code places them at `.claude/worktrees/<name>`) was walked as part of
the main checkout: its manifests were reported as main-checkout errors and its instruction files produced
119 false instruction-checker errors. Fixed by not walking nested repositories/worktrees (`common.walk`);
covered by the D1 tests above.

**Observed vs. simulated (method limit).** No live Claude Code session was driven, and this report
does not claim one; the workspace is isolated and the hook-engine mechanics are supplied as binding
external evidence in `audit/EXTERNAL_MECHANICS_NOTES.md`. The tests are the "controlled tests" the task
asks for:

- *observed:* the real hook scripts and `settings.json` of each template, launched as real Windows
  processes exactly as the documented exec form prescribes (`node` with the `${CLAUDE_PROJECT_DIR}`
  argument substituted as a plain string, no shell, hook JSON on stdin, `CLAUDE_PROJECT_DIR` set);
  real Git repositories, worktrees, and a directory junction under paths with spaces; real Bash and
  Windows PowerShell for the manual checker commands; real exit codes, stdout, and stderr;
- *simulated:* only the final mapping from a hook's exit status/JSON to allow, deny, or block, which
  applies the documented rules (exit 0 + JSON decides; exit 2 blocks; any other failure is non-blocking
  unless the handler declares `onFailure: "block"`).

A live runtime observation was attempted but is not obtainable in this environment:

- no Claude Code CLI is installed on `PATH` (checked with `which`/`where.exe`), and locating or
  installing one outside the workspace would have violated the workspace boundary;
- the running desktop session was moved (with the user's folder approval) into a sandbox Git
  repository created from the output template, with a worktree at `.claude/worktrees/feature`. The app
  loaded the sandbox's instruction files as context, but did not activate the sandbox's hooks for the
  running session: the probe `dotnet add Foo.Api.csproj reference Foo.Domain.csproj` executed (and
  failed harmlessly, because the project did not exist) instead of being denied, and writing a
  `.csproj` with a versioned `PackageReference` produced no PostToolUse feedback. A session's hook
  configuration is fixed when the session starts, and a fresh session cannot be started from inside
  this one. Both probes were chosen to be harmless when not intercepted; the session was moved back to
  the workspace afterwards.

Node.js must be resolvable as `node` on `PATH` (as in the baseline).

## 4. Quality Gates Q1–Q3

**Q1 — V2 fidelity.** Every one of the 41 V2 files was compared side by side with its owners in the
output (rules, `CLAUDE.md`, decision records, every knowledge and workflow skill and reference). An
automated section/code-block scan identified low-overlap areas; each was reviewed manually. Result: the
baseline preserves the V2 technique and examples; differences are condensation, policy moved to its
single owner, or leak-rule neutralization of selected implementation names. One materially useful
omission was found and restored (Section 10). The lexical diagnostic is otherwise unchanged
(130/300 exact code blocks before and after; mean section overlap 0.305 → 0.304, the only movement being
three `ef-core` sections whose layer names became role vocabulary under Q2 — same code and technique).

Per-file review record (all 41 V2 files; the per-file lexical diagnostic — section overlap, exact and
covered code blocks — is identical between baseline and output for 40 files, and `ef-core` moves only
in section overlap, 0.29 → 0.28):

| V2 file | Output owners compared | Result |
|---|---|---|
| `CLAUDE.md` | `CLAUDE.md`, `development-workflow`, `docs/technology-stack.md`, `docs/capabilities/architecture.md` | preserved; Development Workflow lives in its workflow per the construction contract |
| `CUSTOM_SETTINGS.md` | `CUSTOM_SETTINGS.md` (product input), `CLAUDE.md` § Product Sources | preserved |
| `SPECIFICATION.md` | `SPECIFICATION.md` | identical (empty) |
| `.claude/agents/code-reviewer.md` | `code-reviewer` agent, `code-review` | preserved; area→skill routing restored |
| `.claude/rules/architecture.md` | `rules/architecture.md`, `rules/persistence-technology.md`, `CLAUDE.md` § Decision Control, `docs/capabilities/architecture.md` | preserved |
| `.claude/rules/coding-style.md` | `rules/coding-style.md`, `verify` § 9 (using cleanup) | preserved |
| `.claude/rules/dependencies.md` | `rules/dependencies.md`, `add-dependency`, `docs/technology-stack.md`, `docs/capabilities/`, `verify` § 8 | preserved |
| `.claude/rules/error-handling.md` | `rules/error-handling.md`, `rules/performance.md` | preserved |
| `.claude/rules/performance.md` | `rules/performance.md`, `development-workflow` | preserved |
| `.claude/rules/security.md` | `rules/security.md`, `ef-core` § Raw SQL | preserved |
| `.claude/rules/testing.md` | `rules/testing.md`, `rules/test-framework.md`, `verify` § 4 | preserved |
| `skills/angular` | `angular`, `rules/frontend.md`, `rules/frontend-framework.md` | preserved |
| `skills/api-versioning` | `api-versioning`, `rules/api.md`, `architecture-decision` § 6, `add-dependency` § 2 | preserved |
| `skills/authentication` | `authentication`, `rules/security.md` | preserved |
| `skills/build-fix` | `build-fix` | preserved |
| `skills/caching` | `caching`, `rules/performance.md`, `rules/architecture.md` | preserved |
| `skills/ci-cd` | `ci-cd`, `verify` § 8 | preserved |
| `skills/code-review` | `code-review` | preserved |
| `skills/configuration` | `configuration`, `rules/composition.md` | preserved |
| `skills/custom-settings` | `custom-settings`, `CLAUDE.md`, `persistence-change` § 5 | preserved |
| `skills/dependency-injection` | `dependency-injection`, `rules/composition.md`, `rules/architecture.md` | preserved |
| `skills/docker` | `docker`, `rules/security.md`, `verify` § 8 | preserved |
| `skills/ef-core` | `ef-core`, `rules/persistence-technology.md`, `persistence-change` | preserved (Q2 role vocabulary) |
| `skills/error-handling` | `aspnet-error-handling`, `rules/error-handling.md` | preserved |
| `skills/git-workflow` | `git-workflow` | preserved |
| `skills/health-check` | `health-check`, `rules/api.md` | preserved |
| `skills/http-api` | `http-api`, `rules/api.md` | preserved |
| `skills/httpclient-factory` | `httpclient-factory`, `rules/performance.md`, `rules/architecture.md` | preserved |
| `skills/logging` | `logging`, `rules/composition.md`, `rules/security.md` | preserved |
| `skills/modern-csharp` | `modern-csharp`, `rules/coding-style.md` | preserved |
| `skills/project-structure` | `project-structure` | preserved |
| `project-structure/references/backend-layout.md` | `references/backend-layout.md`, `ef-core` § Persistence Layout | preserved |
| `project-structure/references/solution-layout.md` | `references/solution-layout.md`, `docs/capabilities/architecture.md` | preserved |
| `project-structure/references/technology-stack.md` | `docs/technology-stack.md`, `docs/capabilities/*.md`, `ef-core` § Project Setup, `dotnet-testing` § Test Project Setup, `angular` § Scaffolding, `rules/persistence-technology.md` | preserved |
| `skills/resilience` | `httpclient-factory/references/resilience.md`, `add-dependency` § 2 | preserved |
| `skills/security-scan` | `security-scan` | preserved |
| `security-scan/references/scan-layers.md` | `references/scan-layers.md`, `angular` § Security Review Notes | preserved |
| `skills/serilog` | `logging/references/serilog.md`, `rules/composition.md` | preserved |
| `skills/swagger` | `swagger`, `rules/api.md`, `docs/technology-stack.md` | preserved |
| `skills/testing` | `dotnet-testing`, `rules/testing.md`, `verify` § 4, `development-workflow` | preserved |
| `skills/verify` | `verify` | preserved |

**Q2 — persistence coupling.** Frame-specific names in the four persistence facets were classified:

- normative persistence rule/workflow text that says "Domain invariants" / "Domain or persistence
  changes" is domain language of the policy owners (PST-007, PST-008) and stays;
- layer and project names in `ef-core` prose, review checks, decision guide, layout root, and package
  placement were avoidable and now use the frame's role vocabulary (adapter layer, use-case layer, core
  model) resolved by the always-loaded role map;
- executable guidance keeps concrete frame names because it cannot be expressed through roles without
  becoming less usable: the registration example (`AddInfrastructure`, the frame's composition method),
  the `Persistence/` placement inside the adapter-layer project (frame-owned placement), the V2
  migration command, and the co-change globs consumed by the Stop hook.

`binds` is kept (not forced to zero) and its reason now lists exactly those four couplings, so a frame
replacement knows precisely what to revisit. The checker still verifies that a facet uses frame names
only with a declared `binds` entry.

**Q3 — minimalism.** No new slot, file, layer, decision artifact, or always-loaded text; always-loaded
bytes are identical. New maintenance concepts are limited to what the repairs require: the
launcher/active-root model (D1), the `# project-reference: checked` marker (D4), the exec-form schema
with `onFailure` (D2/D5/D8). Rejected ideas that would have added concepts are listed in Section 12.

## 5. Policy, Trigger, Scope, and Semantic Audit

An explicit owner map for all 196 policies (194 inventory + GOV-017, GOV-018) records owner file and the
anchor text that must appear there. A script checked, for output and baseline alike:

| Check | Output | Baseline |
|---|---|---|
| Policies with an owner whose anchor text is present | 196/196 | 196/196 |
| Trigger-role deltas (always 32 / workflow 41 / path 123) | 0 | 0 |
| Minimum-scope gaps (rule `paths` matched against scope sample files) | 0 | 0 |
| Anchor texts restated in a second instruction file | 0 | 0 |

Semantic review: every changed instruction file was diffed against the baseline. The diffs consist of
checker command forms (D6), the new pointer-only procedure section in `project-structure` (D4; it
classifies through `CLAUDE.md` § Decision Control and keeps every non-prescribed reference-graph change
Reserved), one routing line in `development-workflow`, the restored review routing table (Q1), role
vocabulary in the `ef-core` knowledge skill (Q2), and map updates. No normative sentence of any policy
owner changed; strength and conditions are unchanged. `SPECIFICATION.md` is still the empty product input.

## 6. Capability Identity and Conformance

| Check | Result |
|---|---|
| Slots | exactly `architecture` (frame, required), `persistence` (leaf, required, provider `sqlserver`), `backend-testing` (leaf, required), `frontend` (leaf, optional) |
| Selected implementations | one per required slot, one for the optional slot; manifests present and matching their location |
| Composition | static selection record only; no discovery or runtime selection code |
| Facets / properties / enforcement data | complete per contract (checker + independent audit) |
| Implementation-name leaks outside module facets | 0 (checker and an independent scan over Markdown, JS, and JSON) |
| `binds` | persistence → frame, reason lists the remaining executable couplings; frame use is verified |
| Unselected implementations in runtime | none; optional-frontend removal procedure applied in a sandbox → checker 0 errors, 61 instruction files, ~5,219 tokens (identical to baseline) |
| Flat rules, no `Level:` / `Kind:` | yes |
| Internal references | checker 0 errors; independent resolver 454 references, 0 unresolved |
| Hygiene | no research labels, policy IDs, run identifiers, workspace paths, or non-English text in `output/template/` |

## 7. Dependency-Command Test Matrix

Columns: expected PreToolUse decision / expected `changesManifests`; actual output; actual baseline
(`✗` = baseline differs). `dep` = routed to `add-dependency`; `ref` = routed to `project-structure`
§ Changing Project References; `force` = peer-override approval required; `⏎` = newline.
Output 125/125; baseline 71/125.

<details>
<summary>All 125 cases</summary>

| Command | Expected | Output | Baseline |
|---|---|---|---|
| `npm install lodash` | dep / true | dep / true | dep / true |
| `npm i -D typescript` | dep / true | dep / true | dep / true |
| `npm add zod` | dep / true | dep / true | dep / true |
| `npm --prefix frontend install x` | dep / true | dep / true | allow / false ✗ |
| `npm --prefix=frontend install x` | dep / true | dep / true | allow / false ✗ |
| `npm -C frontend install x` | dep / true | dep / true | allow / false ✗ |
| `npm --workspace app install x` | dep / true | dep / true | allow / false ✗ |
| `npm -w app install x` | dep / true | dep / true | allow / false ✗ |
| `npm --workspace=app install x` | dep / true | dep / true | allow / false ✗ |
| `npm install x --prefix frontend` | dep / true | dep / true | dep / true |
| `npm --loglevel warn --prefix frontend uninstall x` | dep / true | dep / true | allow / false ✗ |
| `npm update` | dep / true | dep / true | dep / true |
| `npm --prefix frontend update @angular/core` | dep / true | dep / true | allow / false ✗ |
| `npm uninstall x` | dep / true | dep / true | dep / true |
| `npm rm x` | dep / true | dep / true | dep / true |
| `npm audit fix` | dep / true | dep / true | allow / false ✗ |
| `npm exec -- ng add @angular/material` | dep / true | dep / true | dep / true |
| `npx ng add @angular/material` | dep / true | dep / true | dep / true |
| `npx -p @angular/cli ng add @angular/material` | dep / true | dep / true | dep / true |
| `cd frontend && npm install x` | dep / true | dep / true | dep / true |
| `(cd frontend; npm install x)` | dep / true | dep / true | dep / true |
| `FOO=1 npm install x` | dep / true | dep / true | dep / true |
| `sudo npm install -g @angular/cli` | dep / true | dep / true | dep / true |
| `& "C:\Program Files\nodejs\npm.cmd" install x` | dep / true | dep / true | allow / false ✗ |
| `npm.cmd --prefix frontend install x` | dep / true | dep / true | allow / false ✗ |
| `bash -c "npm --prefix frontend install x"` | dep / true | dep / true | allow / false ✗ |
| `pwsh -Command "npm install x"` | dep / true | dep / true | dep / true |
| `npm install x 2>&1 \| tee log.txt` | dep / true | dep / true | dep / true |
| `npm install \ ⏎   --prefix frontend x` | dep / true | dep / true | dep / true |
| `npm install x # add-dependency: checked ⏎ npm install y` | dep / true | dep / true | allow / true ✗ |
| `pnpm add x` | dep / true | dep / true | dep / true |
| `pnpm --dir frontend add x` | dep / true | dep / true | allow / false ✗ |
| `pnpm -C frontend add x` | dep / true | dep / true | allow / false ✗ |
| `pnpm --filter app add x` | dep / true | dep / true | allow / false ✗ |
| `pnpm -F app add -D x` | dep / true | dep / true | allow / false ✗ |
| `pnpm --filter=app remove x` | dep / true | dep / true | allow / false ✗ |
| `pnpm -r update` | dep / true | dep / true | allow / false ✗ |
| `corepack pnpm add x` | dep / true | dep / true | dep / true |
| `yarn add x` | dep / true | dep / true | dep / true |
| `yarn --cwd frontend add x` | dep / true | dep / true | allow / false ✗ |
| `yarn --cwd frontend remove x` | dep / true | dep / true | allow / false ✗ |
| `yarn workspace app add x` | dep / true | dep / true | allow / false ✗ |
| `yarn global add x` | dep / true | dep / true | allow / false ✗ |
| `yarn upgrade x` | dep / true | dep / true | dep / true |
| `yarn up x` | dep / true | dep / true | dep / true |
| `yarn ng add @angular/material` | dep / true | dep / true | dep / true |
| `dotnet add package Serilog` | dep / true | dep / true | dep / true |
| `dotnet add backend/Shop.Api/Shop.Api.csproj package Serilog` | dep / true | dep / true | dep / true |
| `dotnet add Shop.Api.csproj package Serilog --version 4.0.0` | dep / true | dep / true | dep / true |
| `dotnet remove Shop.Api.csproj package Serilog` | dep / true | dep / true | dep / true |
| `dotnet package add Serilog --project Shop.Api.csproj` | dep / true | dep / true | dep / true |
| `dotnet package update` | dep / true | dep / true | dep / true |
| `Install-Package Serilog` | dep / true | dep / true | dep / false ✗ |
| `nuget install Serilog` | dep / true | dep / true | dep / false ✗ |
| `ng add @angular/material` | dep / true | dep / true | dep / true |
| `ng update @angular/core @angular/cli` | dep / true | dep / true | dep / true |
| `dotnet add Foo.Api.csproj reference Foo.Domain.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet remove Foo.Api.csproj reference Foo.Domain.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet add backend/Shop.Api/Shop.Api.csproj reference backend/Shop.Application/Shop.Application.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet add reference ../Shop.Domain/Shop.Domain.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet remove reference ../Shop.Domain/Shop.Domain.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet reference add ../Shop.Domain/Shop.Domain.csproj --project Shop.Application.csproj` | ref / true | ref / true | allow / false ✗ |
| `dotnet reference remove ../Shop.Domain/Shop.Domain.csproj` | ref / true | ref / true | allow / false ✗ |
| `cd backend/Shop.Api && dotnet add reference ../Shop.Application/Shop.Application.csproj` | ref / true | ref / true | allow / true ✗ |
| `dotnet add Foo.Api.csproj reference Foo.Domain.csproj # project-reference: checked` | allow / true | allow / true | allow / true |
| `dotnet add reference ../X/X.csproj # add-dependency: checked` | ref / true | ref / true | allow / true ✗ |
| `dotnet add package Serilog # project-reference: checked` | dep / true | dep / true | dep / true |
| `npm install x --legacy-peer-deps` | force / true | force / true | force / true |
| `npm --prefix frontend install x --force` | force / true | force / true | force / false ✗ |
| `npm install --legacy-peer-deps` | force / true | force / true | force / true |
| `npm ci --legacy-peer-deps` | force / true | force / true | force / false ✗ |
| `npm install x --force # add-dependency: checked` | force / true | force / true | force / true |
| `npm install x --force # add-dependency: checked # peer-override: approved-by-user` | allow / true | allow / true | allow / true |
| `pnpm add x --force` | force / true | force / true | force / true |
| `yarn --cwd frontend add x --force` | force / true | force / true | force / false ✗ |
| `npm install x # add-dependency: checked` | allow / true | allow / true | allow / true |
| `npm --prefix frontend install x # add-dependency: checked` | allow / true | allow / true | allow / false ✗ |
| `cd frontend && npm install x # add-dependency: checked` | allow / true | allow / true | allow / true |
| `echo "# add-dependency: checked" && npm install x` | dep / true | dep / true | allow / true ✗ |
| `npm install` | allow / true | allow / true | allow / true |
| `npm ci` | allow / true | allow / true | allow / false ✗ |
| `npm --prefix frontend ci` | allow / true | allow / true | allow / false ✗ |
| `pnpm install` | allow / true | allow / true | allow / true |
| `pnpm --dir frontend install` | allow / true | allow / true | allow / false ✗ |
| `yarn` | allow / true | allow / true | allow / false ✗ |
| `yarn install --frozen-lockfile` | allow / true | allow / true | allow / true |
| `npm run build` | allow / false | allow / false | allow / false |
| `npm --prefix frontend run build` | allow / false | allow / false | allow / false |
| `npm test` | allow / false | allow / false | allow / false |
| `npm audit` | allow / false | allow / false | allow / false |
| `npm ls` | allow / false | allow / false | allow / false |
| `npm outdated` | allow / false | allow / false | allow / false |
| `npm view zod version` | allow / false | allow / false | allow / false |
| `npm cache clean --force` | allow / false | allow / false | force / false ✗ |
| `pnpm --filter app build` | allow / false | allow / false | allow / false |
| `yarn --cwd frontend build` | allow / false | allow / false | allow / false |
| `yarn test` | allow / false | allow / false | allow / false |
| `npx ng build` | allow / false | allow / false | allow / false |
| `ng build --configuration production` | allow / false | allow / false | allow / false |
| `ng update` | allow / false | allow / false | allow / true ✗ |
| `dotnet build` | allow / false | allow / false | allow / false |
| `dotnet test --filter "FullyQualifiedName~Orders"` | allow / false | allow / false | allow / false |
| `dotnet list package --vulnerable` | allow / false | allow / false | allow / false |
| `dotnet package list --vulnerable --include-transitive` | allow / false | allow / false | allow / true ✗ |
| `dotnet list Shop.Api.csproj reference` | allow / false | allow / false | allow / false |
| `dotnet reference list --project Shop.Api.csproj` | allow / false | allow / false | allow / false |
| `dotnet ef migrations add AddOrderIndex` | allow / false | allow / false | allow / false |
| `git commit -m "npm install x"` | allow / false | allow / false | dep / true ✗ |
| `echo npm install x` | allow / false | allow / false | dep / true ✗ |
| `grep -rn "dotnet add package" docs` | allow / false | allow / false | allow / true ✗ |
| `cat > setup.sh <<'EOF' ⏎ npm install x ⏎ EOF` | allow / false | allow / false | dep / true ✗ |
| `Write-Output "npm install x"` | allow / false | allow / false | dep / true ✗ |
| `Set-Location C:\Projects\App\ ⏎ npm install x` (PowerShell) | dep / true | dep / true | dep / true |
| `` npm install ` ⏎   --prefix frontend x `` (PowerShell) | dep / true | dep / true | dep / true |
| `npm install \ ⏎   --prefix frontend x` (Bash) | dep / true | dep / true | dep / true |
| `git commit -m "fix @" ⏎ npm install x` | dep / true | dep / true | dep / true |
| `$body = @" ⏎ npm install x ⏎ "@ ⏎ Set-Content notes.txt $body` (PowerShell) | allow / false | allow / false | dep / true ✗ |
| `bash -lc "npm --prefix frontend i x"` | dep / true | dep / true | allow / false ✗ |
| `powershell -NoProfile -Command "npm i x"` | dep / true | dep / true | dep / true |
| `cmd /C npm install x` | dep / true | dep / true | dep / true |
| `if ($LASTEXITCODE -eq 0) { npm --prefix frontend install x }` (PowerShell) | dep / true | dep / true | allow / false ✗ |
| `npm install x; if ($?) { npm run build }` (PowerShell) | dep / true | dep / true | dep / true |
| `dotnet new classlib -n Shop.Domain -o backend/Shop.Domain` | allow / true | allow / true | allow / true |
| `dotnet sln add backend/Shop.Domain/Shop.Domain.csproj` | allow / true | allow / true | allow / true |
| `ng new Shop.Web --directory frontend/Shop.Web` | allow / true | allow / true | allow / true |

</details>

Key behavior changes against the baseline: all global-option forms now route (npm `--prefix`/`-C`/
`--workspace`/`-w`, pnpm `--dir`/`-C`/`--filter`/`-F`, yarn `--cwd`, `yarn workspace`, `yarn global`);
`dotnet … reference` routes to the project-reference owner; an approval marker on one line no longer
approves a command on another line or inside a quoted string; ordinary non-mutating commands are no
longer denied (`npm cache clean --force`, `git commit -m "npm install x"`, `echo npm install x`, heredoc
and here-string bodies); restore-type installs, `Install-Package`, `nuget install`, and
`dotnet reference add/remove` now also trigger the post-command manifest/architecture re-check, so the
two phases agree.

## 8. Worktree, Nested-cwd, and Windows Matrix

All runs: Windows 11, Node 24, Git for Windows, sandbox paths containing spaces (`…\AI Learning\…\main repo`,
`wt one`), `GIT_CEILING_DIRECTORIES` capped at the sandbox, `CLAUDE_PROJECT_DIR` = main checkout,
hook input `cwd` as listed.

| Scenario | Output | Baseline (actual outcome) |
|---|---|---|
| Write invalid `.csproj` in worktree, cwd = worktree root | block + ERROR | allow (missed) |
| Same, cwd = nested directory of the worktree | block + ERROR | allow (missed) |
| Same, relative `file_path` | block + ERROR | reminder only (checked the main file) |
| Valid worktree manifest | no ERROR | no ERROR |
| Invalid main + valid worktree, post-command check from worktree | no ERROR | ERROR from main (substitution) |
| Valid main + invalid worktree, post-command check from worktree | ERROR | no ERROR (masked) |
| Edit of a main-checkout file while cwd = worktree | not checked as worktree content | checked |
| `../../outside/Evil.csproj` | ignored | ignored |
| CLI argument outside the active root | exit 2 | exit 2 |
| Nested worktree in `.claude/worktrees/feature`: main checks | clean | ERROR + 119 instruction errors |
| Nested worktree cwd | checks the nested worktree | checks it |
| Junction to the worktree as cwd and in `file_path` | block + ERROR | allow |
| Stop in worktree with a model change | reminds | allow (looks at main) |
| PreToolUse / PostToolUse / Stop launch from root, nested, worktree, nested-in-worktree (exec form, no shell) | launched, routed | launched (shell form), global-option form not routed |
| Windows backslash `file_path` | contained and checked | contained and checked |
| Documented manual checker from nested worktree dir, Bash | checks the worktree | `MODULE_NOT_FOUND` |
| Same, Windows PowerShell | checks the worktree | `MODULE_NOT_FOUND` |
| Template copy before `git init` | post/pre checks run; Stop fails visibly | same |

## 9. Stop-Hook State Tests

| Step (worktree `wt one`, then `wt two`) | Output | Baseline |
|---|---|---|
| Model file changed without seed/migrations → stop | reminder | allow (checks main) |
| `stop_hook_active: true` | allow (no loop) | allow |
| Later stop, unchanged state | allow (no repeat) | allow |
| Unrelated file changed | allow (no noise) | allow |
| Same file set, modified model content | reminder again | allow (suppressed) |
| Repeat with that modified state | allow | allow |
| `wt two` with equivalent file names and content | reminder (not suppressed) | allow |
| Main checkout without changes | allow | allow |
| State file location | each worktree's own Git directory | n/a (main only) |
| Ordinary checkout (no worktree): model change → stop | reminder | reminder |
| Ordinary checkout: later stop, unchanged | allow | allow |
| Ordinary checkout: same file set, modified content | **reminder again** | **allow (suppressed — the D7 defect)** |

## 10. V2 Material Restorations

| Restored | Where | Why |
|---|---|---|
| The V2 reviewer's "Project Guidance" routing from changed area to knowledge skill (persistence, tests, frontend, authentication, HTTP, error handling, outbound HTTP/resilience, caching, configuration/DI, containers/CI, security-sensitive changes) | `code-review` § Step 2 (canonical procedure; the `code-reviewer` agent preloads it and stays thin) | Operational review technique dropped by the baseline; capability skills are referenced by slot role, so no implementation name leaks |

No other V2 technique was missing; no duplicate normative text or research material was restored.

## 11. Intentional Baseline Behavior Retained

- Hook decisions as ASCII-only hook JSON with exit 0; PostToolUse and Stop failures visible and
  non-blocking; Stop loop prevention through `stop_hook_active`.
- Marker syntax `# add-dependency: checked` and `# peer-override: approved-by-user` (now line-bound).
- Global tool installs (`npm i -g …`) and `npm audit fix --force` still require the workflow / approval.
- Post-command checks after `dotnet new`, `dotnet sln`, and the frontend framework CLI's project creation.
- The frontend framework CLI stays recognized inside the embedded classifier (written without leak tokens)
  so the fail-closed pre-tool hook reads no repository state.
- All policy owner texts, trigger roles, scopes, the always-loaded surface, the capability model, the
  checker's structural predicates other than hook wiring, and the optional-frontend removal procedure.

## 12. Rejected Refinement Ideas

| Idea | Reason rejected |
|---|---|
| Role placeholders in the persistence co-change globs, resolved by the Stop hook | New resolution mechanism (Q3); `Persistence/…` sub-paths are frame placement anyway, so `binds` would remain |
| Role placeholders in the migration command | Makes an executable V2 example less directly usable (Q1 vs. Q2) |
| Moving frontend-CLI recognition into the frontend manifest | Would make the critical fail-closed pre-tool hook depend on repository state, so a broken selection file would block every shell command |
| `onFailure: "block"` on PostToolUse / Stop | No effect on Stop; would turn post-change reporting into blocking |
| Deriving the active root from the edited file instead of `cwd` | Contradicts the required model and reintroduces cross-checkout substitution |
| Adding "project references" to the `CLAUDE.md` routing table | Grows always-loaded context; the `project-structure` description already names project references and the hook routes deterministically |
| Pre-routing `dotnet new` / `dotnet sln add` | Not a confirmed defect; would add friction without evidence; post-checks retained |
| Rewording "Domain invariants" in persistence policy owners to role terms | Domain language of policy owner text; churn without substitutability gain |

## 13. Audit Cycles and Confirmation

This section records iteration 1 (template `84fd48d2…6d44d138`). The cumulative confirmation of
the final template after corrective iteration 2 is Section 16.12.

Primary audit repairs that changed the template after the first implementation: shell-aware line
continuation, unbalanced-quote here-string detection, and `bash -lc` / `pwsh -Command` prefixes in the
parser; the `project-structure` procedure step reworded to classify through Decision Control without
reinterpreting Reserved item 3; the reference-routing hook message reduced to a pointer; line wrapping.

**Confirmation audit: 0 concrete template defects.** It was performed as one clean, uninterrupted
run of a single script over the frozen template (output tree hash `84fd48d2…6d44d138`, verified at the
start of the run), after the evidence set (all test cases and audit scripts) was final, on freshly
created sandboxes:

| Gate | Output | Baseline (comparison) |
|---|---|---|
| `MANIFEST.sha256` (protected inputs) | 140/140 OK | — |
| Script syntax (`node --check`) | 0 failures | — |
| `check-instructions` / `check-architecture` / `check-manifests` | 0 / 0 / 0 errors, 0 warnings | — |
| Command matrix | 125/125 | 71/125 |
| Hook behavior (D1, D2, D6, D7, D8, regressions) | 69/69 | 48/69 (all 21 failures in D1/D6/D7/D8 rows) |
| Checker hook-schema cases | 17/17 | 2/17 |
| Policy audit (owner, trigger role, scope, restatement) | 196/196 | 196/196 |
| Independent structure audit | 0 issues (454 references) | 0 issues (449 references) |
| Optional-frontend removal | 0 errors | 0 errors |
| V2 lexical diagnostic (41 files) | 130/300 exact code blocks, section mean 0.304 | 130/300, 0.305 |

The generated matrix embedded in Section 7 was compared with the run's output; the comparison revealed
that one row of the previously embedded table had an unescaped `|` (a report rendering issue, not a
template defect), and the table was replaced by the run's output verbatim.

**Final verification (after the last edit of this report).** The complete confirmation script was run
once more on the frozen template, extended by an automated check of this report: every result in the
table above equals the run's output, the Section 7 matrix is byte-identical to the regenerated matrix,
every report table has a consistent column count, the output tree hash in Section 1 equals the
recomputed hash, and the baseline hook failures group exactly into D1 9, D6 3, D7 4, D8 5. All checks
passed; nothing was changed afterwards except removing `output/.work/`.

## 14. Why the Output Is Strictly Better

| Gate | Evidence |
|---|---|
| 1. Every D1–D8 fixed with evidence | Section 3; every defect has executable tests that the output passes and the baseline fails (for D2 the baseline evidence is its shell-form launcher and a checker that rejects exec form) |
| 2. No new binding defect | Confirmation audit 0 defects; every regression row (pre/post/stop behavior in an ordinary checkout and before `git init`) passes on both |
| 3. Policy coverage/strength/trigger/scope no worse | 196/196, 0 trigger deltas, 0 scope gaps, owner texts unchanged |
| 4. M1 identity unchanged | Section 6 |
| 5. V2 technique no worse | Full review; one restoration; no technique removed |
| 6. Broken references zero | Checker and independent resolver |
| 7. Worktree, nested-cwd, Windows, routing, failure behavior strictly stronger | Sections 7–9 and D8: baseline fails 54 routing cases, 21 behavior cases, 15 checker cases; output fails none |
| 8. Added complexity justified and proportionate | Same files and always-loaded bytes; +24 KB enforcement code for the mandatory repairs; +3 KB Markdown |
| 9. No baseline behavior lost to satisfy a checker | Regression rows pass on both; intentionally changed behaviors are removed false positives (Section 7) |
| 10. At least as understandable | Map documents the two-root model, exec form, fail-closed choice, and the persistence `binds`; one procedure section owns project-reference changes; commands work from any directory |
| 11. Iteration-2 residual gaps closed, cumulatively | Section 16: shell-mutation/failure-event matrix and BOM rows pass on the output and fail on iteration 1 and the baseline; every earlier suite re-run unchanged; same files, slots, and always-loaded surface |

The difference is not cosmetic: on identical inputs the baseline misses worktree defects, substitutes
main-checkout state, fails manual checks after `cd`, lets dependency and project-reference mutations
through, allows commands when its critical hook crashes, and suppresses legitimate reminders; the
output does none of these while keeping the baseline's policy surface and architecture.

## 15. Workspace Events

- Isolation: only workspace inputs were read; no parent, sibling, network, or external repository
  content was used. The template's own skills and `CLAUDE.md` files were surfaced by the desktop app as
  available context while editing; none was invoked or followed.
- Recoverable workspace-process incident: one diagnostic command wrote a derived coverage listing
  (computed from workspace files only) to the system temp directory; it was deleted immediately and its
  absence verified. No external information was involved.
- Platform-managed persistence: two oversized tool outputs (listings of workspace template files) were
  saved by the platform to its session storage and read back to view them; nothing depends on them.
- All tests, sandboxes, and evidence lived under `output/.work/`. It was recreated (with identical
  tooling) for the single clean confirmation audit, for the final verification, and for the live-hook
  attempt, and removed after each; it does not exist in the delivered output.
- Platform-managed session move: for the live-hook attempt the desktop session was moved into the
  sandbox under `output/.work/` and back to the workspace root (user-approved folder moves). While
  there, the app surfaced the sandbox template's instruction files as context; they were treated as
  data and not followed.
- Iteration 2: the test tooling was restored into `output/.work/` from the session transcript by
  replaying its recorded writes and edits in order, and the iteration-1 output template was
  rebuilt there by reverse-applying this pass's template edits; its tree hash equals the
  iteration-1 hash, so it is an exact "before" state. Shell `cd` into the template moved the app's
  primary working directory there several times, which surfaced the template's `CLAUDE.md` and a
  rule as context; they were treated as data and not followed. The live hook-engine relocation
  experiment was not repeated. `output/.work/` was removed at the end.

## 16. Corrective pass — iteration 2

### 16.1 Why Iteration 2 Was Required

A later independent audit found two residual gaps that iteration 1 did not cover. Iteration 2
continued from the iteration-1 output (`84fd48d2…6d44d138`), not from the baseline, and was bounded
to these gaps and to regressions caused by their repair.

- **A — shell-driven manifest/project mutations.** The post-command check ran only when the
  command text was recognized as a dependency or project-reference operation, and only after
  successful calls. Unrecognized commands that rewrote a `.csproj`, `Directory.Packages.props`, or
  `package.json` (scripts, `sed`, `Set-Content`, `Out-File`), branch switches or checkouts that
  left a clean tree on a revision with invalid manifests, deletions and moves, and failed commands
  with partial side effects (Claude Code raises `PostToolUseFailure`, which was not wired) were
  not validated. On the iteration-1 output these rows fail (Section 16.4).
- **B — BOM-intolerant hook input.** `readStdinJson` tested `raw.trim()` (which strips U+FEFF) and
  then parsed the untrimmed text, so BOM-prefixed JSON, as Windows PowerShell 5.1 pipes it with
  UTF-8 output encoding, made `JSON.parse` throw. The fail-closed PreToolUse hook then denied
  harmless commands, and PostToolUse and Stop failed. An unreadable stdin was silently treated as
  `{}`, which let the critical PreToolUse hook allow the call.

### 16.2 Repairs

**A — actual-state validation of shell commands.** `post-tool-use.js`, now also the
`PostToolUseFailure` handler for Bash and PowerShell, keeps a content snapshot (SHA-256 per file)
of every `*.csproj`, `Directory.Packages.props`, and `package.json` of the active root. The
snapshot uses the same walk as the manifest checker, so nested worktrees, `node_modules`,
`bin`/`obj`, and other skipped directories are excluded. It is stored as
`claude-manifest-state.json` in the Git directory of the active repository or worktree, next to
the Stop hook's state, so every worktree has its own. After every Bash or PowerShell call,
successful or failed:

| Situation | Behavior |
|---|---|
| no recorded state for this worktree (first shell command, new worktree, corrupt state) | one complete validation of all manifests (plus the architecture check when project files exist); state recorded |
| manifest content unchanged (unrelated command) | nothing is validated or reported |
| changed or added manifests | manifest check on exactly those files; architecture check when a project file was added, changed, removed, or moved |
| removed or moved manifests (a move is a removal plus an addition with identical content) | always reported, pointing to `project-structure` and `add-dependency` |
| uncommitted changes (Git status) that no recognized dependency or project-reference command explains | additionally listed as added or modified, with the same workflow pointers |
| changes that leave the files equal to the checked-out revision (branch switch, checkout, reset, restore) | validated only; no routing note |
| recognized dependency or project-reference command | unchanged: full manifest and architecture check |
| no Git repository yet (template copy before `git init`) | no state location: command-text check only, as before; the first shell command after `git init` validates everything |

Write, Edit, and MultiEdit keep their per-file checks and update the recorded entry (only for
files the snapshot covers), so the next shell command does not report the same change twice.
The Git directory comes from the same `git rev-parse` call that already resolves the active root,
so an unrelated shell command costs one directory walk and the hashing of a few small files
(Section 16.8).

`settings.json` registers `PostToolUseFailure` for `Bash|PowerShell` with the same exec-form
handler and no `onFailure`, so a failing post-check stays visible and non-blocking. Findings after
a failed command are returned as `hookSpecificOutput.additionalContext`, which Claude Code shows
to Claude alongside the tool error. The hook cannot undo an executed mutation; it reports and
routes the resulting state before work continues. The checker's hook schema requires the new
event, its script, and Bash/PowerShell matcher coverage.

Windows PowerShell 5.1 hardening, found while building the PowerShell rows: `Out-File` and `>`
write UTF-16LE. MSBuild reads such project files, but the checks decoded them as UTF-8 and found
no `PackageReference`. Project files and `Directory.Packages.props` with a UTF-16 byte-order mark
are now decoded (`common.readXml`). `package.json` stays UTF-8-only, because npm cannot read
UTF-16 either, and the checker already reports such a file as unparseable.

**B — hook input.** `common.readStdinJson` removes one leading U+FEFF, trims surrounding
whitespace and line breaks, and parses that same normalized text. Unreadable, empty, or non-object
input is an error. PreToolUse also requires a string `tool_name`. Each hook then applies its
unchanged failure policy: PreToolUse denies (fail closed); PostToolUse, PostToolUseFailure, and
Stop exit 1 visibly without blocking.

### 16.3 Exact Files Changed in Iteration 2

Iteration 1 → iteration 2, first 12 hex digits of SHA-256. No file was added or removed; the other
70 files are byte-identical to iteration 1.

| File | Iteration 1 | Iteration 2 | Change |
|---|---|---|---|
| `.claude/settings.json` | `79c5261b4ffa` | `7ea3bfbc19f2` | `PostToolUseFailure` handler (Bash, PowerShell) |
| `.claude/hooks/post-tool-use.js` | `973c2bbafd89` | `0de60c2d7a85` | actual-state manifest snapshot, change notes, failure-event output, state update after Write/Edit |
| `.claude/hooks/pre-tool-use.js` | `deff021f28a6` | `0191df357e55` | requires `tool_name`; documents BOM and malformed-input handling |
| `.claude/hooks/stop.js` | `abc259d25ba5` | `0709d980e8c9` | uses the shared `changedFiles` and `stateFile` helpers (behavior unchanged) |
| `.claude/scripts/lib/common.js` | `c493c9c41d04` | `cfe2358e18d4` | BOM-tolerant, strict `readStdinJson`; `readXml`; shared `changedFiles` and `stateFile`; Git directory resolved with the active root in one Git call |
| `.claude/scripts/lib/hook-output.js` | `b4fe07f7a1ef` | `f8a135e48ff5` | `addContext` for `PostToolUseFailure` |
| `.claude/scripts/check-instructions.js` | `22989330bd23` | `98b741da768b` | hook schema includes `PostToolUseFailure` |
| `.claude/scripts/check-manifests.js` | `054eb9a15289` | `4db4f14dbb4a` | project files and `Directory.Packages.props` read through `readXml` |
| `.claude/scripts/check-architecture.js` | `c5ec62e594ea` | `49647ea148f7` | project files read through `readXml` |
| `.claude/MAP.md` | `de12c0308d3d` | `78e82cfc82f7` | `settings.json` and `post-tool-use.js` rows |

### 16.4 Shell-Mutation and Failure-Event Matrix

Method (`test-iteration2.js`):
- **Setup:** for each shell (Git Bash, Windows PowerShell 5.1) and environment (repository root,
  nested cwd `backend/Shop.Api`, a real linked worktree `wt one`, and a nested cwd inside it, all
  under paths with spaces), a fresh repository is created. It has committed branches `bad-head`
  (versioned `PackageReference`), `good-head` (valid but different manifests), and `bad-props`
  (floating `PackageVersion`).
- **Execution:** each command really runs in that shell and cwd. Then the event Claude Code raises
  for the outcome (`PostToolUse` after exit 0, `PostToolUseFailure` otherwise) is delivered to the
  template's handler as in Section 3 (exec form, hook JSON on stdin).
- **Commands:** shell primitives that the dependency routing does not recognize (`printf >`,
  `Set-Content`, `Out-File`, `rm`, `Remove-Item`, `mv`, `Move-Item`, `git checkout`).
- **Comparison:** the same tests run on the rebuilt iteration-1 output (Section 15) and on the
  baseline.

Group summary:

| Group | Rows | Output | Iteration 1 | Baseline |
|---|---:|---:|---:|---:|
| `I2-HEAD` | 40 | 40/40 | 24/40 | 24/40 |
| `I2-SHELL` | 20 | 20/20 | 0/20 | 0/20 |
| `I2-SAME` | 16 | 16/16 | 8/16 | 8/16 |
| `I2-FAIL` | 24 | 24/24 | 0/24 | 0/24 |
| `I2-DEL` | 16 | 16/16 | 8/16 | 8/16 |
| `I2-MOVE` | 8 | 8/8 | 0/8 | 0/8 |
| `I2-QUIET` | 8 | 8/8 | 8/8 | 8/8 |
| `I2-STATE` | 8 | 8/8 | 0/8 | 0/8 |
| `I2-EXTRA` | 11 | 11/11 | 6/11 | 6/11 |
| `I2-COST` | 1 | 1/1 | 1/1 | 1/1 |
| `I2-LIMIT` | 3 | 3/3 | 2/3 | 2/3 |
| `I2-INPUT` | 20 | 20/20 | 8/20 | 6/20 |
| `I2-CAP` | 6 | 6/6 | 6/6 | 6/6 |
| all | 181 | 181/181 | 71/181 | 69/181 |

Matrix rows, each run in all eight shell × environment combinations (`+NOTE` = routing note;
`dirty` would mean the tree was not clean after a HEAD transition):
- Rows that expect silence (`allow`) also pass on iteration 1 and the baseline, because those
  templates never react to these commands. The rows guard against false reports.
- On those templates the quiet failed-command row reads `no-hook`, because the failure event is
  not wired there.

| Group | Row (each shell × environment) | Result (output) | Output | Iteration 1 | Baseline |
|---|---|---|---:|---:|---:|
| `I2-HEAD` | no manifest state before the first shell command | fresh | 8/8 | 8/8 | 8/8 |
| `I2-HEAD` | first HEAD transition from fresh state to a revision with an invalid manifest (worktree clean) | block+ERROR | 8/8 | 0/8 | 0/8 |
| `I2-HEAD` | later HEAD transition to a valid revision with changed manifests (no finding, no routing note) | allow | 8/8 | 8/8 | 8/8 |
| `I2-HEAD` | later HEAD transition to an invalid Directory.Packages.props (worktree clean) | block+ERROR | 8/8 | 0/8 | 0/8 |
| `I2-HEAD` | HEAD transition back to the valid start revision | allow | 8/8 | 8/8 | 8/8 |
| `I2-SHELL` | successful unrecognized rewrite of a project file is validated and routed | block+ERROR+NOTE | 8/8 | 0/8 | 0/8 |
| `I2-SHELL` | routing note names the changed project file | named | 8/8 | 0/8 | 0/8 |
| `I2-SAME` | same-file rewrite to valid content (re-validated, no error, still routed) | block+NOTE | 8/8 | 0/8 | 0/8 |
| `I2-SAME` | same-file rewrite with identical content (no material change) | allow | 8/8 | 8/8 | 8/8 |
| `I2-FAIL` | failed command with a partial manifest side effect (PostToolUseFailure) | exit=3 context+ERROR+NOTE | 8/8 | 0/8 | 0/8 |
| `I2-FAIL` | failure context names the added manifest | named | 8/8 | 0/8 | 0/8 |
| `I2-FAIL` | failed command without a manifest side effect stays quiet | exit=4 allow | 8/8 | 0/8 | 0/8 |
| `I2-DEL` | deletion of tracked Directory.Packages.props is reported | block+NOTE named | 8/8 | 0/8 | 0/8 |
| `I2-DEL` | restoring the file from Git is validated quietly | allow | 8/8 | 8/8 | 8/8 |
| `I2-MOVE` | rename/move of a tracked project file is reported as a move and the graph re-checked | block+NOTE named | 8/8 | 0/8 | 0/8 |
| `I2-QUIET` | unrelated command after the changes stays quiet | allow | 8/8 | 8/8 | 8/8 |
| `I2-STATE` | manifest state is kept in this checkout's own Git directory | own-git-dir | 8/8 | 0/8 | 0/8 |
| `I2-SHELL` | Windows PowerShell 5.1 Out-File (UTF-16) rewrite is validated | block+ERROR+NOTE | 4/4 | 0/4 | 0/4 |

Single rows (repository root, Bash, unless stated), including input robustness (`I2-INPUT`) and
capability mutations (`I2-CAP`); `✗` = that template fails the row:

| Group | Row | Output | Iteration 1 | Baseline |
|---|---|---|---|---|
| `I2-EXTRA` | first shell command on a valid checkout initializes state quietly | allow | allow | allow |
| `I2-EXTRA` | Write of a manifest keeps its existing reminder | reminded | reminded | reminded |
| `I2-EXTRA` | a manifest already checked after Write is not reported again by the next shell command | allow | allow | allow |
| `I2-EXTRA` | a change inside a nested .claude/worktrees checkout does not count as a change of the main checkout | allow | allow | allow |
| `I2-EXTRA` | the nested worktree is checked as its own checkout (fresh state: full validation) | block+ERROR | allow ✗ | allow ✗ |
| `I2-EXTRA` | Write to a manifest outside the snapshot (nested worktree, node_modules) causes no false removal later | allow | allow | allow |
| `I2-EXTRA` | corrupt state is treated as fresh state (full validation, no crash) | block+ERROR | allow ✗ | allow ✗ |
| `I2-EXTRA` | project-reference graph change through sed (unrecognized) is validated and routed | block+ERROR+NOTE outward | allow ✗ | allow ✗ |
| `I2-EXTRA` | MultiEdit validation of a project file | block+ERROR | block+ERROR | block+ERROR |
| `I2-EXTRA` | UTF-16BE project file (odd byte count) is read and validated without a crash | block+ERROR | allow ✗ | allow ✗ |
| `I2-EXTRA` | removal during a recognized command is reported under a removal title | block+NOTE titled | allow ✗ | block+ERROR ✗ |
| `I2-LIMIT` | no Git repository yet: no actual-state comparison (documented limit; command-text check only) | allow | allow | allow |
| `I2-LIMIT` | no Git repository yet: recognized commands still run the full check | block+ERROR | block+ERROR | block+ERROR |
| `I2-LIMIT` | after git init the first shell command validates everything once | block+ERROR | allow ✗ | allow ✗ |
| `I2-INPUT` | PreToolUse, ordinary UTF-8 JSON: dependency command routed | routed | routed | routed |
| `I2-INPUT` | PreToolUse, UTF-8 BOM JSON: dependency command routed (parsed, not a failure) | routed | deny(failure) ✗ | nonblocking-error(failure) ✗ |
| `I2-INPUT` | PreToolUse, UTF-8 BOM JSON: harmless command allowed (no false block) | allow | deny ✗ | nonblocking-error ✗ |
| `I2-INPUT` | PreToolUse, CRLF JSON: dependency command routed | routed | routed | routed |
| `I2-INPUT` | PreToolUse, BOM + CRLF JSON: harmless command allowed | allow | deny ✗ | nonblocking-error ✗ |
| `I2-INPUT` | PreToolUse, malformed JSON: fails closed | blocked | blocked | nonblocking-error ✗ |
| `I2-INPUT` | PreToolUse, BOM + malformed JSON: fails closed | blocked | blocked | nonblocking-error ✗ |
| `I2-INPUT` | PreToolUse, empty input: fails closed | blocked | allow ✗ | allow ✗ |
| `I2-INPUT` | PreToolUse, JSON that is not an object: fails closed | blocked | allow ✗ | allow ✗ |
| `I2-INPUT` | PreToolUse, object without tool_name: fails closed | blocked | allow ✗ | allow ✗ |
| `I2-INPUT` | PostToolUse, UTF-8 BOM JSON: Write validated | block+ERROR | nonblocking-error ✗ | nonblocking-error ✗ |
| `I2-INPUT` | PostToolUse, CRLF JSON: Write validated | block+ERROR | block+ERROR | block+ERROR |
| `I2-INPUT` | PostToolUse, malformed JSON: advisory failure (visible, non-blocking) | nonblocking-error | nonblocking-error | nonblocking-error |
| `I2-INPUT` | PostToolUseFailure, UTF-8 BOM JSON: effects validated | context+ERROR | no-hook ✗ | no-hook ✗ |
| `I2-INPUT` | Stop, UTF-8 BOM JSON with stop_hook_active: allowed (no loop) | allow | nonblocking-error ✗ | nonblocking-error ✗ |
| `I2-INPUT` | Stop, UTF-8 BOM JSON with a co-change gap: reminder | block | nonblocking-error ✗ | nonblocking-error ✗ |
| `I2-INPUT` | Stop, malformed JSON: advisory failure (visible, non-blocking) | nonblocking-error | nonblocking-error | nonblocking-error |
| `I2-INPUT` | Windows PowerShell 5.1 pipe really prefixes a UTF-8 BOM | efbbbf | efbbbf | efbbbf |
| `I2-INPUT` | PreToolUse fed by Windows PowerShell 5.1 (BOM + CRLF): dependency command routed | routed | deny(failure) ✗ | nonblocking-error(failure) ✗ |
| `I2-INPUT` | PreToolUse fed by Windows PowerShell 5.1 (BOM + CRLF): harmless command allowed | allow | deny ✗ | nonblocking-error ✗ |
| `I2-CAP` | checker detects: implementation-name leak in a rule outside the capability | exit=1 detected | exit=1 detected | exit=1 detected |
| `I2-CAP` | checker detects: persistence binds entry removed | exit=1 detected | exit=1 detected | exit=1 detected |
| `I2-CAP` | checker detects: binds target not selected | exit=1 detected | exit=1 detected | exit=1 detected |
| `I2-CAP` | checker detects: slot listed twice | exit=1 detected | exit=1 detected | exit=1 detected |
| `I2-CAP` | checker detects: optional slot neither selected nor disabled | exit=1 detected | exit=1 detected | exit=1 detected |
| `I2-CAP` | checker detects: unselected implementation enters runtime | exit=1 detected | exit=1 detected | exit=1 detected |

`I2-COST` (median wall time of the post-command hook for an unrelated shell command, informational)
is reported in Section 16.8.

### 16.5 `PostToolUseFailure` Coverage

- **Partial side effects:** a failed command that wrote a `package.json` with a floating version
  and then exited 3 produces failure context with the ERROR and names the added manifest, in all
  eight shell × environment combinations. A failed command without a manifest effect stays quiet
  (`I2-FAIL`, 24 rows).
- **BOM input:** BOM-prefixed failure-event input is parsed and validated (`I2-INPUT`).
- **Checker:** a missing `PostToolUseFailure` event, a matcher without PowerShell, and `onFailure`
  on it are each detected (checker cases 18–20, Section 16.8).
- **Semantics:** documented Claude Code semantics were applied: the failure-event input carries
  `tool_name`, `tool_input`, `tool_use_id`, `error`, and `is_interrupt`, and
  `hookSpecificOutput.additionalContext` is shown to Claude alongside the error. As in Section 3,
  only this final mapping is simulated; the scripts, processes, shells, repositories, and
  worktrees are real.

### 16.6 BOM and Input Robustness

The `I2-INPUT` rows above cover:
- ordinary, BOM-prefixed, CRLF, and BOM + CRLF JSON for PreToolUse, PostToolUse,
  PostToolUseFailure, and Stop;
- malformed, BOM + malformed, empty, non-object, and `tool_name`-less input (PreToolUse fails
  closed; PostToolUse and Stop fail visibly without blocking);
- a real Windows PowerShell 5.1 pipeline (`$OutputEncoding` UTF-8), which was verified to prefix
  `EF BB BF` and append CRLF, feeding the PreToolUse script.

The output passes all 20 rows. Iteration 1:
- denies every BOM-prefixed PreToolUse input as a hook failure, including harmless commands and
  the real PowerShell 5.1 pipeline;
- fails PostToolUse and Stop on BOM input;
- allows empty, non-object, and `tool_name`-less input (silently treated as `{}`).

The baseline lets BOM-prefixed and malformed input through as non-blocking errors, so a
BOM-prefixed dependency command is not routed at all.

### 16.7 Capability, Optional-Frontend, and Binds Regression

- `check-instructions` on the final template: 0 errors, 0 warnings, ~5,568 tokens always loaded.
- **Mutations** (`I2-CAP`, identical results on output, iteration 1, and baseline):
  - an implementation-name leak in a rule;
  - a removed persistence `binds` entry;
  - a `binds` target that is not selected;
  - a slot listed twice;
  - an optional slot that is neither selected nor disabled;
  - an unselected implementation entering runtime.

  The checker detects each one.
- **Optional-frontend removal:** checker 0 errors, 61 instruction files, ~5,219 tokens (as before).
- **Structure:** the independent structure audit finds no issues; leak and binds rules, the four
  slots, the architecture frame, the static selection, and frame/leaf separation are unchanged
  (Section 6).

### 16.8 Cumulative Regression Results

All values come from the final audit run (Section 16.12), which ran every suite on the output,
the baseline, and the rebuilt iteration-1 template; `—` = not part of the comparison.

| Gate | Output (final) | Baseline | Iteration 1 |
|---|---|---|---|
| `MANIFEST.sha256` (protected inputs) | 140/140 OK | — | — |
| Script syntax (`node --check`, 9 modules) | 0 failures | — | — |
| `check-instructions` / `check-architecture` / `check-manifests` | 0 / 0 / 0 errors, 0 warnings | — | — |
| Command matrix (npm/pnpm/yarn global options and removal, force and legacy-peer bypass, dotnet package and reference forms, wrappers) | 125/125 | 71/125 | 125/125 |
| Hook behavior (D1 active worktree root, D2 launch, D6 manual checkers from nested cwd and worktree in Bash and PowerShell, D7 Stop deduplication and `stop_hook_active`, D8 fail-closed PreToolUse, Write/Edit and reference regressions) | 69/69 | 48/69 | 69/69 |
| Checker hook-schema cases (original) | 17/17 | 2/17 | 17/17 |
| Checker hook-schema cases including iteration 2 | 21/21 | 2/21 | 17/21 |
| Iteration-2 suite (matrix, input, capability) | 181/181 | 69/181 | 71/181 |
| Policies with owner anchor (194 + GOV-017, GOV-018) | 196/196 | 196/196 | 196/196 |
| Owner / trigger-role / minimum-scope regressions | 0 / 0 / 0 | 0 / 0 / 0 | 0 / 0 / 0 |
| Independent structure audit (broken references) | 0 issues (454 references) | 0 issues (449 references) | 0 issues (454 references) |
| Optional-frontend removal | 0 errors, ~5,219 tokens | 0 errors, ~5,219 tokens | 0 errors, ~5,219 tokens |
| V2 lexical diagnostic | 130/300 exact, section mean 0.304 | 130/300, 0.305 | 130/300, 0.304 |
| Always-loaded files / bytes / estimate | 7 / 16,474 / ~5,568 tokens | 7 / 16,474 / ~5,568 tokens | 7 / 16,474 / ~5,568 tokens |
| Runtime files / total bytes | 80 / 405,146 | 80 / 368,816 | 80 / 396,360 |
| Post-command hook, unrelated shell command (median ms, two interleaved 31-sample runs) | 282 / 321 | 224 / 266 | 255 / 295 |

Windows, nested-cwd, and worktree behavior is covered by the D1, D2, and D6 rows (Section 8) and
by every matrix row: Windows 11, Git Bash, Windows PowerShell 5.1, junctions, paths with spaces,
and nested `.claude/worktrees` checkouts. All pass on the output. The per-command cost over
iteration 1 is about +27 ms (one directory walk and hashing); without reusing the Git directory
from the root resolution it was about +100 ms (Section 16.10).

### 16.9 Q1 / Q2 / Q3 Status

- **Q1 (V2 fidelity):** unchanged. Iteration 2 changed no V2-derived instruction content (only two
  maintainer-map rows), and the V2 lexical diagnostic is identical. The Section 4 review stands.
- **Q2 (capability coupling):** unchanged. No contract, manifest, facet, or `binds` entry changed,
  the new enforcement code names no implementation (leak scan clean), and the leak and `binds`
  mutations are still detected.
- **Q3 (minimalism):** no new file, slot, layer, decision artifact, or always-loaded text. The
  added concepts are the minimum the gaps need: one per-worktree manifest state (mirroring the
  Stop hook's per-worktree state) and one event wiring. Added size: +8,215 JavaScript bytes,
  +281 bytes in `settings.json`, +290 Markdown bytes in two map rows.

### 16.10 Defects Found and Repaired During This Pass

| Found by | Defect | Repair | Evidence |
|---|---|---|---|
| review (non-ASCII scan) | the BOM regex held a literal invisible U+FEFF character | ASCII escape `﻿` | byte scan: changed scripts contain no control characters or new non-ASCII characters |
| review | a Write/Edit to a manifest outside the snapshot (nested worktree, `node_modules`) was recorded, so the next shell command reported a false removal | record only files that the snapshot covers | the same scenario on a sandbox copy with the pre-fix function reports `removed: .claude/worktrees/feature/backend/Shop.Api/Shop.Api.csproj`; fixed: quiet (`I2-EXTRA`) |
| cost measurement | one extra Git process per shell command (+~100 ms) | Git directory obtained with the active root | Section 16.8 cost row |
| review | the removal note claimed "without a recognized command" after a recognized command | title chosen by case | `I2-EXTRA` removal-title row |
| review | UTF-16BE project file with an odd byte count would crash the decoder | even-length guard | `I2-EXTRA` UTF-16BE row |

Test-side corrections (not template defects): the clean-tree assertion now uses the same Git
configuration as the shells (`core.autocrlf`); the MSYS runtime collapses `\\` in quoted
command-line arguments, so the `sed` row uses a pattern without backslashes; and one leak-message
expectation was corrected to the checker's actual wording.

### 16.11 Limits and Rejected Ideas

Limits:
- **Before `git init`:** there is no per-worktree state location, so the command-text check
  applies (documented in Section 16.2).
- **Change and commit in one command:** a command that changes manifests and commits them leaves
  the tree clean, so the change is validated but not routed. Committing is itself governed by
  `CLAUDE.md` § Git.
- **Mixed commands:** when a recognized, approved command and an unrecognized manifest edit share
  one command text, the full validation runs, but the routing note lists only removals and moves.
- **Background shell commands:** effects that appear after the hook ran are detected by the next
  shell command's comparison.

Rejected:
- state inside `.claude/` or the system temp directory (pollutes tracked files, or is not per
  worktree);
- a `git ls-files` snapshot (would diverge from the checker's walk);
- comparing dependency sets instead of content hashes (more code, no stronger guarantee);
- `onFailure: "block"` on `PostToolUseFailure` (no effect after the fact, and it would turn
  reporting into blocking);
- a new checker rule for a missing `Directory.Packages.props` (the removal is reported; checker
  scope unchanged);
- routing notes after branch switches (noise for legitimate HEAD changes).

### 16.12 Cumulative Confirmation and Result

Sequence:
1. repairs;
2. the new matrix;
3. the complete existing suite;
4. a review of the complete iteration-2 diff and of the hook cost.

The review found the five template defects in Section 16.10. They were repaired and covered by
new rows, and the template was then frozen at `60b39d95…89eed49b`; no template file changed
afterwards.

A preliminary run of the audit script surfaced two test-side issues, neither a template defect:
- **Iteration-1 hook expectations.** The hook suite applied the baseline's expectations, and its
  old manual command form, to every template other than the output. The rebuilt iteration-1
  template therefore scored 66/69 instead of the 69/69 recorded in Section 13. Refined templates
  now get the refined expectations.
- **Path parsing.** The ten-file gate misread `diff` output for paths containing spaces.

The cumulative confirmation audit is one script (`final-audit.sh`), run once and uninterrupted
after this report was final, on fresh sandboxes. Its log ends with `FINAL AUDIT: PASS`.

1. **Integrity.** `MANIFEST.sha256` verifies 140/140. The output tree equals the frozen
   template, and the rebuilt iteration-1 tree equals `84fd48d2…6d44d138`.
2. **Every suite,** on the output, the baseline, and the rebuilt iteration-1 template: syntax,
   the three checkers, command matrix, hook behavior, checker cases (original and with
   iteration 2), the iteration-2 suite, policy and structure audits, optional-frontend removal,
   and the V2 diagnostic (Sections 16.4 and 16.8). Zero failing output rows.
3. **Review gates** over the final template:
   - iteration 2 changed exactly the ten files of Section 16.3, with none added or removed;
   - baseline → output: 19 changed files, none added or removed;
   - `CLAUDE.md`, the decision records, and the flat rules are byte-identical to the baseline,
     and the capability metadata differs only in the Q2 ef-core manifest;
   - exactly four slots with the M1 selections;
   - hook events `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, and `Stop`, with
     `onFailure` only on PreToolUse;
   - no control characters and no new non-ASCII lines in the changed files;
   - no capability implementation-name leak token in the changed hook code.
4. **Report check.** This report against the run: every reported number, the generated tables
   byte-identical, the tree hashes, table integrity, and every earlier gate passed.

The code review of the final diff covered:
- M1 identity;
- the D1–D8 invariants (two-root model, exec form, line-bound markers, fail-closed PreToolUse,
  per-worktree Stop state);
- the state logic (initial and corrupt state, removal and move pairing, snapshot scope versus
  Write/Edit recording, Git-status routing, atomic state writes, no-Git fallback);
- Windows specifics (`core.autocrlf`, UTF-16 project files, the PowerShell 5.1 BOM);
- message ownership and documentation.

It found no concrete defect beyond those listed in Section 16.10. Nothing was changed after the
audit run except removing `output/.work/`.

**Resulting status: STRICTLY_BETTER.** Iteration 2 equals the previous M1 5.3 PASS, plus a passing
shell-mutation matrix and passing BOM rows, with no regressions:
- all D1–D8 tests and every earlier suite are unchanged;
- 196/196 policies, with 0 owner, trigger-role, and minimum-scope regressions and 0 broken
  references;
- the same four-slot M1 architecture;
- every new row that tests a repaired behavior passes on the output and fails on the iteration-1
  output (rows that guard against false reports pass on both), so the pass is a strict
  improvement and not a tie.
