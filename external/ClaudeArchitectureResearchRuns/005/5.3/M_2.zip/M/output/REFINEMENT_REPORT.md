# Refinement Report — Candidate M

| Item | Result |
| --- | --- |
| Selected baseline | **M/Run-02** (`baseline/template/`, read only; still 60 files / 340,417 bytes as recorded in `PROVENANCE.json`) |
| Final status | **STRICTLY_BETTER**, cumulative, after the [Final corrective pass](#final-corrective-pass) |
| Final corrective pass | 3 later-found defect classes fixed (fail-closed PreToolUse, shell-driven manifest mutations, content-aware Stop deduplication). The cumulative suite passes 89/89. |
| Confirmed defects D1–D6 | 6/6 fixed, each reproduced on the baseline and shown fixed on the output |
| Additional defects found during the audit and fixed | 3 (double-BOM stdin from PowerShell 5.1; npm bypass through shell wrappers; npm bypass through line continuations) |
| Regression matrix | 56/56 PASS (12 dossier cases, edge cases, baseline evidence, and two parser tables with 76 commands) |
| Policy owner / trigger / scope deltas | 0 / 0 / 0 (196/196 owners carried over unchanged) |
| Broken internal references | 0 |
| Always-loaded context | ~4,766 tokens before and ~4,766 after (byte-identical) |
| Runtime file count | 60 before, 61 after (+`.claude/scripts/repo-root.mjs`) |
| Optional Run-01 ideas | 0 adopted, 1 rejected, 2 deferred |
| Confirmation audit | round 1: 1 cleanup item repaired; round 2 (complete rerun): **0 concrete template defects** |

## Changed Files and Reasons

Thirteen files were modified and one was added. Every other runtime file is byte-identical to the baseline.

| File | Reason |
| --- | --- |
| `.claude/settings.json` | **D1.** All four hooks now use exec form: `"command": "node"` with `"args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.mjs"]`. No shell is involved and no command string depends on the current directory. |
| `.claude/scripts/repo-root.mjs` (new) | **D2/D6.** One resolver for the hooks and the checkers. It keeps two roots apart: the *template root*, found from the script's own location and used only to find the installed scripts, and the *active root*. The active root is computed from a start directory: (1) the same repository's Git working tree, confirmed by a shared common Git dir so linked worktrees count, plus the template's offset inside its tree; (2) otherwise, the template root when the start directory is inside it (no Git, or a submodule); (3) otherwise a clear error. It never treats `CLAUDE_PROJECT_DIR` as repository state. |
| `.claude/hooks/hook-io.mjs` | **D2.** The `CLAUDE_PROJECT_DIR`-based `projectRoot()` was replaced by `startDirectory(input)` (the input `cwd`) and `activeRoot(input)`, which fails visibly with "Repository checks were NOT run". `repoRelative` now canonicalizes paths. **Audit fix:** leading BOMs are stripped with `/^﻿+/`, because the Windows PowerShell 5.1 UTF-8 pipe sends two BOMs. |
| `.claude/hooks/dependency-guard.mjs` | **D4:** a table-driven npm parser. It skips global options and their values (`NPM_VALUE_OPTIONS`), and a token that is not a known npm command is treated as an option value, so it cannot hide the real subcommand. It also detects `npm_config_force`/`npm_config_legacy_peer_deps`, `npm config set force`, `npm set`, and `=false`. **D3:** detects `dotnet add/remove <proj> reference`, `dotnet reference add/remove`, and the package forms. Project-reference changes are classified separately from packages and routed to `architecture.md` § Project References and CLAUDE.md § Decision Control, not to `add-dependency`. **D2:** the manifest check runs on the active root. **Audit fixes:** joins `\`/`` ` `` line continuations and unwraps `cmd /c`, `bash -c`/`-lc`, and `powershell`/`pwsh -Command`. |
| `.claude/hooks/file-change.mjs` | **D2.** The active root for an edit is the checkout or worktree that contains the edited file (a relative `file_path` resolves against `cwd`). Edits in a worktree are no longer skipped silently. |
| `.claude/hooks/stop-co-change.mjs` | **D2.** Git state (status and the per-worktree state dir) is read from the active root derived from `cwd`, not from the main checkout. |
| `.claude/scripts/check-manifests.mjs` | **D2/D6.** The CLI root comes from the current directory through `repo-root.mjs`. `<file>` arguments resolve against the current directory, `isMain` compares canonical paths, and the usage header states the root precondition. |
| `.claude/scripts/check-instructions.mjs` | **D5.** Requires exec form: `type: command`, `command: node`, exactly one argument matching `${CLAUDE_PROJECT_DIR}/.claude/hooks/<name>.mjs`, and a script that exists under the root being checked. It rejects shell strings, `$VAR`/`%VAR%`, relative arguments, other executables, paths outside the hooks directory, and extra arguments. **D6:** its root comes from the current directory. |
| `.claude/skills/verify/SKILL.md`, `add-dependency/SKILL.md`, `project-structure/SKILL.md`, `project-structure/references/backend-layout.md` | **D6.** Each checker or root-relative CLI step now says to run it from the repository root, i.e. the top level of the current checkout or worktree (`git rev-parse --show-toplevel`). Only the invocation lines changed. |
| `.claude/skills/template-maintenance/SKILL.md` | **D1/D2/D5/D6.** The old "shell-neutral `node <script>`" invariant described the defective launcher and now describes exec form and root derivation. Step 4 adds the root precondition. |
| `.claude/MAP.md` | Accuracy for D1/D2/D3/D5/D6: the settings, hook-io, dependency-guard, and check-instructions rows, the architecture enforcement cell, and step 6's root precondition. The new `repo-root.mjs` row is required by the checker's "MAP lists every script" predicate. |

## D1–D6 Repair Evidence

Each defect was reproduced on the baseline in the same sandbox before being shown fixed on the output.

| Defect | Baseline (reproduced) | Refined |
| --- | --- | --- |
| D1 CWD-dependent launch | T02-baseline: from `backend/Shop.Api`, `node .claude/hooks/...` fails with `Cannot find module` (exit 1) in both cmd.exe and Git Bash. | T01/T02/T02b/T03: exec form works from the root and from nested backend and frontend directories, with no shell. |
| D2 launcher root vs worktree | T05-baseline, T11-baseline: inspects the main checkout. It misses worktree Git changes, skips worktree manifests silently, and misses worktree violations. | T05–T05e, T11–T11c, E04–E06: linked worktrees, nested `.claude/worktrees/<n>`, subdirectory installs, and no-Git copies resolve correctly. A cwd outside every checkout fails visibly (E02/E03). |
| D3 project-reference bypass | T06-baseline: `dotnet add … reference …` is ignored. | T06/T07 + P02: add/remove in both CLI syntaxes are detected and the Domain→Infrastructure violation blocks. Packages and references are never confused (32 cases). |
| D4 npm global options | T09/10-baseline: `--prefix … --force` and `--workspace … --legacy-peer-deps` pass. P01-baseline: 23 of 33 must-block commands pass. | T09/T10 + P01: all 44 PreToolUse cases are correct, including 35 must-block cases and no false blocks on 9 benign ones. |
| D5 checker vs exec form | T12-baseline: the correct exec-form settings fail. | T12a accepts exec form. T12 (12 variants) rejects every unsafe shell or ambiguous form. |
| D6 manual root-relative calls | T13-baseline: the nested relative call fails, and the absolute call checks `CLAUDE_PROJECT_DIR` (main) and misses the worktree violation. | T13a–e: the checkers resolve the active worktree from any nested directory. The documented `git rev-parse --show-toplevel` procedure works in Bash and in PowerShell 5.1. |

## Regression Test Matrix

The sandbox was built under `output/.work/sbx`: Git main checkouts plus linked worktrees for both the refined and the baseline template. Git discovery was capped with `GIT_CEILING_DIRECTORIES`. Hooks were launched exactly as configured: exec form (placeholder substituted, `spawn` without a shell) for the refined template, and the shell command string for the baseline.

| # | Dossier case | Tests | Result |
| --- | --- | --- | --- |
| 1 | Launch from repository root | T01 | PASS |
| 2 | Launch from nested cwd | T02, T02b | PASS |
| 3 | Windows-safe exec form | T03 (Windows, no shell, path with spaces) | PASS |
| 4 | PowerShell 5.1 BOM stdin | T04a (one BOM), T04b (real PS 5.1 pipe), T04c (two BOMs) | PASS |
| 5 | Active root from `cwd`, not the launcher | T05, T05b–e | PASS |
| 6 | `dotnet add … reference` detected | T06, P02 | PASS |
| 7 | Reference removal detected | T07, P02 | PASS |
| 8 | Normal `npm install` detected | T08, T08b | PASS |
| 9 | `npm --prefix … install … --force` blocked | T09, P01 | PASS |
| 10 | `npm --workspace … install … --legacy-peer-deps` blocked | T10, P01 | PASS |
| 11 | Manifest and reference checks on the active worktree | T11, T11b, T11c | PASS |
| 12 | Checker accepts exec form and rejects unsafe forms | T12a + 12 rejection variants | PASS |

Extra coverage, all PASS:
- D6 manual invocation: T13a–e.
- Root edge cases: E01–E06.
- Stop-loop protection and once-per-change-set reminders: T05c, T05d.
- Baseline evidence rows (`*-baseline`), confirming each defect exists in the baseline.
- The documented manual-test commands in each hook header, run in Bash and PowerShell.
- Existing checkers on `output/template`: `check-instructions` reports 48 instruction files, 0 failures, 0 warnings. `check-manifests` reports 0 violations, from the root and, using the absolute script path, from a nested directory.

**Residual limitations (not tested, outside the minimal parser):**
- An unlisted npm value option whose value equals an npm command name.
- `npx npm …`.
- PowerShell `-EncodedCommand`.

These are documented in the hook header. No tested dependency or project-reference case bypasses enforcement.

## Policy Owner / Trigger / Scope Audit

- Every policy owner file is byte-identical to the baseline (23 of 23): CLAUDE.md, the imported stack, both product inputs, all 11 rules, the agent, and the 7 unchanged workflow skills.
- The six changed Markdown files have zero frontmatter changes (descriptions, `paths`, `disable-model-invocation`) and zero `> Owns:` header changes.
- The baseline lines no longer present verbatim are all checker-invocation lines, maintenance-invariant lines, or MAP rows. None carries an inventory policy or a shared invariant.
- The baseline's 196/196 mapping (194 inventory policies plus GOV-017/018) therefore carries over unchanged: 0 owner changes, 0 trigger-role deltas, 0 minimum-scope gaps (rule `paths` are untouched).
- M identity is unchanged:
  - flat `.claude/rules/` and no `Level:`/`Kind:` lines (checker);
  - no capability or decision-register layer;
  - workflow and knowledge separation intact;
  - private references used only by their owner.
- No V2 content was removed.
- The new invocation text is procedure placed next to each command, as D6 requires. It is not a policy restatement.
- Hook messages point to their owners instead of restating policy.

## Hygiene, Dependencies, Context

- **Broken references:** 0 (file, `§` section, skill/agent, import, and private-reference checks). Every JS import resolves.
- **Module graph:** acyclic, with `repo-root.mjs` as the leaf (hooks → hook-io / check-manifests → repo-root).
- **Language and metadata:** English only; no Cyrillic in 61 files. 0 research-metadata hits.
- **`CLAUDE_PROJECT_DIR`:** appears only as the launcher placeholder and in comments. No code reads it as a root.
- **Always-loaded context:** about 4,766 tokens before and after (CLAUDE.md + `docs/technology-stack.md` + skill/agent listings, all byte-identical). This is within the ~5k target.
- **Runtime files:** 60 → 61. The added module exists because a single deterministic root resolver is shared by the hooks and the checkers (D2/D6). No layer or metadata was added.

## Windows / Worktree Hook Result

On Windows 11 with Node 24 and Git 2.55 in a path containing spaces, all hooks run in exec form from any cwd. stdin is accepted from Windows PowerShell 5.1, including its double-BOM UTF-8 pipe. The active root resolves correctly for:
- main checkouts;
- nested subdirectories;
- linked worktrees, both sibling and nested under `.claude/worktrees/`;
- subdirectory installs and their worktrees;
- non-Git copies.

When no root can be established, the hooks fail visibly. Known Windows or worktree hook defects: **0**. The baseline has 5 in this matrix: D1, D2, D6, the double BOM, and wrapper/continuation parsing on Windows shells.

## Optional Run-01 Ideas

| Idea | Decision | Rationale |
| --- | --- | --- |
| Source-level architecture checker | **DEFER** | Only Run-01's report is available, so false-positive rates cannot be assessed. Regex heuristics over C# `using`/namespaces are brittle. The highest-value boundary, the project-reference graph, is now enforced mechanically after both edits and CLI changes. Adding it would add a file without proven net benefit. |
| Destructive-Git confirmation hook | **REJECT** | It duplicates Claude Code's permission prompts. GOV-015 is already always loaded. A hook cannot tell whether the user explicitly asked for the operation, so it would prompt on requested operations (noise), and it would add another command-parser surface. |
| Auto instruction-structure check after edits | **DEFER** | Multi-file edits pass through valid intermediate states (for example, a new file before its MAP row) that would raise transient failures and blocks. `template-maintenance` already mandates the checker, and there is no evidence of a net benefit. |

## Rejected or Reverted Proposed Changes

- **Git top level as the only active root:** rejected. It would regress subdirectory installs, which the baseline supported. The same-repository offset mapping covers that case (E06).
- **A one-line root-anchored command (`node "$(git rev-parse --show-toplevel)/…"`):** rejected. It breaks for subdirectory installs and non-Git copies and is less readable. Kept the explicit precondition plus cwd-derived resolution.
- **Quote-aware tokenizer rewrite:** rejected. Not required, and it would drift toward a general shell parser. The fallback scan handles quoted paths (P01).
- **PreToolUse pre-blocking of project references:** rejected. The PostToolUse check and block already cover it with less parsing.
- **MSYS-path conversion of `cwd`:** rejected as speculative. Claude Code supplies native paths, and a failure would be visible.
- **Rewording `architecture.md` / `dependencies.md` enforcement sentences:** omitted. They are still true, and changing them would churn path-loaded rules.
- **Confirmation round 1:** an unused `baseDir` parameter and a cosmetic comment rewording in `hook-io.repoRelative` were reverted to baseline form.

## Confirmation Audit

Round 1 rechecked every gate and every changed item. It found one non-functional cleanup item, the unused parameter and cosmetic rewording above. That item was repaired.

Round 2 was a complete rerun after the repair:
- harness 56/56;
- both checkers clean, from the root and from nested directories;
- module syntax checks clean;
- change scope limited to 13 modified and 1 added file;
- policy-owner invariance 23/23;
- frontmatter and headers unchanged;
- language and metadata scans clean;
- budget equal;
- documented manual commands correct in Bash and PowerShell.

Round 2 found **0 concrete template defects**, so convergence is established.

**Promotion gate:**
1. D1–D6 fixed.
2. 5.2 acceptance gates still pass.
3. No policy, scope, or trigger regressions.
4. 0 broken references.
5. M identity unchanged.
6. Windows and worktree behavior demonstrably stronger.
7. No tested bypass.
8. No new semantic duplication.
9. V2 content retained.
10. Context equal.
11. +1 file, with a reliability purpose.
12. Every change documented above.

All twelve hold, so the result is **STRICTLY_BETTER**.

## Workspace Events

- **Isolation violations:** 0. No parent, sibling, 5.2, network, or external sources were used, and `baseline/` and `source/` were only read.
- **Recoverable incident, remediated:** while reading inputs, a concatenation of baseline skill text was briefly written to the session scratchpad and deleted immediately. Later scratch work stayed under `output/.work/`, which has been removed.
- **Platform-managed:** the tool runtime persisted some large command outputs to its own session store, and those outputs were read back. They contained only the requested workspace files.

---

## Final corrective pass

### Why this pass exists

After the M refinement above was finished, cross-candidate audits found three more defect classes that also apply to M. This pass continues from the refined `output/template/`; it was not rebuilt from `baseline/`. It repairs only those three classes. For before/after evidence, a snapshot of the pre-pass template was kept under `output/.work/` (removed afterwards). Acceptance is cumulative: every earlier property must still pass.

### Disposition of the three defect classes

| # | Defect class | Disposition |
| --- | --- | --- |
| 1 | The policy-critical PreToolUse guard failed open: a missing, crashing, or timed-out guard, or one given malformed input, let the tool call through. | **Fixed.** The PreToolUse `dependency-guard` entry sets `"onFailure": "block"`. Advisory PostToolUse and Stop hooks stay fail-open, because their event has already happened and a blocking Stop failure could loop. `check-instructions.mjs` now requires `onFailure: "block"` on PreToolUse hooks and rejects it on PostToolUse and Stop hooks. |
| 2 | Shell-driven manifest or project-file changes (sed, `Set-Content`, scripts, `git checkout`, new files) bypassed `check-manifests`. | **Fixed.** After any shell command that is not a known dependency or reference command, PostToolUse validates only the manifests whose content changed since the last manifest check. In a Git working tree, the candidates are the manifests Git reports as changed, plus those changed between the recorded and current HEAD. Without Git there is no narrower signal, so every manifest is a candidate. Content state is stored per worktree in its Git directory. The file-change hook records the manifests it validates, so they are not reported twice. Unchanged manifests are never re-validated, and no full repository validation runs after unrelated commands. |
| 3 | Stop deduplication fingerprinted only reminder IDs and paths, so changing the same file again was suppressed. | **Fixed.** The fingerprint now also covers the content of the relevant changed files (model, seeder, migration, production, and test paths). This is bounded: at most 200 files, each hashed with SHA-256, or by size and mtime above 1 MB. `stop_hook_active` handling is unchanged. |

### Files changed in this pass

All 10 files are under `output/template/`. No file was added or removed.

| File | Change | Defect |
| --- | --- | --- |
| `.claude/settings.json` | `"onFailure": "block"` on the PreToolUse guard only. | 1 |
| `.claude/scripts/check-instructions.mjs` | Fail-closed rule: required on PreToolUse, rejected on PostToolUse and Stop. Header line updated. | 1 |
| `.claude/hooks/hook-io.mjs` | `contentId` (bounded content identity). `manifestChanges` and `rememberManifests` (per-worktree manifest state). `activeRoot` became `activeRepository`. Exit-code comment notes the fail-closed guard. | 2, 3 |
| `.claude/hooks/dependency-guard.mjs` | PostToolUse validates manifests changed by any other shell command. Known-command behavior is unchanged, except that it also records state. | 2 |
| `.claude/hooks/file-change.mjs` | Records the state of manifests it validated, and uses the repository object. | 2 |
| `.claude/hooks/stop-co-change.mjs` | The fingerprint includes the relevant file content. | 3 |
| `.claude/scripts/repo-root.mjs` | `resolveActiveRepository` returns `{ root, top, gitDir }` from the same `rev-parse` call, with a same-tree shortcut. Results are identical to before (the root cases T05/T11/T13/E01–E07 still pass). This keeps the new per-command check at 2 Git spawns instead of 4. | 2 (cost) |
| `.claude/scripts/check-manifests.mjs` | `discover` is exported, for the no-Git candidate set. | 2 |
| `.claude/skills/template-maintenance/SKILL.md` | One sentence on the fail-closed guard, so maintainers keep it. | 1 |
| `.claude/MAP.md` | Settings, hook-io, dependency-guard, and stop-co-change rows updated. | 1, 2, 3 |

### Behavioral evidence

A fresh in-workspace harness ran against the final template, the pre-pass snapshot, and the immutable baseline. Git discovery was capped. Hooks were launched exactly as configured. The fail-closed cases use a launcher model of Claude Code's command-hook semantics:
- exit 2 blocks and exit 0 allows;
- a hook that cannot start, exits with any other code, or times out counts as a failure;
- a failure blocks only when the entry sets `onFailure: "block"`.

Result: **89/89 PASS**, of which 27 cases are new.

- **Fail closed (F00–F04)**
  - The settings set the failure mode correctly, and the normal guard still blocks bypasses and allows benign commands.
  - All six failure modes now block, and each failed open in the pre-pass template:
    - malformed JSON;
    - empty input;
    - `node` not on `PATH`;
    - guard script missing;
    - guard crashing on import;
    - guard hanging past the timeout (a 3 s test timeout stands in for the configured 30 s).
  - Advisory PostToolUse and Stop failures stay non-blocking.
  - T12 adds four checker rejections: PreToolUse without `onFailure`, a non-`block` value, and `block` on PostToolUse or Stop.
- **Shell-driven mutations (S01–S13, E03b, E07)**
  - Detected and blocked; each of the first two passed silently in the pre-pass template:
    - Bash `sed -i` adding a Domain→Infrastructure reference in a linked worktree from a nested cwd;
    - a PowerShell 5.1 `Set-Content` floating npm version from a nested frontend cwd.
  - Also detected:
    - a newly created project file;
    - the same manifest changed again;
    - a `git checkout` that brings in a committed violating manifest;
    - a change in a non-Git copy;
    - a change in a subdirectory-install worktree.
  - A valid shell change gets context routing, not a block.
  - Commands that should stay silent do:
    - an unrelated command;
    - the next command with the same state;
    - after an Edit-validated manifest (MultiEdit violations still block);
    - after a known reference command;
    - from a cwd outside every checkout.
  - A committed, unchanged violation is not re-reported, which shows that no full validation runs.
  - Measured cost after an unrelated command: ~340–390 ms, including Node start, versus ~110 ms before. The extra cost is one `rev-parse` and one `status`.
- **Stop (C01)**
  - The final template follows the required sequence:
    1. First applicable Stop: remind.
    2. Unchanged repeat: silent.
    3. Same file changed again: remind.
    4. Unchanged repeat: silent.
    5. `stop_hook_active=true`, even after a change: silent twice.
    6. New changed path: remind.
    7. Non-relevant content edit: silent.
  - The pre-pass template stayed silent at step 3, which reproduces the defect.

### Cumulative acceptance

- **D1–D6:** every original repair still passes, rerun in the same harness against both the baseline and the final template. These are T01–T13 with all baseline-evidence rows, E01–E07, and the P01 (44 commands) and P02 (32 commands) parser tables.
- **Earlier refinement properties:** all still pass.
  - Windows exec form: no shell, path with spaces.
  - PowerShell 5.1 BOM, including the double BOM (T04a–c).
  - Nested cwd (T02/T02b).
  - Real worktrees: linked, nested `.claude/worktrees/`, and subdirectory installs.
  - npm force and global-option blocking.
  - Project-reference routing.
  - The D6 manual-checker procedure in Bash and PowerShell.
  - The documented manual hook-test commands in Bash and PowerShell.
- **Owner / trigger / minimum-scope regressions:** 0 / 0 / 0.
  - All 23 policy-owner files are still byte-identical to the baseline: CLAUDE.md, the stack, the product inputs, all 11 rules, the agent, and 7 workflow skills.
  - The 194 policies plus GOV-017/GOV-018 are unchanged.
  - No frontmatter or `> Owns:` header changed.
- **Broken references:** 0. `check-instructions` reports 48 files, 0 failures, 0 warnings. Imports resolve and the module graph is acyclic.
- **M identity:** unchanged. Rules stay flat, there are no Level/Kind lines, and no capability, contract, or meta layer was added.
- **Hygiene:** English only, 0 research-metadata hits.

| Measure | Before this pass | After |
| --- | --- | --- |
| Always-loaded estimate | ~4,766 tokens | ~4,766 tokens (CLAUDE.md, stack, and skill/agent listings unchanged) |
| Runtime file count | 61 | 61 |

### Confirmation audit

The confirmation audit covered:
- a line-by-line review of the final changed code;
- the change scope against the pre-pass snapshot (exactly the 10 files above);
- both checkers;
- policy-owner and frontmatter invariance;
- module graph, language, and metadata scans;
- the absence of hook state outside the workspace (OS temp `claude-hooks` absent);
- the documented manual commands;
- a complete harness rerun on the final template: **89/89**.

It found **0 concrete template defects**. The only addition during the audit was a new evidence case (S05b, a new untracked project file), which is a harness-only change. The template did not change after the last complete run.

Workspace events in this pass: 0 isolation violations. All scratch material, sandboxes, and non-Git hook state stayed under `output/.work/`, which has been removed.

### Final status

Every earlier property still passes, and all three new defect classes are fixed with no regressions. **Final status: STRICTLY_BETTER** (cumulative).
