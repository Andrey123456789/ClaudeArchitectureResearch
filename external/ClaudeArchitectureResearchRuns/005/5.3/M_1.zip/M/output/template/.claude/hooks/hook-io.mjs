// Shared helpers for the Claude Code hook entry points in this directory.
// Requires Node.js 18+; works the same on Windows, macOS, and Linux.
//
// Exit-code contract used by the hooks:
//   0  success (optional JSON on stdout for Claude Code)
//   1  hook could not run (environment problem) - reported to the user, work is not blocked
//   2  PreToolUse block - stderr is shown to Claude and the tool call is cancelled
//
// Roots: settings.json launches each hook through ${CLAUDE_PROJECT_DIR}, which
// only locates the script. The repository state a hook inspects is the active
// root, derived from the hook input - its "cwd", or the edited file's location
// for file events (.claude/scripts/repo-root.mjs).

import { readFileSync } from 'node:fs';
import { resolve, relative, isAbsolute, sep } from 'node:path';
import { resolveActiveRoot, canonical } from '../scripts/repo-root.mjs';

// Reads the hook event JSON from stdin.
export function readInput() {
  let raw;
  try {
    raw = readFileSync(0, 'utf8');
  } catch (error) {
    fail(`cannot read hook input from stdin: ${error.message}`);
  }
  raw = raw.replace(/^﻿+/, ''); // Windows PowerShell may prepend one or more UTF-8 byte-order marks
  if (!raw.trim()) {
    fail('hook input on stdin is empty; this script expects Claude Code hook JSON.');
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    fail(`hook input is not valid JSON: ${error.message}`);
  }
}

// Directory the event happened in: the input "cwd" (resolved against the
// process directory when relative), or the process directory when absent.
export function startDirectory(input) {
  const cwd = typeof input.cwd === 'string' ? input.cwd.trim() : '';
  return cwd ? resolve(process.cwd(), cwd) : process.cwd();
}

// Active repository or worktree root for this event; reports and exits when it
// cannot be established, so no check silently runs against the wrong tree.
export function activeRoot(input) {
  try {
    return resolveActiveRoot(startDirectory(input));
  } catch (error) {
    fail(`${error.message}. Repository checks were NOT run.`);
  }
}

// Environment or input problem: report visibly instead of silently skipping.
export function fail(message) {
  process.stderr.write(`[hook error] ${message}\n`);
  process.exit(1);
}

// PreToolUse: cancel the tool call and tell Claude why.
export function blockTool(message) {
  process.stderr.write(`${message}\n`);
  process.exit(2);
}

// Emits a JSON response for Claude Code and exits successfully.
export function respond(payload) {
  process.stdout.write(JSON.stringify(payload));
  process.exit(0);
}

// Adds non-blocking context for Claude after a tool call.
export function postToolContext(text) {
  respond({ hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: text } });
}

// Makes Claude address the reason after a tool call.
export function postToolBlock(reason) {
  respond({ decision: 'block', reason });
}

export function done() {
  process.exit(0);
}

// Repository-relative path with forward slashes, or null when outside the root.
export function repoRelative(root, filePath) {
  if (!filePath || typeof filePath !== 'string') return null;
  const absolute = canonical(isAbsolute(filePath) ? filePath : resolve(root, filePath));
  const rel = relative(root, absolute);
  if (!rel || rel.startsWith('..') || isAbsolute(rel)) return null;
  return rel.split(sep).join('/');
}
