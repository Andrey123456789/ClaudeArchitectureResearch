# Refinement Report — Candidate M

| Item | Result |
| --- | --- |
| Selected baseline | **M/Run-02** (`baseline/template/`, read only; still 60 files / 340,417 bytes as recorded in `PROVENANCE.json`) |
| Final status | **STRICTLY_BETTER** |
| Confirmed defects D1–D6 | 6/6 fixed, each reproduced on the baseline and shown fixed on the output |
| Additional defects found during the audit and fixed | 3 (double-BOM stdin from PowerShell 5.1; npm bypass through shell wrappers; npm bypass through line continuations) |
| Regression matrix | 56/56 PASS (12 dossier cases, edge cases, baseline evidence, and two parser tables with 76 commands) |
| Policy owner / trigger / scope deltas | 0 / 0 / 0 (196/196 owners carried over unchanged) |
| Broken internal references | 0 |
| Always-loaded context | ~4,766 tokens before and ~4,766 after (byte-identical) |
| Runtime file count | 60 before, 61 after (+`.claude/scripts/repo-root.mjs`) |
| Optional Run-01 ideas | 0 adopted, 1 rejected, 2 deferred |
| Confirmation audit | round 1: 1 cleanup item repaired; round 2 (complete rerun): **0 concrete template defects** |

## Changed Files and Reasons

Thirteen files were modified and one was added. Every other runtime file is byte-identical to the baseline.

| File | Reason |
| --- | --- |
| `.claude/settings.json` | **D1.** All four hooks now use exec form: `"command": "node"` with `"args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>.mjs"]`. No shell is involved and no command string depends on the current directory. |
| `.claude/scripts/repo-root.mjs` (new) | **D2/D6.** One resolver for the hooks and the checkers. It keeps two roots apart: the *template root*, found from the script's own location and used only to find the installed scripts, and the *active root*. The active root is computed from a start directory: (1) the same repository's Git working tree, confirmed by a shared common Git dir so linked worktrees count, plus the template's offset inside its tree; (2) otherwise, the template root when the start directory is inside it (no Git, or a submodule); (3) otherwise a clear error. It never treats `CLAUDE_PROJECT_DIR` as repository state. |
| `.claude/hooks/hook-io.mjs` | **D2.** The `CLAUDE_PROJECT_DIR`-based `projectRoot()` was replaced by `startDirectory(input)` (the input `cwd`) and `activeRoot(input)`, which fails visibly with "Repository checks were NOT run". `repoRelative` now canonicalizes paths. **Audit fix:** leading BOMs are stripped with `/^﻿+/`, because the Windows PowerShell 5.1 UTF-8 pipe sends two BOMs. |
| `.claude/hooks/dependency-guard.mjs` | **D4:** a table-driven npm parser. It skips global options and their values (`NPM_VALUE_OPTIONS`), and a token that is not a known npm command is treated as an option value, so it cannot hide the real subcommand. It also detects `npm_config_force`/`npm_config_legacy_peer_deps`, `npm config set force`, `npm set`, and `=false`. **D3:** detects `dotnet add/remove <proj> reference`, `dotnet reference add/remove`, and the package forms. Project-reference changes are classified separately from packages and routed to `architecture.md` § Project References and CLAUDE.md § Decision Control, not to `add-dependency`. **D2:** the manifest check runs on the active root. **Audit fixes:** joins `\`/`` ` `` line continuations and unwraps `cmd /c`, `bash -c`/`-lc`, and `powershell`/`pwsh -Command`. |
| `.claude/hooks/file-change.mjs` | **D2.** The active root for an edit is the checkout or worktree that contains the edited file (a relative `file_path` resolves against `cwd`). Edits in a worktree are no longer skipped silently. |
| `.claude/hooks/stop-co-change.mjs` | **D2.** Git state (status and the per-worktree state dir) is read from the active root derived from `cwd`, not from the main checkout. |
| `.claude/scripts/check-manifests.mjs` | **D2/D6.** The CLI root comes from the current directory through `repo-root.mjs`. `<file>` arguments resolve against the current directory, `isMain` compares canonical paths, and the usage header states the root precondition. |
| `.claude/scripts/check-instructions.mjs` | **D5.** Requires exec form: `type: command`, `command: node`, exactly one argument matching `${CLAUDE_PROJECT_DIR}/.claude/hooks/<name>.mjs`, and a script that exists under the root being checked. It rejects shell strings, `$VAR`/`%VAR%`, relative arguments, other executables, paths outside the hooks directory, and extra arguments. **D6:** its root comes from the current directory. |
| `.claude/skills/verify/SKILL.md`, `add-dependency/SKILL.md`, `project-structure/SKILL.md`, `project-structure/references/backend-layout.md` | **D6.** Each checker or root-relative CLI step now says to run it from the repository root, i.e. the top level of the current checkout or worktree (`git rev-parse --show-toplevel`). Only the invocation lines changed. |
| `.claude/skills/template-maintenance/SKILL.md` | **D1/D2/D5/D6.** The old "shell-neutral `node <script>`" invariant described the defective launcher and now describes exec form and root derivation. Step 4 adds the root precondition. |
| `.claude/MAP.md` | Accuracy for D1/D2/D3/D5/D6: the settings, hook-io, dependency-guard, and check-instructions rows, the architecture enforcement cell, and step 6's root precondition. The new `repo-root.mjs` row is required by the checker's "MAP lists every script" predicate. |

## D1–D6 Repair Evidence

Each defect was reproduced on the baseline in the same sandbox before being shown fixed on the output.

| Defect | Baseline (reproduced) | Refined |
| --- | --- | --- |
| D1 CWD-dependent launch | T02-baseline: from `backend/Shop.Api`, `node .claude/hooks/...` fails with `Cannot find module` (exit 1) in both cmd.exe and Git Bash. | T01/T02/T02b/T03: exec form works from the root and from nested backend and frontend directories, with no shell. |
| D2 launcher root vs worktree | T05-baseline, T11-baseline: inspects the main checkout. It misses worktree Git changes, skips worktree manifests silently, and misses worktree violations. | T05–T05e, T11–T11c, E04–E06: linked worktrees, nested `.claude/worktrees/<n>`, subdirectory installs, and no-Git copies resolve correctly. A cwd outside every checkout fails visibly (E02/E03). |
| D3 project-reference bypass | T06-baseline: `dotnet add … reference …` is ignored. | T06/T07 + P02: add/remove in both CLI syntaxes are detected and the Domain→Infrastructure violation blocks. Packages and references are never confused (32 cases). |
| D4 npm global options | T09/10-baseline: `--prefix … --force` and `--workspace … --legacy-peer-deps` pass. P01-baseline: 23 of 33 must-block commands pass. | T09/T10 + P01: all 44 PreToolUse cases are correct, including 35 must-block cases and no false blocks on 9 benign ones. |
| D5 checker vs exec form | T12-baseline: the correct exec-form settings fail. | T12a accepts exec form. T12 (12 variants) rejects every unsafe shell or ambiguous form. |
| D6 manual root-relative calls | T13-baseline: the nested relative call fails, and the absolute call checks `CLAUDE_PROJECT_DIR` (main) and misses the worktree violation. | T13a–e: the checkers resolve the active worktree from any nested directory. The documented `git rev-parse --show-toplevel` procedure works in Bash and in PowerShell 5.1. |

## Regression Test Matrix

The sandbox was built under `output/.work/sbx`: Git main checkouts plus linked worktrees for both the refined and the baseline template. Git discovery was capped with `GIT_CEILING_DIRECTORIES`. Hooks were launched exactly as configured: exec form (placeholder substituted, `spawn` without a shell) for the refined template, and the shell command string for the baseline.

| # | Dossier case | Tests | Result |
| --- | --- | --- | --- |
| 1 | Launch from repository root | T01 | PASS |
| 2 | Launch from nested cwd | T02, T02b | PASS |
| 3 | Windows-safe exec form | T03 (Windows, no shell, path with spaces) | PASS |
| 4 | PowerShell 5.1 BOM stdin | T04a (one BOM), T04b (real PS 5.1 pipe), T04c (two BOMs) | PASS |
| 5 | Active root from `cwd`, not the launcher | T05, T05b–e | PASS |
| 6 | `dotnet add … reference` detected | T06, P02 | PASS |
| 7 | Reference removal detected | T07, P02 | PASS |
| 8 | Normal `npm install` detected | T08, T08b | PASS |
| 9 | `npm --prefix … install … --force` blocked | T09, P01 | PASS |
| 10 | `npm --workspace … install … --legacy-peer-deps` blocked | T10, P01 | PASS |
| 11 | Manifest and reference checks on the active worktree | T11, T11b, T11c | PASS |
| 12 | Checker accepts exec form and rejects unsafe forms | T12a + 12 rejection variants | PASS |

Extra coverage, all PASS:
- D6 manual invocation: T13a–e.
- Root edge cases: E01–E06.
- Stop-loop protection and once-per-change-set reminders: T05c, T05d.
- Baseline evidence rows (`*-baseline`), confirming each defect exists in the baseline.
- The documented manual-test commands in each hook header, run in Bash and PowerShell.
- Existing checkers on `output/template`: `check-instructions` reports 48 instruction files, 0 failures, 0 warnings. `check-manifests` reports 0 violations, from the root and, using the absolute script path, from a nested directory.

**Residual limitations (not tested, outside the minimal parser):**
- An unlisted npm value option whose value equals an npm command name.
- `npx npm …`.
- PowerShell `-EncodedCommand`.

These are documented in the hook header. No tested dependency or project-reference case bypasses enforcement.

## Policy Owner / Trigger / Scope Audit

- Every policy owner file is byte-identical to the baseline (23 of 23): CLAUDE.md, the imported stack, both product inputs, all 11 rules, the agent, and the 7 unchanged workflow skills.
- The six changed Markdown files have zero frontmatter changes (descriptions, `paths`, `disable-model-invocation`) and zero `> Owns:` header changes.
- The baseline lines no longer present verbatim are all checker-invocation lines, maintenance-invariant lines, or MAP rows. None carries an inventory policy or a shared invariant.
- The baseline's 196/196 mapping (194 inventory policies plus GOV-017/018) therefore carries over unchanged: 0 owner changes, 0 trigger-role deltas, 0 minimum-scope gaps (rule `paths` are untouched).
- M identity is unchanged:
  - flat `.claude/rules/` and no `Level:`/`Kind:` lines (checker);
  - no capability or decision-register layer;
  - workflow and knowledge separation intact;
  - private references used only by their owner.
- No V2 content was removed.
- The new invocation text is procedure placed next to each command, as D6 requires. It is not a policy restatement.
- Hook messages point to their owners instead of restating policy.

## Hygiene, Dependencies, Context

- **Broken references:** 0 (file, `§` section, skill/agent, import, and private-reference checks). Every JS import resolves.
- **Module graph:** acyclic, with `repo-root.mjs` as the leaf (hooks → hook-io / check-manifests → repo-root).
- **Language and metadata:** English only; no Cyrillic in 61 files. 0 research-metadata hits.
- **`CLAUDE_PROJECT_DIR`:** appears only as the launcher placeholder and in comments. No code reads it as a root.
- **Always-loaded context:** about 4,766 tokens before and after (CLAUDE.md + `docs/technology-stack.md` + skill/agent listings, all byte-identical). This is within the ~5k target.
- **Runtime files:** 60 → 61. The added module exists because a single deterministic root resolver is shared by the hooks and the checkers (D2/D6). No layer or metadata was added.

## Windows / Worktree Hook Result

On Windows 11 with Node 24 and Git 2.55 in a path containing spaces, all hooks run in exec form from any cwd. stdin is accepted from Windows PowerShell 5.1, including its double-BOM UTF-8 pipe. The active root resolves correctly for:
- main checkouts;
- nested subdirectories;
- linked worktrees, both sibling and nested under `.claude/worktrees/`;
- subdirectory installs and their worktrees;
- non-Git copies.

When no root can be established, the hooks fail visibly. Known Windows or worktree hook defects: **0**. The baseline has 5 in this matrix: D1, D2, D6, the double BOM, and wrapper/continuation parsing on Windows shells.

## Optional Run-01 Ideas

| Idea | Decision | Rationale |
| --- | --- | --- |
| Source-level architecture checker | **DEFER** | Only Run-01's report is available, so false-positive rates cannot be assessed. Regex heuristics over C# `using`/namespaces are brittle. The highest-value boundary, the project-reference graph, is now enforced mechanically after both edits and CLI changes. Adding it would add a file without proven net benefit. |
| Destructive-Git confirmation hook | **REJECT** | It duplicates Claude Code's permission prompts. GOV-015 is already always loaded. A hook cannot tell whether the user explicitly asked for the operation, so it would prompt on requested operations (noise), and it would add another command-parser surface. |
| Auto instruction-structure check after edits | **DEFER** | Multi-file edits pass through valid intermediate states (for example, a new file before its MAP row) that would raise transient failures and blocks. `template-maintenance` already mandates the checker, and there is no evidence of a net benefit. |

## Rejected or Reverted Proposed Changes

- **Git top level as the only active root:** rejected. It would regress subdirectory installs, which the baseline supported. The same-repository offset mapping covers that case (E06).
- **A one-line root-anchored command (`node "$(git rev-parse --show-toplevel)/…"`):** rejected. It breaks for subdirectory installs and non-Git copies and is less readable. Kept the explicit precondition plus cwd-derived resolution.
- **Quote-aware tokenizer rewrite:** rejected. Not required, and it would drift toward a general shell parser. The fallback scan handles quoted paths (P01).
- **PreToolUse pre-blocking of project references:** rejected. The PostToolUse check and block already cover it with less parsing.
- **MSYS-path conversion of `cwd`:** rejected as speculative. Claude Code supplies native paths, and a failure would be visible.
- **Rewording `architecture.md` / `dependencies.md` enforcement sentences:** omitted. They are still true, and changing them would churn path-loaded rules.
- **Confirmation round 1:** an unused `baseDir` parameter and a cosmetic comment rewording in `hook-io.repoRelative` were reverted to baseline form.

## Confirmation Audit

Round 1 rechecked every gate and every changed item. It found one non-functional cleanup item, the unused parameter and cosmetic rewording above. That item was repaired.

Round 2 was a complete rerun after the repair:
- harness 56/56;
- both checkers clean, from the root and from nested directories;
- module syntax checks clean;
- change scope limited to 13 modified and 1 added file;
- policy-owner invariance 23/23;
- frontmatter and headers unchanged;
- language and metadata scans clean;
- budget equal;
- documented manual commands correct in Bash and PowerShell.

Round 2 found **0 concrete template defects**, so convergence is established.

**Promotion gate:**
1. D1–D6 fixed.
2. 5.2 acceptance gates still pass.
3. No policy, scope, or trigger regressions.
4. 0 broken references.
5. M identity unchanged.
6. Windows and worktree behavior demonstrably stronger.
7. No tested bypass.
8. No new semantic duplication.
9. V2 content retained.
10. Context equal.
11. +1 file, with a reliability purpose.
12. Every change documented above.

All twelve hold, so the result is **STRICTLY_BETTER**.

## Workspace Events

- **Isolation violations:** 0. No parent, sibling, 5.2, network, or external sources were used, and `baseline/` and `source/` were only read.
- **Recoverable incident, remediated:** while reading inputs, a concatenation of baseline skill text was briefly written to the session scratchpad and deleted immediately. Later scratch work stayed under `output/.work/`, which has been removed.
- **Platform-managed:** the tool runtime persisted some large command outputs to its own session store, and those outputs were read back. They contained only the requested workspace files.
